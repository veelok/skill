---
name: cn-patent-drafting
description: >
  中国专利撰写与评审助手，覆盖四种使用场景：
  ①根据交底书从零撰写权利要求；
  ②根据交底书评审权利要求初稿（只评审不改写，输出问题清单与批注）；
  ③根据交底书和确定好的权利要求撰写完整申请文件
  （权利要求书+说明书+摘要+附图）；
  ④根据交底书评审专利全文（权要+说明书，只评审不修复）。
  支持 SEP 对应性分析。覆盖通信、软件、计算机、电子等技术领域。
  支持可插拔领域包（references/domains/）：内置 3GPP 核心网感知
  （ISAC/通感一体）领域包——交底书涉及感知网元（SF/SCF）、
  NEF 感知业务开放、感知授权、感知网元选择、协同感知、感知数据上报
  等主题时，加载该领域 47 件在先申请归纳的撰写策略、套话库与附图版式；
  其他课题方向可通过挂载新领域包扩展。
  当用户需要撰写权利要求、检查/校验权利要求初稿、撰写专利申请全文、
  评审/审查专利申请文件质量时触发。
---

# cn-patent-drafting

## 核心原则

1. **可脚本化的不放在规则里**：格式检查、计数、禁止词汇扫描 → 脚本门禁兜底
2. **Sub agent 隔离重上下文阶段**：交底书分析、SEP分析、权利要求撰写、说明书撰写由 sub agent 完成，主 Agent 只接收入口和出口状态
3. **Sub agent 用 Tool: task 显式调起**，prompt 直接内联在 SKILL.md 中，不依赖外部 prompt 文件
4. **需要判断力的规则配显式验证协议**：写完之后逐条自检
5. **反向校验优先于正向检查**：检查"不应存在的"比检查"应该存在的"更可靠
6. **门禁是脚本，不是 Agent 自查**：确定性工作不走 Agent 判断

---

## 场景路由（先读本节）

本 skill 覆盖四种使用场景。开始任何工作前，先从用户输入识别场景
（用户只给交底书→A；交底书+权要初稿且要求"检查/评审"→B；交底书+确定权要且要求"写全文"→C；
交底书+专利全文且要求"评审"→D）；无法确定时，在 Phase 0 第 0 步向用户确认。

| 场景 | 输入 | 执行路径 | 交付物 |
|---|---|---|---|
| **A 权要撰写** | 交底书 | Phase 0 → 1 → (1.5) → 2 → 2.5 定稿循环 → 4 精简自查 → **交付** | 权利要求书 docx + claims_final.txt + 覆盖校验两张表 |
| **B 权要评审** | 交底书 + 权要初稿 | Phase 0 → 1 → **2R 评审** → gate_02 → **交付** | 权要评审报告 + 批注版权要（如有 docx） |
| **C 全文撰写** | 交底书 + 确定权要 | 完整主流程（见下「整体编排」） | 完整申请文件 docx |
| **D 全文评审** | 交底书 + 专利全文 | Phase 0 → 1 → 拆分全文 → gate_02+gate_03+verify_coverage 直跑 → **6R 评审** → **交付** | 全文评审报告 + 批注版全文（如有 docx） |

路由要点：

- **评审场景（B/D）只评审、不改写、不修复**：问题以评审报告+批注形式交付；
  用户随后要求修改的，再按问题所在文件转入场景 A（权要）或场景 C（全文）的对应 Phase
- **脚本门禁在评审场景中作检查器复用**：gate_02/gate_03/verify_coverage 原样直跑，
  输出并入评审报告，脚本零改动
- **领域包路由对四个场景同样生效**：四个场景都经过 Phase 1，
  命中领域包后按该包文件清单在对应阶段传参
- 场景 A 中 Phase 2 的 {claims_raw_file} 输入缺省（无权要初稿，从零撰写）；
  场景 B/D 不设可选阶段（Phase 1.5/3.5 不适用）

---

## 整体编排（场景 C 主流程）

```
Phase 0: 文档预处理         ← 主Agent直接处理
    ↓ gate_01（脚本）
Phase 1: 交底书分析          ← sub agent（Tool: task）
    ↓
Phase 1.5: SEP对应性分析     ← sub agent（Tool: task），可选（Phase 0 询问用户是否需要）
    ↓ gate_01.5（脚本）
Phase 2: 权利要求撰写        ← sub agent（Tool: task）
    ↓ gate_02（汇总脚本，主Agent直跑）
Phase 2.5: 权要覆盖校验+定稿 ← sub agent 出两张对应表；主 Agent 与用户交互循环：
           展示表格 → 用户选择（直接定稿 / 修改权要）→ 修改则重校验、
           小问题顺手修复、给建议 → 再确认，不定稿则继续等用户修改
    ↓ gate_02 --coverage（每轮修改后重跑，主Agent直跑）
Phase 3: 说明书撰写          ← sub agent（Tool: task）← 最重阶段
    ↓ gate_03 + verify_coverage（脚本 × 2，主Agent直跑）
Phase 3.5: 附图绘制          ← 主Agent直接处理，可选（Phase 0 询问用户是否需要附图）
Phase 4: 反模式自查          ← sub agent（Tool: task），必执行
Phase 5: 摘要+最终整合+DOCX  ← 主Agent直接处理（摘要为改写权1的轻量任务，
           不设独立阶段，在本阶段开头顺手完成）
    ↓ gate_04（摘要脚本）→ gate_05（终检脚本，含交叉校验）
Phase 6: 质量评估与修复       ← sub agent（Tool: task），必执行
    ↓ 明显问题→修复→重跑对应门禁
    交付
```

**领域包路由（可插拔）**：Phase 1 启动前，主 Agent 扫描 `references/domains/` 下各子目录的
`pack.md`，用其中的"命中关键词"对 `output/disclosure.txt` 做全文匹配（grep 即可，
无需通读交底书）：
- 命中某领域包 → 按该包 `pack.md` 的文件清单，在各阶段 prompt 中传入对应文件路径
  （Phase 1 传 disclosure-analysis、Phase 2 传 claims-strategy、
  Phase 3 传 boilerplate、Phase 3.5 读 figures，具体以包内清单为准）；
  下文中"（领域包案件）"即指此情形
- 未命中任何领域包 → 不加载，按通用规则撰写
- 命中多个 → 全部加载，冲突时以更匹配交底书发明点的包为准

**新增领域包**：在 `references/domains/` 下新建子目录，放入 `pack.md`（含命中关键词、
3GPP 归属、文件清单）及策略文件即可，无需改动本文件。当前内置：`isac/`（核心网感知）。

---

## Phase 0：文档预处理（主 Agent）

由主 Agent 直接处理。

**输入**（按场景）：
- 场景 A：交底书（加密/未加密 docx/txt）
- 场景 B：交底书 + 权利要求初稿
- 场景 C：交底书 + 确定好的权利要求文本
- 场景 D：交底书 + 专利全文（权利要求书+说明书，docx/txt）

**操作**：

0. **场景识别**：按「场景路由」节的规则识别场景；无法确定时向用户确认（A/B/C/D 四选一）。
   后续所有步骤按识别出的场景执行
1. 如果 docx 有密码，向用户索取并解密
2. 提取交底书全文并保存为 `output/disclosure.txt`
3. 按场景准备第二输入文件：
   - 场景 A：无第二输入文件，跳过
   - 场景 B：将权要初稿保存为 `output/claims_raw.txt`
   - 场景 C：将确定好的权利要求保存为 `output/claims_raw.txt`
   - 场景 D：拆分专利全文——权要部分保存为 `output/claims_review.txt`，
     说明书部分保存为 `output/spec_review.txt`，说明书摘要（如有）单独保存为
     `output/abstract_review.txt`；拆分边界不清时向用户确认。
     全文 docx 中的附图图片不拆分，保留在原 docx 中供 P6R 的 F 维度评估参考
4. 确认已生成的文件非空
5. **确认本地协议库目录**（仅场景 A/C）：首次使用时询问用户本地 3GPP 协议/提案库存放路径（用于 Phase 1.5/3 的标准文献检索与复用）；确认后记住该路径，后续默认沿用，不再重复询问。用户表示没有协议库则跳过的，后续阶段直接网络检索。场景 B/D 跳过本步
6. **确认发明名称**：
   - 场景 A/C：向用户确认发明名称，给出选项：
     - 通用名称："一种通信方法、通信装置及存储介质"（不确定时的安全默认项）
     - 基于交底书技术方案生成 2~3 个候选名称（格式："一种[技术主题][方法/装置/介质]"，主题取自独权核心特征，避免包含具体实现细节导致保护范围被限缩）
     - 用户自行填写
     确认后的名称在权利要求、说明书、摘要中全文统一使用
   - 场景 B/D：从用户稿件中提取现有发明名称，评审以稿件名称为准，不提议改名
7. **确认可选阶段**（仅场景 A/C）：一次性向用户确认两件事，后续阶段不再重复询问：
   - 是否需要 SEP 对应性分析（Phase 1.5）：交底书对应 3GPP 标准课题时建议执行；
     用户确认执行后，Phase 1.5 必须执行并留痕（sep_analysis.json + gate_01.5），Agent 不得自行跳过
   - 是否需要附图（Phase 3.5，仅场景 C）：默认建议需要。用户明确不要附图的，形成全链路处理：
     Phase 3 prompt 中注明不写附图说明章节、具体实施方式不引用图号；
     Phase 3.5 整体跳过；gate_03 加 `--no-figures` 参数；Phase 5 拼接时不含"说明书附图"章节

**门禁**（按场景选用参数）：
- 场景 A：`scripts/phase_gates/gate_01_preprocess.py --disclosure output/disclosure.txt`
- 场景 B/C：在上述基础上加 `--claims output/claims_raw.txt`
- 场景 D：在上述基础上加 `--claims output/claims_review.txt`

PASS 则继续，FAIL 则提示用户补充。

---

## Phase 1：交底书分析（Sub Agent）

交底书全文可能几百段，进入主 Agent 上下文会严重稀释注意力，因此交由 sub agent 独立处理。
主 Agent 只接收 sub agent 返回的状态摘要和文件路径。

Tool: task
subagent_type: general
prompt: |
  你是一个专利交底书分析代理。

  请读取 {disclosure_file}（交底书 docx 提取出的文本），
  提取以下字段并保存 JSON 到 {output_path}：

  {
    "innovation_points": ["创新点1：xxx", "创新点2：xxx", ...],
    "tech_problems": ["要解决的技术问题1", "技术问题2", ...],
    "diff_features": ["区别技术特征1", "区别技术特征2", ...],
    "beneficial_effects": {"特征A": "效果A", "特征B": "效果B", ...},
    "embodiment_details": [
      {"name": "实施例1", "content": "详细描述..."},
      {"name": "实施例2", "content": "详细描述..."}
    ],
    "alternative_solutions": ["替代方案1", ...],
    "potential_commercial_scenarios": ["场景1", ...],
    "method_steps": ["步骤1：第一网元接收……", "步骤2：第一网元确定……", ...]
  }

  要求：
  - 逐条提取，不要合并或遗漏
  - method_steps 字段：按交底书原文顺序提取方法步骤序列（交底书没有显式编号时，
    按动作语义自行切分），每步一句话概括——该字段将被 verify_coverage.py 和
    Phase 4 反模式自查直接消费，务必完整
  - 保留交底书原始关键信息，不要重写
  - 标注来源类型："交底书原文"或"逻辑推演"
  - 技术术语尽量保留交底书中的原文
  - 若主 Agent 在 prompt 中传入了领域包文件 {domain_disclosure_analysis_file}
    （即交底书命中了某领域包），先 read 该文件，按其信息采集清单补全字段
    （触发点、新增/修改的消息与字段、判断/选择规则、数据流向、与现有 3GPP 流程的差异等），
    并尝试归入其发明点类型库；信息缺项且影响撰写时，按其中的提问模板向用户提问补齐，不要编造。
    未传入则跳过本项
  - 交底书未给出的技术细节（消息名、字段、判断规则）：可按领域惯例建议并标注
    【待确认】，不得当作交底书已有内容写死

  输出：纯 JSON 到 {output_path}。
  最后返回一行：
  STATUS:PASS|FAIL  INNOVATION_COUNT:N  EMBODIMENT_COUNT:N  STEP_COUNT:N  WARNINGS:N

**主 Agent 操作**：启动前按"领域包路由"扫描命中情况，命中则将命中包的
disclosure-analysis 文件路径填入 prompt 的 {domain_disclosure_analysis_file}，未命中则删除该占位行。
收到返回后保存 output_file 路径，只读取 STATUS 和计数行，不保留 JSON 全文在主 Agent 上下文。

---

## Phase 1.5：SEP 对应性分析（Sub Agent）— 可选，经 Phase 0 与用户确认后执行

在交底书分析之后，权利要求撰写之前，由 sub agent 独立完成标准匹配、提案搜索、扩展建议。

⚠️ **执行与否只由用户在 Phase 0 第 7 步的确认决定，Agent 不得自行跳过**。
主 Agent 在 Phase 0 询问时可以给出建议（如交底书明显不涉及标准——纯软件算法、
纯硬件结构等——则建议用户跳过），但只要用户确认执行，本阶段就必须执行并留痕
（产出 sep_analysis.json + 通过门禁），不得以任何理由静默跳过。

Tool: task
subagent_type: general
prompt: |
  你是一个 SEP（标准必要专利）对应性分析代理。
  分三步执行，按顺序：

  【第1步：标准课题匹配】
  读取 {disclosure_analysis_file}，分析交底书技术方向。
  参考 {sep_mapping_file} 中的 3GPP 课题对照表，判断可能的课题归属。
  输出候选课题列表，每个标注置信度（高/中/低）和理由。

  【第2步：提案方向搜索】
  针对置信度"高"的课题，搜索相关提案的讨论方向。
  使用可用的搜索工具（web 搜索/本地协议库检索等，以当前环境实际可用的为准），关键词示例：
  - "R1 {关键术语} agreement"
  - "RAN2 {关键术语} discussion"
  - "SA2 {关键术语} solution"
  提取：争议点、主流方案、各公司倾向。

  【第3步：扩展建议】
  结合交底书发明点和提案方向，给出合理的实施例扩展建议。
  标注每条的来源类型：
  - [提案依据]：来自标准提案讨论（必须标注具体提案编号，如 R1-24xxxxx）
  - [逻辑推演]：基于发明点的合理演绎
  - 严禁无依据的编造

  输出 JSON 到 {output_path}，格式：
  {
    "standard_matches": [{"standard": "RAN1", "relevance": "HIGH", "reason": "xxx"}],
    "proposal_directions": [{"topic": "xxx", "agreements": ["xxx"], "companies": ["xxx"]}],
    "extension_suggestions": [{"title": "xxx", "source": "提案依据|逻辑推演", "proposal_ref": "R1-xxx"}],
    "warnings": []
  }

  最后返回一行：
  STATUS:PASS|FAIL  STANDARD_MATCHES:N  PROPOSALS_FOUND:N  EXTENSIONS:N  WARNINGS:N

**门禁**：
运行 `scripts/phase_gates/gate_01.5_sep.py --sep output/sep_analysis.json`
PASS 则继续。FAIL 或检索后确无可匹配标准时，**不得静默跳过**——主 Agent 必须把
FAIL 原因 / 无匹配结论摆给用户，由用户决定：补充检索线索后重跑本阶段、
确认无标准相关性后进入 Phase 2、或暂停流程人工介入。

**主 Agent 操作**：
1. **执行留痕校验**：进入 Phase 2 之前，核对两样东西——
   ① sub agent 返回行包含 `STANDARD_MATCHES:N` 字段（Phase 1.5 的返回签名，
   防止把其他阶段的输出张冠李戴）；② `output/sep_analysis.json` 存在且非空。
   任一不满足，视为本阶段未执行，必须先补跑或向用户说明，不得带着缺失状态进入 Phase 2
2. 校验通过后保存 output_file 路径。将 extension_suggestions 列表作为参考传递给
   Phase 2 和 Phase 3 的 sub agent。不保留 JSON 全文。

---

## Phase 2：权利要求撰写（Sub Agent）

需要同时处理交底书分析结果、权利要求原文、撰写细则，上下文较重，由 sub agent 独立完成。

Tool: task
subagent_type: general
prompt: |
  你是一个专利权利要求撰写代理。

  【输入文件】
  - {disclosure_analysis_file} — 交底书分析结果（JSON）
  - {claims_raw_file} — 确定好的权利要求原文（场景 A 无权要初稿时本项缺省，直接从零撰写）
  - {claim_rules_file} — 权利要求撰写细则（先 read 这个文件获取规则）
  - （可选）{sep_analysis_file} — SEP 分析结果中的 extension_suggestions
  - （领域包案件）命中包的 claims-strategy 文件 — 如 ISAC 案件读 references/domains/isac/claims-strategy.md
    （权利要求树、独权句式模板、从权三层素材库），命中领域包时先 read 再动笔
   【任务】
   1. 读取 claim_rules_file 了解撰写细则（包括单侧撰写、主题名称上位化、执行主体默认省略主语、动作描述抽象化等）
   2. 读取 disclosure_analysis_file 了解交底书内容
   3. 读取 claims_raw_file 获取确定好的权利要求（场景 A 无此文件时跳过，基于交底书分析结果从零撰写）
   4. 撰写/补充权利要求，严格遵守以下原则：
      a) 单侧撰写：每项权利要求只能有一个执行主体，不允许出现两个不同设备共同完成动作的情况
      b) 覆盖交底书的全部创新点
      c) 全品类布局（方法 + 装置 + 存储介质 + 程序产品 + 芯片）
      d) 回引型权利要求覆盖全部方法权项
      e) 使用标准引用格式："根据权利要求X所述的"
      f) 无禁用词："可以"、"优选"、"大约"、"例如"、"等"
      g) 独立权项数不限，总权项数 ≤ 30；特别复杂的案子总权项数 ≤ 40
      h) 方法权要先写，全部方法写完后再写装置权要（装置权要回引方法权要）
      i) 主题名称使用上位表达："一种通信方法"而非"一种[具体方案]方法"
      j) 执行主体（详见 claim_rules_file 第四节）：方法独权**默认省略主语**，用消息流句式——
         "接收/获取+触发消息（所述+用途定义）→ 基于所述触发消息+核心动作（确定/选择/判断）→ 发送+结果消息（所述+用途定义）"；
         不写"[主语网元]向[目标网元]发送……"这类具名主语+收发对象修饰。
         仅当省略主语会不清楚（多网元密集交互、消息来源/去向本身是发明点）时，
         才用具名网元主语（NEF/SF/AMF/接入网设备/UE 等）或"第一通信设备/第一网元"代称
         （代称必须配下位列举从权："所述第一网元为如下网元之一：……"），且全篇统一
      k) 动作描述去冗余：去掉"来自XXX"、"向XXX"等修饰，除非会导致不清楚
         - ⚠️ 常见违规："接收接入网设备发送的第一消息"→应改为"接收第一消息"
         - ⚠️ "向所述接入网设备发送第二消息"→应改为"发送第二消息"
         - ⚠️ "接收应用功能实体发送的感知业务请求"→应改为"接收感知业务请求"
         - 例外规则：当消息的发送方/接收方是**核心动作目的地**（如"发送感知数据到目标处理功能实体"中删除"到目标处理功能实体"会导致不清楚数据发送目的地），或**动作方向本身就是发明点**时，才保留
         - 具名路线下保留来源修饰（"接收来自于所述UDM网元的授权响应消息"）也是常见在先申请风格，按判断标准把握
      l) 独权主语风格一致：默认全省略主语；采用具名/代称路线时全程"所述+主体"回指，不混用
      m) 装置权要形式二选一且全篇统一（详见 claim_rules_file 6.3）：
         - 形式一·处理器回引式：多套方法权要时用"或者"连接合并回引，
           如"执行如权1至10任一项所述的方法，或者如权11至13任一项所述的方法"
         - 形式二·功能单元式：接收单元/处理单元/发送单元与方法步骤一一对应
      n) 从权分层素材优先顺序：流程分支细化 > 消息字段枚举（"包括如下一项或多项"）> 参数与条件；
         领域包案件字段池参考命中包的 claims-strategy 文件（ISAC 包见第四节）
      o) 禁止占位符残留：输出文本不得包含任何方括号模板槽（如"[主语网元]""[触发消息]"），
         所有槽位必须实例化为具体技术术语（gate_02 格式检查已覆盖，残留即 FAIL）
   5. 如有 sep_analysis_file，参考其中的 extension_suggestions 调整布局

  【输出】
  完整权利要求文本到 {output_path}。
  最后返回一行：
  REGION:claim_drafting  STATUS:PASS|FAIL  OUTPUT_FILE:{output_path}  CLAIM_COUNT:N  INDEP_COUNT:N  CATEGORIES:类别列表  WARNINGS:N  ERRORS:(如有)

**门禁**（主 Agent 直接运行汇总脚本，一次覆盖数量/格式/序号三项子检查）：

```
python scripts/phase_gates/gate_02_claims.py --claims {claims_final_file}
```

结果为 PASS 则继续；FAIL 则按 sub_checks 中失败项修正后重跑 Phase 2
（数量类问题→重跑撰写；格式/引用类问题→参考 `references/verification_protocols.md` 的 VP2/VP10 修正）。

---

## Phase 2.5：权要覆盖校验与定稿确认（Sub Agent 校验 + 主 Agent 交互循环）

权利要求初稿完成后、说明书动笔前，校验权要是否覆盖全部关键发明点，把对应关系摆给用户看，
并由用户决定直接定稿还是修改后再定稿——**只有用户明确定稿才能进入下一阶段**
（场景 A：交付权要；场景 C：Phase 3 说明书撰写）。

### 第1步：覆盖校验（Sub Agent）

上下文中量，由 sub agent 完成比对并产出两张表。

Tool: task
subagent_type: general
prompt: |
  你是一个专利权利要求覆盖校验代理。

  【输入文件】（先 read 再比对）
  - {claims_file} — 当前的权利要求书
  - {disclosure_analysis_file} — 交底书分析结果（取其中 innovation_points 字段作为关键发明点清单）

  【任务】
  1. 逐项核对：每项权利要求 ↔ 它落在交底书的哪个实施例、对应哪个（些）关键发明点
  2. 反向核对：每个关键发明点 ↔ 被哪些权项覆盖；存在未被任何权项覆盖的发明点视为 FAIL
  3. 产出两张 Markdown 表格，写入 {output_path}：

     表1·权要对应表（每项权要一行，权项号连续无缺）：
     | 权项 | 类型（独权/从权） | 主题（方法/装置/介质…） | 对应实施例 | 对应关键发明点 |

     表2·发明点覆盖表（每个关键发明点一行）：
     | 关键发明点 | 覆盖权项 | 覆盖状态（已覆盖/未覆盖） |

     表格后附一节"结论"： uncovered 列表（为空则写"全部发明点已被覆盖"）。

  最后返回一行：
  STATUS:PASS|FAIL  CLAIM_ROWS:N  INNOVATION_ROWS:N  UNCOVERED:N
  （UNCOVERED>0 时 STATUS 必须为 FAIL）

**门禁**（主 Agent 直接运行）：

```
python scripts/phase_gates/gate_02_claims.py --claims {claims_final_file} --coverage output/claims_coverage.md --analysis {disclosure_analysis_file}
```

- 脚本校验：表1 权项号与权要书 1..N 一一对应无缺行；表2 发明点行数与 innovation_points 一致且无"未覆盖"
- 覆盖校验 FAIL（有发明点未被覆盖）→ 按缺失发明点补写/调整权项（重跑 Phase 2），再重跑本步

### 第2步：用户定稿确认（主 Agent 交互循环）

覆盖校验 PASS 后，主 Agent 执行以下循环（参考流程：展示表格→用户选择→修改则校验后再确认，直至定稿）：

1. **展示与询问**：把 claims_coverage.md 的两张表完整展示给用户，附上权要全文（或文件位置），
   然后让用户单选：
   - **直接使用当前权利要求（定稿）** → 跳出循环：场景 A 经 Phase 4 精简自查后交付权要，场景 C 进入 Phase 3
   - **我要修改权利要求** → 进入第 2 项
2. **接收修改后的权要**，两种途径都支持（询问时一并说明）：
   - 用户上传修改后的权要文档（docx/txt）→ 提取文本，覆盖写回 {claims_final_file}
   - 用户在主 Agent 给出的权要文本上直接修改，回复"已完成修改"→ 以用户贴出的文本为准覆盖写回
3. **修改后重校验**：对修改后的 {claims_final_file}：
   a. 权项如有增删改，先重跑第1步的覆盖校验 sub agent，刷新两张表（否则覆盖门禁会对陈旧表误判）；
   b. 重跑 gate_02 完整校验（数量/格式/序号三项子检查 + 覆盖表校验，一条命令覆盖）；
   c. 向用户给出**建议清单**（如独权范围过宽/过窄、从权层次、单侧撰写疑点等语义层面建议）；
   d. **确定性强的小问题顺手修复**：编号错误、引用格式错误（"根据权利要求X所述"写法）、
      编号倒序/跳号等——修复后重跑门禁确认 PASS，并把修复点逐条告知用户；
   e. 结构性问题（保护范围、布局）不擅自改，列入建议清单交用户定夺
4. **再确认**：把校验结果（PASS/FAIL 明细）、顺手修复的内容、建议清单一并告知用户，
   再次让用户单选：
   - **可以定稿** → 跳出循环：场景 A 经 Phase 4 精简自查后交付权要，场景 C 进入 Phase 3
   - **不定稿，继续修改** → 回到第 2 项，重新等待用户修改后的权要
5. 循环不限制轮数；每轮修改均以用户提供的最新权要文本为唯一基准（防 AM1 式串改）

**场景 A 交付（定稿并精简自查通过后，主 Agent 执行）**：
1. 用 `references/patent_format.py` 的 PatentDoc 生成**权利要求书 docx**（默认交付物）：
   页标题"权利要求书"（`add_page_title("权利要求书", after=240)`），逐条权要调用
   `add_claim_group`（每条权要一个列表传入），条间 `add_sep_line()` 空行分隔；
   保存为 `output/权利要求书.docx`
2. 交付三件：`权利要求书.docx` + `claims_final.txt` + `claims_coverage.md`（两张覆盖表）

---

## Phase 2R：权利要求评审（Sub Agent）— 场景 B 专用

只评审、不改写。对用户的权要初稿做形式 + 语义双层检查，产出评审报告。
用户随后要求按报告修改的，转入场景 A 的 Phase 2 流程。

Tool: task
subagent_type: general
prompt: |
  你是一个专利权利要求评审代理。你的任务是【只评审，不改写】用户的权利要求初稿。

  【输入文件】（先 read 再评审）
  - {claims_raw_file} — 用户权要初稿（output/claims_raw.txt）
  - {disclosure_analysis_file} — 交底书分析结果（innovation_points 为发明点清单）
  - {claim_rules_file} — 权利要求撰写细则（评审依据）
  - {verification_protocols_file} — 显式验证协议（VP1/VP2/VP10 为必做项）
  - {review_template_file} — 评审报告模板（references/review_templates.md）
  - （领域包案件）命中包的 claims-strategy 文件 — 如 ISAC 案件读 references/domains/isac/claims-strategy.md

  【任务】逐项检查并记录问题（位置/描述/依据/严重程度/建议）：
  1. 语义评审（必做）：
     - VP1 独权保护范围：对每个独权特征做删除测试，找出可删除的冗余特征
     - VP2 从权递进：绘制依赖链，检查跳级引用无增量、两从权限定重叠
     - VP10 回引覆盖：回引型权要（装置/介质/程序产品/芯片）是否覆盖全部方法权项
  2. 布局评审：全品类布局（方法/装置/介质/程序产品/芯片）、单侧撰写、
     主语写法（清楚场景下不应堆具名主语+收发对象；具名/代称路线须全篇一致）、主题名称上位化
  3. 覆盖评审：交底书每个发明点是否被权项覆盖；独权范围是否明显过宽/过窄
     （对照交底书区别技术特征与现有技术判断）
  4. 形式问题（引用格式、禁用词、编号、权项数）以主 Agent 的 gate_02 结果为准，
     你不重复扫描，但应在报告中引用其结论

  【输出】按 review_template_file 的"权要评审报告"模板写入 {report_file}。
  严重程度分级：高＝可能导致驳回或保护范围实质受损；中＝影响权要质量但可补救；低＝建议性优化。

  最后返回一行：
  STATUS:PASS|FAIL  HIGH:N  MID:N  LOW:N
  （HIGH>0 时 STATUS 必须为 FAIL）

**主 Agent 操作**（sub agent 返回后执行）：
1. 直跑 `python scripts/phase_gates/gate_02_claims.py --claims output/claims_raw.txt`
   （不加 --coverage），把脚本违规明细并入评审报告的"形式检查"一节
2. 用户提供的是 docx 权要初稿的，用 `references/patent_format.py` 的 add_comment
   把高严重度问题以批注标到原文对应段落，输出批注版 docx
3. 交付：评审报告 + （如有）批注版权要；不修改权要本身

⚠️ 评审场景中 STATUS:FAIL 与门禁 FAIL 均不阻断交付、不进入修复循环——
FAIL 仅表示存在高严重度问题，明细全部留在报告中交用户定夺。

---

## Phase 3：说明书撰写（Sub Agent）

**这是整个流程中最重的阶段**——需要同时处理交底书、权利要求、模板，生成几百段的正文。
必须使用 sub agent 隔离，主 Agent 不接触中间产物。

Tool: task
subagent_type: general
prompt: |
  你是一个专利说明书撰写代理。

  【通用规则】（全文适用，不区分章节）
  ⚠️ 全文禁止出现标准协议号（如TS23.137、TR23.700-14、TR22.837、R19、SA2等）——只写"现有标准"或"当前通信标准"。
  ⚠️ 说明书中出现的外文缩写首次出现时必须给出中文全称，例如"感知控制功能（Sensing Control Function，SCF）"。
  ⚠️ 需要参考3GPP标准协议或提案时：先到本地协议库目录（即 Phase 0 确认的 {protocol_lib_dir}）查找是否有同名标准号/提案号的文件；如果已有则直接使用，如没有则从网络搜索下载到该目录（下载无约束），以标准号/提案号命名文件（如"TR23.700-14.docx"），便于后续复用。若用户未配置协议库，则直接网络检索参考，不落盘。

  【输入文件】
  - {claims_file} — 确定好的权利要求（先 read 获取内容）
  - {disclosure_analysis_file} — 交底书分析结果（先 read 获取内容）
  - {spec_templates_file} — 说明书模板（先 read 获取各章节模板）
  - （可选）{sep_analysis_file} — SEP 扩展建议
  - （领域包案件）命中包的 boilerplate 文件 — 如 ISAC 案件读 references/domains/isac/boilerplate.md
    （背景技术三段式、网元功能定义段、感知专用定义段、中英对照词汇表、
    结尾通用段），领域包案件优先从套话库取用并替换方括号占位词

  【撰写顺序和要点】
  按以下 5 章顺序撰写，写完一章再写下一章：

  ### 第1章：技术领域（1句话）
  模板："本申请涉及[技术领域]，尤其涉及[发明标题]。"
  ⚠️ "尤其涉及"之后的文字必须与发明标题**逐字一致**——例如使用默认发明标题时写
  "尤其涉及一种通信方法、通信装置及存储介质"，不得改写、增删或调整语序。

  ### 第2章：背景技术（3~5句）
  ⚠️ 严禁透露本申请的技术特征。
  只描述现有技术方案及其存在的问题。
  不使用"本申请"、"本发明"、"本方案"等措辞。
  模板："目前，[现有技术]通常采用[实现方式]。然而，[现有技术]存在[具体问题]。"

  ### 第3章：发明内容
  ⚠️ 本章**不写任何小标题**（包括"要解决的技术问题""技术方案""有益效果"），
  不使用黑体/加粗标题，全部以自然段落撰写；不写"3.1""3.2"等编号。
  按以下结构顺序成段：

  1. 首段直接叙述要解决的技术问题（1~2 句，不加标题）。
  2. 之后**每项独立权利要求对应一个"方面"段落**，格式：
     "第一方面，本申请实施例提供一种通信方法，……（独权1技术方案的改写）"
     后续独权依次"第二方面，本申请实施例提供……""第三方面……"，方面主题与权要品类一致。
     每个方面段落之后，把该方面**全部从权的附加技术特征**逐条续写
     （"在一种可能的实现方式中，……""可选地，……"句式）——
     **全部权利要求都要改写到本章**，不允许只写方面概括句；
     还可补充权要中未写入、但交底书/说明书已记载的技术特征。
  3. ⚠️ 有益效果紧跟对应方案，且**另起一个自然段**：
     - 方法独权（尤其是第一方面）的改写内容之后**必须**另起一段写有益效果；
     - 其他方面的改写内容之后，如有对应的有益效果，也另起一段写；
     - 句式"……，从而/因此/进而……"，效果具体（减少XX开销、避免XX问题、提高XX效率），
       禁止"效果好""性能优"式空话。
  4. 发明内容的体量通常不少于权利要求书文本量的六成。
  ⚠️ 禁止写"（对应权利要求5）""（对应权X）"等说明性标注文字——方面与权项的对应关系
  靠"第X方面"顺序表达即可。

  ### 第4章：附图说明
  ⚠️ 若主 Agent 在 prompt 中注明"用户确认不要附图"：本章整体不写（连同标题），
  具体实施方式中也一律不出现"图X"引用。
  正常情形按下述格式撰写：
  图1 为本申请实施例提供的一种通信系统的架构示意图；
  图2 为本申请实施例提供的一种通信方法的流程示意图；
  图3 为本申请实施例提供的一种通信装置的结构示意图。
  ⚠️ 每条"图X"描述必须对齐格式、都以"图X 为本申请实施例提供的"开头、以"示意图"结尾。不要有的有括号说明有的没有。

  ### 第5章：具体实施方式（最重章节）
  
  ⚠️ 标题白名单：说明书全文只允许 5 个章节标题——"技术领域""背景技术""发明内容""附图说明""具体实施方式"，
  章内一律不设小标题（发明内容内也不设，见第3章约束）。
  除此之外，**任何内容不得以独立短行标题的形式出现**，也不得用 **加粗** 等 markdown 标记模拟标题。
  点名禁止的标题变体（均须按下述方式写成自然段落）：
  - "XX侧流程"类（如"SCF侧流程""接入网设备侧流程"）→ 改为自然段引导句后直接写步骤，
    如"下面结合图2，从感知控制功能实体侧对本申请实施例提供的通信方法进行详细说明。"
    随后紧跟 S101 起的步骤段落，中间不得插入任何标题行
  - "替代方案" → 不设独立章节，融入方法实施例对应步骤的"在一种可能的实现方式中"段落
  - "装置实施例" → 不设标题，以自然段落起笔："本申请实施例还提供一种通信装置，……"
  - "术语解释""应用场景""系统架构""方法实施例""SEP扩展" → 同上文，顺序成段、不设标题

  ⚠️ 多实施例组织方式：不得使用"实施例一""实施例二""第一实施例"等编号标签区分实施例——
  编号区分后各实施例的技术特征不便结合，不利于后续审查意见答复时的特征组合。
  不同实施例的内容统一以"在一种可能的实现方式中……"段落自然展开、顺序衔接。
  如需标明某段与交底书哪个实施例的对应关系，在 Phase 5 生成 DOCX 时以批注（修订模式）标明，不写入正文。

  按以下顺序撰写，**不要使用"5.1""5.2""9.1""9.2"等编号**，直接写内容段落：

  1. 术语解释 — 关键术语定义
  2. 应用场景 — 适用场景描述
  3. 系统架构 — 结合附图描述系统组成和交互
  4. 方法实施例 ← 核心部分
      按权利要求中的方法步骤逐条展开，每个步骤写一段。
      ⚠️ 不得合并步骤——交底书 N 个步骤，说明书必须 N 个步骤。
      每个步骤提供多种实现方式（"在一种可能的实现方式中..."）。
      步骤编号：S101, S102, S103...
  
      ⚠️ 替代方案和SEP扩展内容**必须融入**到方法实施例中对应的步骤之下，
      而不是单独写在章节末尾。例如：
      - 如果某步骤有替代实现方式，直接在该步骤写"在另一种可能的实现方式中..."
      - 如果某扩展与特定步骤相关，写在对应步骤的"在一种可能的实现方式中"段落里
      - 禁止在方法实施例之后单独写"替代方案"或"SEP扩展"章节

  5. 装置/系统套话 ← 以下子节全部必须完成
      ⚠️ 不写编号、不写子节标题（标题白名单见上）——每个子节就是一段或连续几段自然段落，
      用"本申请实施例还提供一种……装置，……""在一种可能的实现方式中，该装置为……"等引导句起笔，
      按以下顺序依次成段：
      模块装置图（处理单元+收发单元）
      硬件装置图（处理器+收发器）
      计算机可读存储介质
      计算机程序产品
      芯片（含芯片系统/SoC）
      通信系统（含多方设备交互）
      处理器/存储器声明套话（CPU/DSP/ASIC/FPGA/ROM/RAM）
      内部单元互连（总线）
      功能单元集成声明
      软件功能单元存储声明
  
  ⚠️ 再次强调：具体实施方式下不设任何独立标题（含"SCF侧流程""接入网设备侧流程"等"XX侧流程"变体、
  "替代方案""装置实施例"等），全文禁止出现 ** 加粗标记。以上内容全部作为自然段落顺序撰写，
  段落之间用"下面结合图X……""在一种可能的实现方式中……""本申请实施例还提供……"等引导句衔接。

  【输出】
  完整说明书文本到 {output_path}。
  最后返回一行：
  REGION:spec_drafting  STATUS:PASS|FAIL  OUTPUT_FILE:{output_path}  CHAPTERS:章节列表  PARA_COUNT:N  BOILERPLATE_COMPLETE:是|否（10个子节）  WARNINGS:(如有)  ERRORS:(如有)

**门禁**（主 Agent 直接运行两个脚本）：

```
python scripts/phase_gates/gate_03_specification.py --spec {spec_file} --claims {claims_file} --title "{发明名称}"
# 用户确认不要附图时，追加 --no-figures
python scripts/verify_coverage.py --disclosure {disclosure_file} --specification {spec_file} --analysis {disclosure_analysis_file}
```

- gate_03 覆盖：章节完整性与顺序、装置套话完整性、方法步骤存在性、背景技术纯净度、
  独立标题扫描（白名单之外的短行标题与 ** 标记，AM8 的脚本防线）、发明内容厚度（体量比+有益效果标记）、
  技术领域与发明标题一致性（--title）、"实施例一/二"编号标签扫描、
  发明内容"（对应权利要求X）"标注与第一方面有益效果段落检查
- verify_coverage 覆盖：交底书→说明书的语义片段覆盖度与步骤差集（反向校验）
- 两者均不出现 FAIL 则继续（WARN 不阻塞，但需人工扫一眼缺失片段）；
  FAIL 则修正后重跑 Phase 3（背景技术泄露→参考 VP7；覆盖缺失→参考 VP4/VP5）

---

## Phase 3.5：附图绘制（主 Agent）— 可选，经 Phase 0 与用户确认后执行

由主 Agent 直接处理。Phase 0 已确认需要附图、或说明书附图说明中引用了需要绘制的图时执行。

**操作**：
1. 先检查附图资产库 `assets/figures/`（命名规范见库内 README）：列出目录清单，
   与当前案件所需图型匹配——可直接复用的引用文件名并说明复用理由；
   需新绘的进入第 2 步
2. 读取命中领域包的 figures 文件（如 `references/domains/isac/figures.md`）获取附图版式规范（该规范虽源自核心网感知专利，
   其四类固定版式——架构图/信令时序图/装置功能框图/硬件结构图——对一般通信案件同样适用）
3. 先出图、再核对：保证"图N"编号、步骤号、标号与附图说明和具体实施方式逐字一致
4. 硬性规则：两点直连/横平竖直，禁止多段绕行折线、断头线、连线穿框；黑白线稿；
   可选元素用虚线；图文互查
5. 用可用的绘图工具生成可编辑黑白矢量图（每图一页/一文件），完成后截图自检
   连线与标签，发现问题改坐标重出，不带瑕疵交付；定稿后可复制入 `assets/figures/` 沉淀复用

**产出**：附图文件（可编辑格式），供 Phase 5 整合进 DOCX 的说明书附图章节。

---

## Phase 4：反模式自查（Sub Agent）— 必执行

> **场景 A 使用方式（精简自查）**：场景 A 只产出权要、无说明书，定稿后、交付前必须跑一次
> 精简自查——prompt 输入只传 {claims_file} 与 {disclosure_analysis_file}（无 {spec_file}），
> 检查项限 C1–C10 与 AM1/AM6，AM2/AM8 记 N/A；FAIL 项按本节末尾主 Agent 操作修复后重跑。

Tool: task
subagent_type: general
prompt: |
  你是一个专利撰写质量自查代理。

  先 read {anti_patterns_file} 了解反模式库。
  然后检查以下文件是否存在反模式案例中的错误：
  - {claims_file}
  - {spec_file}
  - {disclosure_analysis_file}（AM2 步骤比对用）
  注：用户在 Phase 0 确认不要附图的，AM8(c) 附图说明检查记 N/A。

  检查项：
   AM1（全局替换扩大范围）：如果本次有修改操作，检查修改是否超出指定权项。
   AM2（步骤静默合并）：检查说明书方法步骤数是否与交底书步骤数一致。先 read {disclosure_analysis_file} 的 method_steps 字段获取交底书步骤序列。
   AM6（输出截断）：检查 claims_final.txt 和 specification.txt 是否完整（末尾无截断标记）。
   AM8（说明书结构）：检查 specification.txt 中：
      (a) 是否有"3.1""9.1"等编号 → 应无编号
      (b) 是否有"术语解释""应用场景""系统架构""方法实施例""装置实施例""替代方案""SEP扩展"等独立标题，
          以及"XX侧流程"（如"SCF侧流程"）变体、用 **加粗** 模拟的标题 → 应全部放在"具体实施方式"下一段式顺序撰写
          （修复方式见 AM8 源头预防节：引导句直写/融入对应步骤/自然段起笔）
      (c) 附图说明格式是否对齐（每条以"图X 为本申请实施例提供的"开头、以"示意图"结尾）
      (d) 替代方案和SEP扩展内容是否已融入方法实施例对应步骤中 → 如果有独立章节则FAIL
      (e) 是否有"实施例一""第一实施例"等实施例编号标签（含"（对应于实施例X）"式回指） → 
          应改为"在一种可能的实现方式中"自然成段，对应关系留待 Phase 5 以批注标明
   C1（标题过于下位）：检查每个独立权利要求的主题名称是否使用了"一种通信方法""一种通信装置"等上位表达，而非"一种[具体方案]方法"。
   C2（执行主体路线混用）：检查全篇主体写法是否统一——具名标准网元（路线A）与"第一通信设备"代称（路线B）不得混用于同一类主体；路线B必须配下位列举从权。
   C3（动作主体冗余）：检查技术特征中是否有多余的"来自XXX"、"向XXX"等修饰（具名路线下为明确交互关系而保留的来源修饰除外）。
   C4（装置权要形式）：检查装置权要形式是否统一（处理器回引式 或 功能单元式，不混用）；用回引式时多套视角合并为一条（"或者"连接），且不存在"根据权利要求X所述的方法"开头的伪装置权要。
   C5（标准结尾权要缺失）：检查是否缺少装置/存储介质/程序产品等标准结尾权要。
   C6（结构顺序）：检查方法权要是否全部集中在前、装置权要统一在后。
   C7（单侧撰写违反）：逐条检查权利要求，确认每项只有一个执行主体；从权中的动作也必须由所引权项的主体执行。
   C8（动作描述通讯对象冗余）：检查每个步骤中是否有"接收XXX发送的"、"向XXX发送"、"来自XXX"等外部实体修饰——除非不写会导致不清楚，否则应去掉。
      - ✅ "接收第一请求消息" → PASS
      - ❌ "接收接入网设备发送的第一请求消息" → FAIL（"接入网设备"不写也不影响理解）
      - ⚠️ "向目标第一处理功能实体发送感知测量数据" → 如果"目标第一处理功能实体"是数据目的地，省略后不清楚数据去哪，可保留
   C9（独权主语风格混用）：检查同一独权内主语风格是否一致——全省略 或 全程"所述+主体"回指，不混用。
   C10（步骤编号脱节）：交底书步骤与说明书 S 编号步骤的对应关系是否完整——编号倒序/整步漏写由 verify_coverage.py 脚本判定；此处检查语义层面：若步骤有合并或拆分，交付说明中是否显式列出了对应关系。

  返回 JSON：
  {"checks": {"AM1": "PASS|FAIL|N/A", "AM2": "PASS|FAIL|N/A", "AM6": "PASS|FAIL|N/A", "AM8": "PASS|FAIL|N/A",
              "C1": "PASS|FAIL|N/A", "C2": "PASS|FAIL|N/A", "C3": "PASS|FAIL|N/A", "C4": "PASS|FAIL|N/A",
              "C5": "PASS|FAIL|N/A", "C6": "PASS|FAIL|N/A", "C7": "PASS|FAIL|N/A", "C8": "PASS|FAIL|N/A",
              "C9": "PASS|FAIL|N/A", "C10": "PASS|FAIL|N/A"},
   "warnings": [], "details": "各 FAIL 项的具体位置与修改建议"}

**主 Agent 操作**：读取返回结果。有 FAIL 项时：
- 局部文字类问题（格式、编号、句式、标题）→ 主 Agent 直接修改对应文件，重跑对应门禁；
- 结构性问题（权要布局、说明书缺漏）→ 不热修补（AM4），带修复意见重跑对应 Phase 的 sub agent；
- 全部 PASS 后进入 Phase 5；修复不了的问题如实告知用户，由用户决定是否人工介入。

---

## Phase 5：摘要、最终整合与 DOCX 输出（主 Agent）

由主 Agent 直接处理。摘要为改写权1技术方案核心的轻量任务，不设独立阶段，在本阶段开头顺手完成。

**输入**：
- `output/claims_final.txt`
- `output/specification.txt`
- `references/patent_format.py`（DOCX 生成工具）

**操作**：
0. **撰写摘要**：改写权利要求1的技术方案核心内容，要求：字数 ≤300（中文）；包含发明名称；
   不出现"本申请"、"本发明"、"包括"、"所述"等；领域包案件可参考命中包 boilerplate
   文件的摘要句式（ISAC 包见第八节）。写入 `output/abstract.txt`，
   运行 `scripts/phase_gates/gate_04_abstract.py --abstract output/abstract.txt --title "{发明名称}"`，
   PASS 后继续，FAIL 则修正
1. 按顺序拼接各章节：说明书 → 权利要求书 → 说明书摘要 → 说明书附图（用户确认不要附图的，不含附图章节）
2. 各章节之间插入分页符
3. 调用 `references/patent_format.py` 中的 `PatentDoc` 类生成 DOCX
4. 空行规范：
   - 各章节之间空2行（1个空段 + 分页符）
   - 具体实施方式中装置套话各子节（模块装置/硬件装置/存储介质等）之间空1行
   - 段落之间不额外加空行（由 spacing 控制）
5. 实施例对应关系批注（Phase 3 第5章规则落点）：具体实施方式不写"实施例一/二"标签，
   若需标明某段与交底书哪个实施例/哪条权要的对应关系，调用
   `references/patent_format.py` 的 `add_comment(para, text)` 以修订模式批注标明，不写入正文：
   ```python
   from references.patent_format import PatentDoc, add_comment
   doc.add_body_para("在一种可能的实现方式中，……")
   add_comment(doc.doc.paragraphs[-1], "对应权利要求5；对应图6实施例")
   ```
   （依赖 python-docx >= 1.2.0 原生批注能力）

**门禁**（主 Agent 直接运行，两道依次执行）：
```
python scripts/phase_gates/gate_04_abstract.py --abstract output/abstract.txt --title "{发明名称}"
python scripts/phase_gates/gate_05_final.py --docx {docx_file} --claims output/claims_final.txt --abstract output/abstract.txt
```
gate_04 校验摘要（字数、禁用词、发明名称出现）；gate_05 除文档可读性、章节顺序、
章节非空外，还交叉校验：docx 权项数与 claims_final.txt 一致、发明名称在摘要中出现。
均 PASS 则进入 Phase 6，FAIL 则修正。
（操作 0 已跑过一次 gate_04 作写作期自检；此处为拼接完成后的最终复验，摘要如有改动必须重跑。）

---

## Phase 6：质量评估与修复（Sub Agent）— 必执行

对照评分标准整体评估本次产出，发现明显问题顺手修复。

Tool: task
subagent_type: general
prompt: |
  你是一个专利撰写质量评估代理。

  1. read {evaluation_criteria_file} 获取六维度评分标准
  2. read 以下产出文件：
     - {claims_file}（权利要求书）
     - {spec_file}（说明书）
     - {abstract_file}（摘要）
  3. 按 C（权利要求）/S（说明书）/A（摘要）/F（附图）/FT（格式）/SC（特别检查）
     六个维度逐项评分（1-5 分），每项给出得分理由
     （用户确认不要附图的，F 维度记 N/A，不计入均分与最低分）
  4. 列出明显问题清单（critical_issues）：只收录会导致审查意见、保护范围受损、
     或形式缺陷被驳回的实质问题，不收风格偏好类建议
  5. 每条问题给出具体定位（权项号/章节/句子）与修复建议

  输出 JSON 到 {output_path}：
  {"scores": {"C": 0, "S": 0, "A": 0, "F": 0, "FT": 0, "SC": 0},
   "score_reasons": {"C": "xxx", ...},
   "critical_issues": [{"location": "权3", "problem": "xxx", "fix": "xxx"}],
   "warnings": []}

  最后返回一行：
  STATUS:PASS|FAIL  AVG_SCORE:N.N  MIN_SCORE:N  CRITICAL:N  WARNINGS:N

**主 Agent 修复操作**（读取 evaluation JSON 后执行）：
- 无任何 critical_issues 且六维度均 ≥3 → 直接交付
- 有 critical_issues 或某维度 ≤2 → 顺手修复：
  - 局部文字类问题（禁用词、格式、编号、摘要措辞）→ 主 Agent 直接修改对应文件，
    改后重跑对应门禁（权要改动重跑 gate_02，说明书改动重跑 gate_03+verify_coverage，
    摘要改动重跑 gate_04）
  - 结构性问题（独权保护范围、权要布局、说明书整体缺漏）→ 不热修补（AM4），
    带修复意见重跑对应 Phase 的 sub agent，再走门禁
- 修复完成后复核：重新运行一次 Phase 6（仅一轮复核，仍不通过则如实告知用户，
  由用户决定是否人工介入）

---

## Phase 6R：专利全文评审（Sub Agent）— 场景 D 专用

只评审、不修复。脚本门禁作检查器复用，sub agent 负责语义评审与报告产出。
用户随后要求按报告修改的，按问题所在文件转入场景 A（权要）或场景 C（全文）的对应 Phase。

**主 Agent 前置操作**（调起 sub agent 前执行）：
1. Phase 0 已拆分出 `output/claims_review.txt` 与 `output/spec_review.txt`
2. 直跑三道脚本，原始 JSON 输出汇总写入 `output/gate_results.json`：
   - `python scripts/phase_gates/gate_02_claims.py --claims output/claims_review.txt`
   - `python scripts/phase_gates/gate_03_specification.py --spec output/spec_review.txt --claims output/claims_review.txt --title "{稿件中的发明名称}"`（全文无附图说明章节的，追加 `--no-figures`）
   - `python scripts/verify_coverage.py --disclosure output/disclosure.txt --specification output/spec_review.txt --analysis {disclosure_analysis_file}`
   - 拆出了 `output/abstract_review.txt` 的，加跑 `python scripts/phase_gates/gate_04_abstract.py --abstract output/abstract_review.txt --title "{稿件中的发明名称}"`
   - 脚本 FAIL 或报错均不阻断评审，原始输出原样收入 gate_results.json，供 sub agent 引用

Tool: task
subagent_type: general
prompt: |
  你是一个专利全文评审代理。你的任务是【只评审，不修复】用户的专利申请全文。

  【输入文件】（先 read 再评审）
  - {claims_review_file} / {spec_review_file} — 拆分出的权要与说明书
  - {abstract_review_file} — 拆分出的说明书摘要（全文含摘要时传入；无则本项缺省，A 维度记 N/A）
  - {disclosure_analysis_file} — 交底书分析结果（innovation_points 为发明点清单）
  - {gate_results_file} — 门禁脚本原始输出（gate_02 / gate_03 / gate_04 / verify_coverage 的 JSON）
  - {anti_patterns_file} — 反模式库（AM1–AM9 逐项对照）
  - {evaluation_criteria_file} — 六维度评分标准
  - {verification_protocols_file} — 显式验证协议（VP1–VP5、VP7、VP9、VP10 适用）
  - {review_template_file} — 评审报告模板（references/review_templates.md）
  - （领域包案件）命中包的 boilerplate / claims-strategy 文件

  【任务】
  1. 通读门禁原始输出，把脚本查出的形式问题原样收录（不重复扫描）
  2. 反模式对照：AM1–AM9 逐项检查（用户确认不要附图的，AM8(c) 记 N/A）
  3. 语义评审：VP1–VP5、VP7、VP9、VP10 逐项执行
  4. 六维度评分（C/S/A/F/FT/SC，1–5 分），每项给出得分理由
     （全文无附图的，F 维度记 N/A，不计入均分与最低分）
  5. 所有问题记录：位置（权项号/章节/句子）/ 描述 / 依据（门禁项/反模式/VP）/
     严重程度（高/中/低）/ 修改建议

  【输出】按 review_template_file 的"全文评审报告"模板写入 {report_file}。
  严重程度分级：高＝可能导致驳回或保护范围实质受损；中＝影响文件质量但可补救；低＝建议性优化。

  最后返回一行：
  STATUS:PASS|FAIL  AVG_SCORE:N.N  HIGH:N  MID:N  LOW:N
  （HIGH>0 时 STATUS 必须为 FAIL）

**主 Agent 收尾操作**（sub agent 返回后执行）：
1. 用户提供的是 docx 全文的，用 `references/patent_format.py` 的 add_comment
   把高严重度问题以批注标到原文对应段落，输出批注版 docx
2. 交付：评审报告 + （如有）批注版全文；不修改全文本身

⚠️ 评审场景中 STATUS:FAIL 与门禁 FAIL 均不阻断交付、不进入修复循环——
FAIL 仅表示存在高严重度问题，明细全部留在报告中交用户定夺。

---

## 反模式库快速导航

| 场景 | 参考反模式 | 说明 |
|------|-----------|------|
| 修改指定权项内的文本 | AM1 | 注意不要全局替换超出范围 |
| 撰写说明书实施例 | AM2 | 不要静默合并方法步骤 |
| 做验证检查 | AM3 | 用脚本，不靠记忆 |
| 修复/补内容 | AM4 | 重跑上游，不热修补 |
| 感觉规则太多记不住 | AM5 | 脚本化的不用记 |
| 输出内容海量 | AM6 | 分多次输出 |
| 用户指出格式/规则问题 | AM7 | 能脚本化的不要写文字 |
| 说明书出现独立标题/编号小标题 | AM8 | 标题白名单 + gate_03 脚本防线 |
| 附图说明句式参差 | AM9 | 统一句式，零成本修复 |

具体反模式条目请 read `references/anti_patterns.md`。

---

## 参考资料索引

| 文件 | 用途 | 何时加载 |
|------|------|---------|
| `references/claim_rules.md` | 权利要求撰写细则 | Phase 2 sub agent 通过 read 加载 |
| `references/specification_templates.md` | 说明书模板 | Phase 3 sub agent 通过 read 加载 |
| `references/claim_layout_examples.md` | 权利要求布局范例 | Phase 2 需要范例时 read |
| `references/anti_patterns.md` | 反模式库 | Phase 4 sub agent 通过 read 加载 |
| `references/verification_protocols.md` | 显式验证协议（开头含门禁 FAIL → VP 映射表） | 门禁 FAIL 后 read，先查映射表 |
| `references/sep_mapping_rules.md` | SEP 课题映射规则 | Phase 1.5 sub agent 通过 read 加载 |
| `references/evaluation_criteria.md` | 六维度评分标准 | Phase 6 sub agent 通过 read 加载；用户要求评估时也可单独 read |
| `references/review_templates.md` | 评审报告模板（权要评审/全文评审） | Phase 2R / 6R sub agent 通过 read 加载（场景 B/D） |
| `references/huawei_guidelines.md` | 华为撰写指南 | 用户要求参考时 read |
| `references/patent_format.py` | DOCX 生成工具 | Phase 5 |
| `references/domains/*/pack.md` | 领域包路由元信息（命中关键词/文件清单） | Phase 1 后扫描，命中即按清单加载 |
| `references/domains/isac/disclosure-analysis.md` | ISAC 交底书信息清单+发明点类型库 | Phase 1，ISAC 案件 |
| `references/domains/isac/claims-strategy.md` | ISAC 权利要求布局策略 | Phase 2，ISAC 案件 |
| `references/domains/isac/boilerplate.md` | ISAC 说明书套话库+中英对照词汇 | Phase 3，ISAC 案件 |
| `references/domains/isac/figures.md` | 附图版式规范（四类图） | Phase 3.5，需要附图时 |

---

## 脚本清单

| 脚本 | 功能 | 调用阶段 |
|------|------|---------|
| `scripts/count_claims.py` | 权利要求数量与独权计数 | gate_02 |
| `scripts/check_claim_rules.py` | 格式检查+禁用词+全品类检验 | gate_02 |
| `scripts/verify_claim_sequence.py` | 编号连续性+引用关系校验 | gate_02 |
| `scripts/verify_coverage.py` | 交底书→说明书覆盖度反向校验 | gate_03；场景 D 作检查器直跑 |
| `scripts/utils/docx_parser.py` | DOCX 文本提取工具 | gate_05 |
| `scripts/phase_gates/gate_01_preprocess.py` | 文档完整性门禁 | Phase 0 |
| `scripts/phase_gates/gate_01.5_sep.py` | SEP 分析门禁 | Phase 1.5 |
| `scripts/phase_gates/gate_02_claims.py` | 权利要求门禁（汇总：数量/格式/序号；--coverage 覆盖表校验） | Phase 2 / 2.5；场景 B/D 作检查器直跑（不加 --coverage） |
| `scripts/phase_gates/gate_03_specification.py` | 说明书门禁（章节/套话/步骤/背景纯净度/独立标题扫描/发明内容厚度；--no-figures 跳过附图说明要求） | Phase 3；场景 D 作检查器直跑 |
| `scripts/phase_gates/gate_04_abstract.py` | 摘要门禁 | Phase 5（摘要步）；场景 D 全文含摘要时作检查器直跑 |
| `scripts/phase_gates/gate_05_final.py` | 最终文档门禁 | Phase 5 |
