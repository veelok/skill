#!/usr/bin/env python3
"""
count_claims.py — 权利要求数量与独立权项计数（CN 案件口径）
规则：独立权项数不限；总权项数 ≤ 30，特别复杂的案子 ≤ 40

Usage:
    python scripts/count_claims.py <claims_file.txt>
Returns:
    JSON: { total, independent_count, dependent_count, status, message }
"""

import re
import sys
import json


def split_claims(content):
    """按权项编号切分为权项块，返回 [(claim_num, block_text)]"""
    lines = content.split('\n')
    header_re = re.compile(r'^(\d+)[\.\、]\s*')
    claims = []
    current = None
    for line in lines:
        m = header_re.match(line.strip())
        if m:
            if current:
                claims.append(current)
            current = [int(m.group(1)), [line.strip()]]
        elif current is not None and line.strip():
            current[1].append(line.strip())
    if current:
        claims.append(current)
    return [(num, '\n'.join(parts)) for num, parts in claims]


def count_claims(filepath):
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
    except FileNotFoundError:
        return {"status": "ERROR", "message": f"File not found: {filepath}"}
    except Exception as e:
        return {"status": "ERROR", "message": str(e)}

    claims = split_claims(content)
    if not claims:
        return {"status": "ERROR", "message": "No claims found in file"}

    total = len(claims)
    independent_count = 0
    dependent_count = 0
    for num, block in claims:
        # 从属权利要求以"根据权利要求X所述的"起头；
        # 回引型权要（装置/介质等）中的"如权利要求X至Y中任一项所述的方法"不构成从属关系
        first_line = block.split('\n')[0]
        if re.search(r'根据权利要求\s*\d+', first_line):
            dependent_count += 1
        else:
            independent_count += 1

    status = "PASS"
    messages = []

    if total > 40:
        status = "FAIL"
        messages.append(f"总权项数 ({total}) 超过特别复杂案件的上限 40")
    elif total > 30:
        status = "WARN"
        messages.append(f"总权项数 ({total}) 超过一般上限 30（仅特别复杂的案子允许至 40）")

    return {
        "status": status,
        "total": total,
        "independent_count": independent_count,
        "dependent_count": dependent_count,
        "message": "; ".join(messages) if messages else "All claim count checks passed"
    }


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(json.dumps({"status": "ERROR", "message": "Usage: python count_claims.py <claims_file.txt>"}))
        sys.exit(1)
    result = count_claims(sys.argv[1])
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if result["status"] == "FAIL":
        sys.exit(1)
