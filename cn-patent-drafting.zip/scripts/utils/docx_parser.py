#!/usr/bin/env python3
"""
docx_parser.py — DOCX 文本提取工具

Usage:
    python scripts/utils/docx_parser.py <file.docx>
Returns:
    JSON: { status, text_content, para_count, char_count }
"""

import sys
import json
import os

def extract_text(filepath):
    try:
        from docx import Document
    except ImportError:
        return {"status": "ERROR", "message": "python-docx not installed. Run: pip install python-docx"}
    
    try:
        doc = Document(filepath)
        paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
        text = '\n'.join(paragraphs)
        return {
            "status": "PASS",
            "text_content": text,
            "para_count": len(paragraphs),
            "char_count": len(text),
            "file": os.path.basename(filepath)
        }
    except Exception as e:
        return {"status": "ERROR", "message": str(e)}

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(json.dumps({"status": "ERROR", "message": "Usage: python docx_parser.py <file.docx>"}))
        sys.exit(1)
    result = extract_text(sys.argv[1])
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if result["status"] == "ERROR":
        sys.exit(1)
