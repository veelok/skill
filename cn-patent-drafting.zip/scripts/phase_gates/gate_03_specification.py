#!/usr/bin/env python3
"""
gate_03_specification.py — 阶段3门禁：说明书校验

校验项：
1. 章节完整性：五个必需章节（技术领域/背景技术/发明内容/附图说明/具体实施方式）
   必须以独立标题行出现（行首匹配、短行），且按法定顺序排列——
   避免正文中提及"技术领域"四字造成的误判。
2. 章节非空：每个章节标题后至少有一段实质内容。
3. 装置套话完整性：在"具体实施方式"部分内检查 10 个套话要素。
4. 方法步骤存在性：S101/步骤1 等编号步骤。
5. 背景技术纯净度：不出现"本申请/本发明/其特征在于"。
6. 独立标题扫描：白名单之外的短行标题（含"XX侧流程""装置实施例""替代方案"等变体）与 markdown ** 标记。
7. 发明内容厚度（--claims 时启用）：体量比 + 有益效果标记数；
   并检查"（对应权利要求X）"标注（禁）、第一方面后有益效果段落（必须另起一段）。
8. 实施例编号标签扫描："实施例一/第一实施例"等（禁，应"在一种可能的实现方式中"成段）。
9. 技术领域一致性（--title 时启用）："尤其涉及"后须与发明标题逐字一致。

Usage:
    python scripts/phase_gates/gate_03_specification.py --spec <specification.txt> [--bg <background_section.txt>] [--no-figures]
Returns:
    JSON: { status, sub_checks[], message }
    说明：sub_check 为 WARN 时不阻塞整体 PASS（与 gate_02 口径一致），仅 FAIL 阻塞。
"""

import sys
import json
import argparse
import os
import re

REQUIRED_CHAPTERS = ["技术领域", "背景技术", "发明内容", "附图说明", "具体实施方式"]

# 标题白名单：说明书中允许以独立短行存在的标题（章节标题 + 发明内容三个文字标题 + DOCX 分册页标题）
HEADING_WHITELIST = set(REQUIRED_CHAPTERS) | {
    "说明书", "权利要求书", "说明书摘要", "说明书附图",
}
# 点名禁止的独立标题（整行精确匹配即违规）
HEADING_BLACKLIST_EXACT = {
    "术语解释", "应用场景", "系统架构", "方法实施例", "装置实施例",
    "替代方案", "SEP扩展", "扩展方案", "替代实现", "可选方案",
}
# 疑似标题的短行后缀（≤14字且以此结尾 → 视为独立标题违规）
HEADING_SUFFIX = ("侧流程", "流程", "实施例", "方案", "架构", "扩展", "介绍", "概述")

BOILERPLATE_KEYS = [
    ("模块装置（处理单元）", "处理单元"),
    ("模块装置（收发单元）", "收发单元"),
    ("硬件装置", "硬件"),
    ("计算机可读存储介质", "计算机可读存储介质"),
    ("计算机程序产品", "计算机程序产品"),
    ("芯片", "芯片"),
    ("通信系统", "通信系统"),
    ("处理器列举（CPU等）", "中央处理器"),
    ("总线互连", "总线"),
    ("功能单元集成声明", "集成在一个处理单元"),
]


def find_chapter_headings(lines):
    """按行首标题匹配章节：(章节名, 行号)，要求整行基本就是标题本身"""
    headings = []
    for i, line in enumerate(lines):
        s = line.strip().strip('【】[]#* ')
        for ch in REQUIRED_CHAPTERS:
            # 整行即标题（允许尾随标点/空格），长度接近章节名
            if s.startswith(ch) and len(s) <= len(ch) + 4:
                headings.append((ch, i))
                break
    return headings


def check_specification(spec_file, bg_file=None, claims_file=None, title=None, no_figures=False):
    if not os.path.exists(spec_file):
        return {"status": "FAIL", "message": f"Specification file not found: {spec_file}"}

    try:
        with open(spec_file, 'r', encoding='utf-8') as f:
            content = f.read()
    except Exception as e:
        return {"status": "ERROR", "message": str(e)}

    lines = content.split('\n')
    sub_checks = []

    # 1. 章节完整性（标题行匹配）
    # no_figures：用户在 Phase 0 确认不要附图时，附图说明章节不作要求
    required = [c for c in REQUIRED_CHAPTERS if not (no_figures and c == "附图说明")]
    headings = find_chapter_headings(lines)
    found = [ch for ch, _ in headings]
    missing = [ch for ch in required if ch not in found]
    sub_checks.append({
        "check": "chapter_completeness",
        "status": "PASS" if not missing else "FAIL",
        "found": found,
        "missing": missing,
        "detail": f"标题行命中: {len(found)}/5"
    })

    # 2. 章节顺序 + 非空
    if not missing:
        # 仅必需章节参与判定：--no-figures 时稿件残留"附图说明"标题不再报错；
        # 同一章节标题重复命中时只取第一次出现
        req_heads = []
        seen = set()
        for ch, ln in headings:
            if ch in required and ch not in seen:
                req_heads.append((ch, ln))
                seen.add(ch)
        positions = [ln for _, ln in sorted(req_heads, key=lambda x: required.index(x[0]))]
        ordered = positions == sorted(positions)
        non_empty = True
        empty_chapters = []
        sorted_heads = sorted(req_heads, key=lambda x: x[1])
        for idx, (ch, ln) in enumerate(sorted_heads):
            end = sorted_heads[idx + 1][1] if idx + 1 < len(sorted_heads) else len(lines)
            body = ''.join(l.strip() for l in lines[ln + 1:end])
            if len(body) < 20:
                non_empty = False
                empty_chapters.append(ch)
        status = "PASS" if (ordered and non_empty) else "FAIL"
        detail = []
        if not ordered:
            detail.append("章节顺序错误（应为：" + "→".join(required) + "）")
        if not non_empty:
            detail.append(f"章节内容为空或过短: {empty_chapters}")
        sub_checks.append({
            "check": "chapter_order_and_content",
            "status": status,
            "detail": "; ".join(detail) if detail else "章节顺序正确且均有实质内容"
        })

    # 3. 装置套话完整性（限定在具体实施方式部分内检查）
    emb_start = content.find("具体实施方式")
    emb_text = content[emb_start:] if emb_start >= 0 else content
    missing_bp = [label for label, kw in BOILERPLATE_KEYS if kw not in emb_text]
    bp_status = "PASS" if not missing_bp else ("WARN" if len(missing_bp) <= 2 else "FAIL")
    sub_checks.append({
        "check": "boilerplate_completeness",
        "status": bp_status,
        "found": len(BOILERPLATE_KEYS) - len(missing_bp),
        "total": len(BOILERPLATE_KEYS),
        "missing": missing_bp,
        "detail": f"套话要素: {len(BOILERPLATE_KEYS) - len(missing_bp)}/{len(BOILERPLATE_KEYS)}"
    })

    # 4. 方法步骤存在性
    steps = set(re.findall(r'(?:S\s*\d{3}|步骤\s*\d+)', content))
    sub_checks.append({
        "check": "method_steps",
        "status": "PASS" if len(steps) >= 1 else "FAIL",
        "step_count": len(steps),
        "detail": f"发现 {len(steps)} 个方法步骤编号"
    })

    # 5. 背景技术纯净度
    bg_content = ""
    if bg_file and os.path.exists(bg_file):
        with open(bg_file, 'r', encoding='utf-8') as f:
            bg_content = f.read()
    else:
        bg_head = next((ln for ch, ln in headings if ch == "背景技术"), None)
        sm_head = next((ln for ch, ln in headings if ch == "发明内容"), None)
        if bg_head is not None and sm_head is not None and sm_head > bg_head:
            bg_content = '\n'.join(lines[bg_head:sm_head])
    if bg_content:
        invention_refs = re.findall(r'(本申请|本发明|本方案|其特征在于)', bg_content)
        sub_checks.append({
            "check": "background_purity",
            "status": "FAIL" if invention_refs else "PASS",
            "detail": f"背景技术中出现 {len(invention_refs)} 处自我指代/权要式语言" if invention_refs else "背景技术干净"
        })

    # 6. 独立标题与 markdown 标记扫描（反模式 AM8 的脚本化防线）
    heading_hits = []
    md_marker_count = 0
    for i, line in enumerate(lines):
        raw = line.strip()
        if not raw:
            continue
        if '**' in raw:
            md_marker_count += 1
        s = raw.strip('【】[]#* ')
        if s in HEADING_WHITELIST:
            continue
        if s in HEADING_BLACKLIST_EXACT:
            heading_hits.append(f"第{i+1}行: {s}")
        elif len(s) <= 14 and s.endswith(HEADING_SUFFIX):
            heading_hits.append(f"第{i+1}行: {s}")
    detail6 = []
    if heading_hits:
        detail6.append(f"独立标题 {len(heading_hits)} 处: {heading_hits[:5]}")
    if md_marker_count:
        detail6.append(f"markdown ** 标记 {md_marker_count} 处")
    sub_checks.append({
        "check": "no_illegal_headings",
        "status": "FAIL" if detail6 else "PASS",
        "detail": "; ".join(detail6) if detail6 else "无独立标题、无 markdown 标记"
    })

    # 7. 发明内容厚度（需 --claims）：体量比例 + 有益效果标记
    if claims_file and os.path.exists(claims_file):
        with open(claims_file, 'r', encoding='utf-8') as f:
            claims_text = f.read()
        sm_head = next((ln for ch, ln in headings if ch == "发明内容"), None)
        fg_head = next((ln for ch, ln in headings if ch == "附图说明"), None)
        if sm_head is not None and fg_head is not None and fg_head > sm_head:
            sm_lines = [l.strip() for l in lines[sm_head + 1:fg_head] if l.strip()]
            sm_body = ''.join(sm_lines)
            # 禁"（对应权利要求X）"式说明性标注
            ref_marks = re.findall(r'[（(]对应权利要求[^）)]*[）)]|[（(]对应权\d+[^）)]*[）)]', sm_body)
            sub_checks.append({
                "check": "summary_no_claim_ref_marks",
                "status": "FAIL" if ref_marks else "PASS",
                "detail": (f"发明内容含说明性标注 {len(ref_marks)} 处，如: {ref_marks[:3]}" if ref_marks
                           else "无'（对应权利要求X）'标注")
            })
            # 第一方面段落后必须紧跟有益效果段落
            eff_re = r'(从而|因此|进而|避免|减少|降低|提高|提升|节省)'
            fa_idx = next((i for i, l in enumerate(sm_lines) if '第一方面' in l), None)
            # 从第一方面段落后逐段扫描：遇到下一个方面段落即停（说明方法方面没有自己的效果段）
            eff_ok = False
            if fa_idx is not None:
                for l in sm_lines[fa_idx + 1:]:
                    if re.search(r'第[一二三四五六七八九十]+方面', l):
                        break
                    if re.search(eff_re, l):
                        eff_ok = True
                        break
            sub_checks.append({
                "check": "summary_first_aspect_effect",
                "status": "PASS" if eff_ok else "FAIL",
                "detail": ("第一方面改写内容后有有益效果段落" if eff_ok else
                           "未找到'第一方面'段落，或其后的自然段无有益效果——"
                           "方法独权改写内容之后必须另起一段写有益效果")
            })
            cl_len = len(''.join(claims_text.split()))
            ratio = len(sm_body) / cl_len if cl_len else 0
            effects = re.findall(r'(从而|因此|进而|避免|减少|降低|提高|提升|节省)', sm_body)
            if ratio < 0.35:
                st = "FAIL"
            elif ratio < 0.6 or len(effects) < 3:
                st = "WARN"
            else:
                st = "PASS"
            sub_checks.append({
                "check": "summary_thickness",
                "status": st,
                "detail": f"发明内容/权要体量比 {ratio:.2f}（阈值：≥0.6 佳，<0.35 过薄），"
                          f"有益效果标记 {len(effects)} 处（应≥3）"
            })

    # 8. "实施例一/二"编号标签扫描（全文）：编号区分实施例不利于审通答复时的特征组合
    emb_labels = re.findall(r'第[一二三四五六七八九十]+实施例|实施例[一二三四五六七八九十\d]+', content)
    sub_checks.append({
        "check": "no_embodiment_labels",
        "status": "FAIL" if emb_labels else "PASS",
        "detail": (f"发现实施例编号标签 {len(emb_labels)} 处，如: {emb_labels[:5]}——"
                   "应改为'在一种可能的实现方式中'自然成段" if emb_labels else
                   "无实施例编号标签")
    })

    # 9. 技术领域与发明标题一致性（--title 时启用）
    if title:
        tf_head = next((ln for ch, ln in headings if ch == "技术领域"), None)
        bg_head = next((ln for ch, ln in headings if ch == "背景技术"), None)
        if tf_head is not None and bg_head is not None and bg_head > tf_head:
            tf_body = ''.join(l.strip() for l in lines[tf_head + 1:bg_head])
            t = re.sub(r'\s+', '', title)
            expect = '尤其涉及' + t
            ok = expect in tf_body.replace(' ', '')
            sub_checks.append({
                "check": "tech_field_title_match",
                "status": "PASS" if ok else "FAIL",
                "detail": "技术领域与发明标题一致" if ok else
                          f"技术领域'尤其涉及'后应为发明标题原文：…尤其涉及{t}"
            })

    # 整体口径：FAIL 阻塞，WARN 不阻塞（与 gate_02 一致）
    all_pass = all(s["status"] in ("PASS", "WARN") for s in sub_checks)

    return {
        "status": "PASS" if all_pass else "FAIL",
        "sub_checks": sub_checks,
        "message": "All specification checks passed" if all_pass else "See sub_checks for details"
    }


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--spec', required=True)
    parser.add_argument('--bg', default=None)
    parser.add_argument('--claims', default=None, help='权要书，用于发明内容厚度等检查')
    parser.add_argument('--title', default=None, help='发明名称，用于技术领域一致性检查')
    parser.add_argument('--no-figures', action='store_true', help='用户确认不要附图：附图说明章节不作要求')
    args = parser.parse_args()

    result = check_specification(args.spec, args.bg, args.claims, args.title, args.no_figures)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if result["status"] == "FAIL":
        sys.exit(1)
