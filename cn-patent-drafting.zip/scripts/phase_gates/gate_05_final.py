#!/usr/bin/env python3
"""
gate_05_final.py — 终检门禁（Phase 5 整合后）：最终文档校验

Usage:
    python scripts/phase_gates/gate_05_final.py --docx <patent_application.docx>
        [--claims claims_final.txt] [--abstract abstract.txt]
Returns:
    JSON: { status, checks, message }

交叉校验（可选参数启用）：
    --claims   比对 docx 权利要求书章节与 claims_final.txt 的权项数量
    --abstract 校验发明名称（docx 说明书首行标题）在摘要中出现
"""

import sys
import json
import argparse
import os
import re

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

def extract_claim_numbers(text):
    """提取权项编号：行首 "N." 或 "N．" """
    import re
    return [int(m.group(1)) for m in re.finditer(r'^\s*(\d{1,2})\s*[.．、]', text, re.MULTILINE)]


def check_final(docx_file, claims_file=None, abstract_file=None):
    if not os.path.exists(docx_file):
        return {"status": "FAIL", "message": f"DOCX file not found: {docx_file}"}
    
    import subprocess
    
    checks = {}
    
    # 1. Check DOCX can be opened
    parser_path = os.path.join(os.path.dirname(__file__), '..', 'utils', 'docx_parser.py')
    try:
        result = subprocess.run(
            [sys.executable, parser_path, docx_file],
            capture_output=True, text=True, timeout=30
        )
        parsed = json.loads(result.stdout)
        if parsed.get("status") == "PASS":
            checks["docx_readable"] = True
            text_content = parsed.get("text_content", "")
        else:
            checks["docx_readable"] = False
            text_content = ""
    except Exception as e:
        checks["docx_readable"] = False
        text_content = ""
    
    if not checks.get("docx_readable"):
        return {"status": "FAIL", "checks": checks, "message": "DOCX file cannot be read"}

    # 页标题按专利格式逐字加空格（如"说    明    书"），
    # 统一去掉行内空白（保留换行）再做章节定位与权项提取
    text_content = '\n'.join(re.sub(r'[^\S\n]+', '', ln) for ln in text_content.splitlines())

    # 2. Check chapter order
    required_sections = ["说明书", "权利要求书", "说明书摘要"]
    section_positions = []
    for section in required_sections:
        pos = text_content.find(section)
        section_positions.append((section, pos))
    
    # Check that sections appear in order
    in_order = True
    for i in range(1, len(section_positions)):
        if section_positions[i][1] < section_positions[i-1][1]:
            in_order = False
            break
    
    checks["chapter_order_correct"] = in_order and all(p[1] >= 0 for p in section_positions)
    
    # 3. Check all chapters non-empty
    checks["all_chapters_non_empty"] = True
    # Rough check: at least some content after each section title
    for section, pos in section_positions:
        if pos >= 0:
            next_section_pos = len(text_content)
            for s2, p2 in section_positions:
                if p2 > pos and p2 < next_section_pos:
                    next_section_pos = p2
            section_content = text_content[pos:next_section_pos].strip()
            if len(section_content) < 50:  # Title + very little content
                checks["all_chapters_non_empty"] = False
    
    # 4. 交叉校验：docx 权项数 vs claims_final.txt 权项数
    if claims_file:
        try:
            with open(claims_file, 'r', encoding='utf-8') as f:
                claims_text = f.read()
            sec_start = text_content.find("权利要求书")
            sec_end = text_content.find("说明书摘要", sec_start)
            docx_claims_section = text_content[sec_start:sec_end if sec_end > 0 else len(text_content)]
            n_docx = max(extract_claim_numbers(docx_claims_section) or [0])
            n_file = max(extract_claim_numbers(claims_text) or [0])
            checks["claim_count_match"] = (n_docx == n_file and n_docx > 0)
            checks["claim_count_detail"] = f"docx: {n_docx} 项, claims_file: {n_file} 项"
        except FileNotFoundError:
            checks["claim_count_match"] = False
            checks["claim_count_detail"] = f"claims file not found: {claims_file}"

    # 5. 交叉校验：发明名称一致性（docx 说明书首行标题应出现在摘要中）
    if abstract_file:
        try:
            with open(abstract_file, 'r', encoding='utf-8') as f:
                abstract_text = f.read()
            spec_pos = text_content.find("说明书")
            title = ""
            for line in text_content[spec_pos:].splitlines()[1:8]:
                line = line.strip()
                if line and line not in ("权利要求书", "说明书摘要") and len(line) >= 6:
                    title = line
                    break
            checks["title_in_abstract"] = bool(title) and title in abstract_text
            checks["title_detail"] = title or "(未能提取发明名称)"
        except FileNotFoundError:
            checks["title_in_abstract"] = False
            checks["title_detail"] = f"abstract file not found: {abstract_file}"

    all_pass = all(v for k, v in checks.items() if isinstance(v, bool))
    
    return {
        "status": "PASS" if all_pass else "FAIL",
        "checks": checks,
        "message": "All final document checks passed" if all_pass else "See checks for details"
    }

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--docx', required=True)
    parser.add_argument('--claims', default=None, help='claims_final.txt，启用权项数交叉校验')
    parser.add_argument('--abstract', default=None, help='abstract.txt，启用发明名称一致性校验')
    args = parser.parse_args()
    
    result = check_final(args.docx, args.claims, args.abstract)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if result["status"] == "FAIL":
        sys.exit(1)
