#!/usr/bin/env python3
"""
gate_02_claims.py — 阶段2门禁：权利要求校验（汇总所有子检查）

Usage:
    python scripts/phase_gates/gate_02_claims.py --claims <claims_final.txt>
Returns:
    JSON: { status, sub_checks[], message }
"""

import sys
import json
import argparse
import os

# Import check scripts
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

def run_check(script_name, *args):
    """Run a check script and return its result"""
    script_path = os.path.join(os.path.dirname(__file__), '..', script_name)
    if not os.path.exists(script_path):
        return {"status": "ERROR", "message": f"Script not found: {script_path}"}
    
    import subprocess
    try:
        result = subprocess.run(
            [sys.executable, script_path] + list(args),
            capture_output=True, text=True, timeout=30
        )
        return json.loads(result.stdout)
    except Exception as e:
        return {"status": "ERROR", "message": str(e)}

def check_coverage(coverage_file, analysis_file, claims_file):
    """Phase 2.5 覆盖表校验：表1权项号连续无缺；表2发明点全覆盖"""
    import re
    sub = []
    if not os.path.exists(coverage_file):
        return [{"check": "coverage_tables", "status": "FAIL",
                 "detail": f"coverage file not found: {coverage_file}"}]
    with open(coverage_file, 'r', encoding='utf-8') as f:
        cov = f.read()
    with open(claims_file, 'r', encoding='utf-8') as f:
        claims_text = f.read()
    claim_nums = set(int(n) for n in re.findall(r'^\s*(\d{1,2})\s*[.．、]', claims_text, re.M))
    rows = []
    for line in cov.split('\n'):
        s = line.strip()
        if s.startswith('|') and s.endswith('|'):
            cells = [c.strip() for c in s.strip('|').split('|')]
            if cells and not set(cells[0]) <= set('-: '):
                rows.append(cells)
    # 依表头切分两张表：含"权项+类型"的为表1表头，含"覆盖状态"的为表2表头
    cur = None
    t1_nums = set()
    t2_rows = []
    for c in rows:
        joined = ''.join(c)
        if '权项' in c[0] and any('类型' in x for x in c[1:]):
            cur = 't1'; continue
        if any('覆盖状态' in x for x in c):
            cur = 't2'; continue
        if cur == 't1' and c[0].isdigit():
            t1_nums.add(int(c[0]))
        elif cur == 't2' and c[0] and not c[0].isdigit():
            t2_rows.append(c)
    missing_in_t1 = sorted(claim_nums - t1_nums)
    extra_in_t1 = sorted(t1_nums - claim_nums)
    ok1 = not missing_in_t1 and not extra_in_t1
    sub.append({
        "check": "coverage_table1_claims",
        "status": "PASS" if ok1 else "FAIL",
        "detail": "表1权项号与权要书一一对应" if ok1 else
                  f"表1缺权项{missing_in_t1 or '无'}，多出权项{extra_in_t1 or '无'}"
    })
    uncovered = [c[0] for c in t2_rows if any('未覆盖' in x for x in c[1:])]
    detail2 = f"表2发明点行数{len(t2_rows)}，未覆盖{len(uncovered)}"
    status2 = "PASS" if not uncovered else "FAIL"
    if analysis_file and os.path.exists(analysis_file):
        try:
            with open(analysis_file, 'r', encoding='utf-8') as f:
                ana = json.load(f)
            n_innov = len(ana.get("innovation_points", []))
            if n_innov and len(t2_rows) != n_innov:
                status2 = "FAIL"
                detail2 += f"；与交底书分析的发明点数{n_innov}不一致"
        except Exception:
            pass
    if uncovered:
        detail2 += f"；未覆盖发明点: {uncovered}"
    sub.append({"check": "coverage_table2_innovations", "status": status2, "detail": detail2})
    return sub


def check_claims(claims_file):
    if not os.path.exists(claims_file):
        return {"status": "FAIL", "message": f"Claims file not found: {claims_file}"}
    
    sub_checks = []
    
    # 1. Count claims
    count_result = run_check('count_claims.py', claims_file)
    sub_checks.append({
        "check": "claim_count",
        "status": count_result.get("status", "ERROR"),
        "detail": f"{count_result.get('total', 0)} claims, {count_result.get('independent_count', 0)} independent"
    })
    
    # 2. Format check
    format_result = run_check('check_claim_rules.py', claims_file)
    violations = format_result.get("violations", [])
    sub_checks.append({
        "check": "claim_format",
        "status": format_result.get("status", "ERROR"),
        "violations": len(violations),
        "detail": "; ".join(v.get("rule", "") for v in violations) if violations else "OK"
    })
    
    # 3. Sequence check
    seq_result = run_check('verify_claim_sequence.py', claims_file)
    errors = seq_result.get("errors", [])
    sub_checks.append({
        "check": "claim_sequence",
        "status": seq_result.get("status", "ERROR"),
        "detail": f"Range: {seq_result.get('claim_range', 'N/A')}, Errors: {seq_result.get('total_errors', 0)}"
    })
    
    # Overall: PASS if all sub-checks are PASS or WARN (only FAIL blocks)
    all_pass = all(s["status"] in ("PASS", "WARN") for s in sub_checks)
    
    return {
        "status": "PASS" if all_pass else "FAIL",
        "sub_checks": sub_checks,
        "message": "All claim checks passed" if all_pass else "One or more claim checks failed"
    }

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--claims', required=True)
    parser.add_argument('--coverage', default=None, help='Phase 2.5 产出的 claims_coverage.md')
    parser.add_argument('--analysis', default=None, help='交底书分析 JSON（校验发明点行数）')
    args = parser.parse_args()

    result = check_claims(args.claims)
    if args.coverage:
        cov_checks = check_coverage(args.coverage, args.analysis, args.claims)
        result["sub_checks"].extend(cov_checks)
        if any(s["status"] == "FAIL" for s in cov_checks):
            result["status"] = "FAIL"
            result["message"] = "Coverage table checks failed"
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if result["status"] == "FAIL":
        sys.exit(1)
