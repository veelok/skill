#!/usr/bin/env python3
"""
gate_01.5_sep.py — SEP 分析门禁

校验 sep_analysis.json（schema 见 SKILL.md Phase 1.5）：
- standard_matches：非空列表
- extension_suggestions：非空列表
- source 为"提案依据"的扩展必须给出 proposal_ref（提案编号）

Usage:
    python scripts/phase_gates/gate_01.5_sep.py --sep <sep_analysis.json>
Returns:
    JSON: { status, checks, message }
"""

import sys
import json
import argparse
import os


def check_sep(sep_file):
    try:
        with open(sep_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
    except FileNotFoundError:
        return {"status": "ERROR", "message": f"SEP file not found: {sep_file}"}
    except json.JSONDecodeError:
        return {"status": "ERROR", "message": f"Invalid JSON in SEP file: {sep_file}"}

    checks = {
        "has_standard_matches": False,
        "has_extensions": False,
        "proposal_refs_valid": True
    }
    problems = []

    # standard_matches 非空
    matches = data.get("standard_matches") or []
    if isinstance(matches, list) and len(matches) > 0:
        checks["has_standard_matches"] = True
    else:
        problems.append("standard_matches 为空")

    # extension_suggestions 非空（列表）
    extensions = data.get("extension_suggestions") or []
    if isinstance(extensions, list) and len(extensions) >= 1:
        checks["has_extensions"] = True
    else:
        problems.append("extension_suggestions 为空")

    # 来源为"提案依据"的扩展必须标注具体提案编号
    for ext in extensions:
        if not isinstance(ext, dict):
            continue
        if ext.get("source") == "提案依据":
            ref = (ext.get("proposal_ref") or "").strip()
            if not ref:
                checks["proposal_refs_valid"] = False
                problems.append(f"扩展建议 '{ext.get('title', '?')}' 标注为[提案依据]但缺少 proposal_ref")

    all_pass = all(checks.values())

    return {
        "status": "PASS" if all_pass else "FAIL",
        "checks": checks,
        "standard_matches": [m.get("standard", "") for m in matches if isinstance(m, dict)],
        "extension_count": len(extensions),
        "problems": problems,
        "message": "All SEP checks passed" if all_pass else "; ".join(problems)
    }


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--sep', required=True)
    args = parser.parse_args()

    result = check_sep(args.sep)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if result["status"] == "FAIL":
        sys.exit(1)
