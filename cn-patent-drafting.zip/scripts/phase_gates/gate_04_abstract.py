#!/usr/bin/env python3
"""
gate_04_abstract.py — 摘要门禁（Phase 5 摘要步）

Usage:
    python scripts/phase_gates/gate_04_abstract.py --abstract <abstract.txt> [--title "{发明名称}"]
Returns:
    JSON: { status, checks, message }
"""

import sys
import json
import argparse
import os
import re

def check_abstract(abstract_file, title=None):
    try:
        with open(abstract_file, 'r', encoding='utf-8') as f:
            content = f.read().strip()
    except FileNotFoundError:
        return {"status": "ERROR", "message": f"Abstract file not found: {abstract_file}"}
    except Exception as e:
        return {"status": "ERROR", "message": str(e)}

    if not content:
        return {"status": "FAIL", "message": "Abstract is empty"}
    
    checks = {
        "word_count_ok": False,
        "has_innovation_name": False,
        "no_forbidden_terms": True
    }
    
    # Check word count (Chinese: count characters)
    char_count = len(content)
    if char_count <= 300:
        checks["word_count_ok"] = True
    
    # Check for invention name
    if title:
        # 提供 --title 时做实校验：发明名称须出现在摘要中（忽略空白差异）
        norm = lambda s: re.sub(r'\s+', '', s)
        checks["has_innovation_name"] = norm(title) in norm(content)
    else:
        # 未提供标题时退化为首行启发式（历史行为）
        first_line = content.split('\n')[0].strip()
        if first_line and len(first_line) >= 4:
            checks["has_innovation_name"] = True
    
    # Check forbidden terms
    forbidden = ['本申请', '本发明', '包括', '所述']
    found_forbidden = []
    for term in forbidden:
        if term in content:
            found_forbidden.append(term)
    if found_forbidden:
        checks["no_forbidden_terms"] = False
    
    all_pass = all(checks.values())
    
    result = {
        "status": "PASS" if all_pass else "FAIL",
        "checks": checks,
        "char_count": char_count,
        "message": "Abstract checks passed" if all_pass else "See checks for details"
    }
    if title and not checks["has_innovation_name"]:
        result["message"] = f"摘要中未出现发明名称：{title}"
    return result

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--abstract', required=True)
    parser.add_argument('--title', default=None, help='发明名称；提供时校验摘要中是否出现该名称')
    args = parser.parse_args()
    
    result = check_abstract(args.abstract, args.title)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if result["status"] == "FAIL":
        sys.exit(1)
