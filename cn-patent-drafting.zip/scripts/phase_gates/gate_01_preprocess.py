#!/usr/bin/env python3
"""
gate_01_preprocess.py — 阶段1门禁：文件完整性校验

Usage:
    python scripts/phase_gates/gate_01_preprocess.py --disclosure <file.txt> [--claims <claims_raw.txt>]
Returns:
    JSON: { status, checks, message }
"""

import sys
import json
import argparse
import os

def check_preprocess(disclosure_file, claims_file=None):
    checks = {
        "disclosure_file_exists": False,
        "disclosure_not_empty": False,
    }

    # Check disclosure file
    if os.path.exists(disclosure_file):
        checks["disclosure_file_exists"] = True
        try:
            with open(disclosure_file, 'r', encoding='utf-8') as f:
                content = f.read()
            if len(content.strip()) >= 200:
                checks["disclosure_not_empty"] = True
        except:
            pass

    # Check claims file（可选：仅在提供 --claims 时纳入判定）
    if claims_file:
        checks["claims_exists"] = False
        checks["claims_has_content"] = False
        if os.path.exists(claims_file):
            checks["claims_exists"] = True
            try:
                with open(claims_file, 'r', encoding='utf-8') as f:
                    lines = f.readlines()
                claim_count = sum(1 for l in lines if l.strip().startswith(tuple('1234567890')))
                if claim_count >= 1:
                    checks["claims_has_content"] = True
            except:
                pass
    
    all_pass = all(checks.values())
    
    return {
        "status": "PASS" if all_pass else "FAIL",
        "checks": checks,
        "message": "All checks passed" if all_pass else "See checks for details"
    }

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--disclosure', required=True)
    parser.add_argument('--claims', default=None)
    args = parser.parse_args()
    
    result = check_preprocess(args.disclosure, args.claims)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if result["status"] == "FAIL":
        sys.exit(1)
