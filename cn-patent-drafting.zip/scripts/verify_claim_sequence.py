#!/usr/bin/env python3
"""
verify_claim_sequence.py — 权利要求编号连续性与引用关系校验（CN 案件口径）
检查项：
1. 编号是否连续（无跳号、无重复）
2. 引用关系是否有效（引用的权项编号存在）
3. 从属权利要求只能引用在前的权利要求
4. 引用链中无循环引用

说明：依赖关系仅由"根据权利要求X所述的"型从属引用构成；
回引型权要（装置/介质/程序产品/芯片）中的"如权利要求X至Y中任一项所述的方法"
不构成从属依赖，但会校验其引用的权项编号是否存在。

Usage:
    python scripts/verify_claim_sequence.py <claims_file.txt>
Returns:
    JSON: { status, errors[], sequence_gaps[], invalid_refs[], cycles[] }
"""

import re
import sys
import json


def split_claims(content):
    """按权项编号切分为权项块，返回 ([(num, block, line_no)], [重复的编号])"""
    lines = content.split('\n')
    header_re = re.compile(r'^(\d+)[\.\、]\s*')
    claims = []
    seen_numbers = []
    current = None
    for i, line in enumerate(lines):
        m = header_re.match(line.strip())
        if m:
            if current:
                claims.append(current)
            num = int(m.group(1))
            seen_numbers.append(num)
            current = [num, [line.strip()], i + 1]
        elif current is not None and line.strip():
            current[1].append(line.strip())
    if current:
        claims.append(current)
    duplicates = sorted({n for n in seen_numbers if seen_numbers.count(n) > 1})
    return [(num, '\n'.join(parts), ln) for num, parts, ln in claims], duplicates


def extract_refs(block):
    """提取权项块中的引用，区分为从属引用（根据）与回引引用（如/实现对象）"""
    dep_refs = set()    # "根据权利要求X所述的" —— 构成从属依赖
    callback_refs = set()  # "如权利要求X至Y中任一项所述的方法" —— 回引型权要的执行对象
    for m in re.finditer(r'(根据|如)权利要求\s*(\d+)(?:\s*(至|到|-|或|、|，|,)\s*(\d+))?(?:\s*中任一项)?\s*所述', block):
        kind, r1, sep, r2 = m.group(1), int(m.group(2)), m.group(3), m.group(4)
        target = dep_refs if kind == '根据' else callback_refs
        if sep in ('至', '到', '-') and r2:
            target.update(range(r1, int(r2) + 1))
        else:
            target.add(r1)
            if r2:
                target.add(int(r2))
    return dep_refs, callback_refs


def verify_claim_sequence(filepath):
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
    except FileNotFoundError:
        return {"status": "ERROR", "message": f"File not found: {filepath}"}
    except Exception as e:
        return {"status": "ERROR", "message": str(e)}

    claims, duplicates = split_claims(content)
    if not claims:
        return {"status": "ERROR", "message": "No claims found in file"}

    errors = []
    claim_numbers = sorted(num for num, _, _ in claims)
    existing = set(claim_numbers)

    # 1. 编号连续性
    expected = set(range(claim_numbers[0], claim_numbers[-1] + 1))
    gaps = sorted(expected - existing)
    if gaps:
        errors.append({
            "rule": "编号连续性",
            "details": [f"缺失的权项编号: {gaps}"],
            "count": len(gaps)
        })
    if duplicates:
        errors.append({
            "rule": "编号重复",
            "details": [f"重复的权项编号: {duplicates}"],
            "count": len(duplicates)
        })

    # 2. 引用有效性与在前引用
    dep_graph = {}
    invalid_refs = []
    forward_refs = []
    for num, block, ln in claims:
        dep_refs, callback_refs = extract_refs(block)
        dep_graph[num] = dep_refs
        for r in sorted(dep_refs):
            if r not in existing:
                invalid_refs.append(f"权{num} (line {ln}): 引用了不存在的权{r}")
            elif r >= num:
                forward_refs.append(f"权{num} (line {ln}): 从属权利要求引用了在后的权{r}")
        for r in sorted(callback_refs):
            if r not in existing:
                invalid_refs.append(f"权{num} (line {ln}): 回引了不存在的权{r}")

    if invalid_refs:
        errors.append({
            "rule": "引用有效性",
            "details": invalid_refs[:5],
            "count": len(invalid_refs)
        })
    if forward_refs:
        errors.append({
            "rule": "在前引用",
            "details": forward_refs[:5],
            "count": len(forward_refs)
        })

    # 3. 循环引用
    def find_cycle(start, visited, path):
        if start in path:
            return path[path.index(start):] + [start]
        if start in visited:
            return None
        visited.add(start)
        path.append(start)
        for ref in dep_graph.get(start, set()):
            if ref in dep_graph:
                cycle = find_cycle(ref, visited, path[:])
                if cycle:
                    return cycle
        return None

    cycles_found = []
    visited_global = set()
    for cn in claim_numbers:
        if cn not in visited_global:
            cycle = find_cycle(cn, set(), [])
            if cycle:
                cycles_found.append(f"循环引用: {' -> '.join(str(c) for c in cycle)}")
                visited_global.update(cycle)

    if cycles_found:
        errors.append({
            "rule": "循环引用",
            "details": cycles_found,
            "count": len(cycles_found)
        })

    return {
        "status": "FAIL" if errors else "PASS",
        "errors": errors,
        "claim_count": len(claim_numbers),
        "claim_range": f"{claim_numbers[0]}-{claim_numbers[-1]}",
        "total_errors": sum(e["count"] for e in errors)
    }


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(json.dumps({"status": "ERROR", "message": "Usage: python verify_claim_sequence.py <claims_file.txt>"}))
        sys.exit(1)
    result = verify_claim_sequence(sys.argv[1])
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if result["status"] == "FAIL":
        sys.exit(1)
