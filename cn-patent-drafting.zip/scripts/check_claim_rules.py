#!/usr/bin/env python3
"""
check_claim_rules.py — 权利要求格式验证（CN 案件口径）
检查项：
1. 引用格式：从属权利要求必须以"根据权利要求X所述的"开头；
   回引型权要（装置/介质/程序产品/芯片）中作为执行对象的
   "如权利要求X至Y中任一项所述的方法"属于合法用法，予以放行。
2. 禁止词汇（权利要求中）：可以、优选、较佳、大约、例如、比如、可选的、
   以及非枚举义的"等"和近似义的"约"。
   说明：中文无词边界，多字禁用词直接子串匹配；
   单字"等/约"使用白名单排除正常用词（等待、等于、等级、约定等）。
3. 从属引用限制（CN）：
   从属权利要求只能引用在前权利要求（FAIL 级）。
   多引多不作限制（CN 实践允许），仅 WARN 提示。
   回引型权要中的"如权利要求X至Y中任一项所述的方法"不属于从属引用，不纳入本检查。
4. 全品类布局检验（方法 + 装置为最低要求）。
5. 占位符残留：最终权要文本不得包含方括号模板槽（如"[主语网元]""[触发消息]"），
   所有槽位必须实例化为具体技术术语。

Usage:
    python scripts/check_claim_rules.py <claims_file.txt>
Returns:
    JSON: { status, violations[], warnings[] }
"""

import re
import sys
import json


def split_claims(content):
    """按权项编号切分为权项块，返回 [(claim_num, block_text, header_line_no)]"""
    lines = content.split('\n')
    header_re = re.compile(r'^(\d+)[\.\、]\s*')
    claims = []
    current = None
    for i, line in enumerate(lines):
        m = header_re.match(line.strip())
        if m:
            if current:
                claims.append(current)
            current = [int(m.group(1)), [line.strip()], i + 1]
        elif current is not None and line.strip():
            current[1].append(line.strip())
    if current:
        claims.append(current)
    return [(num, '\n'.join(parts), ln) for num, parts, ln in claims]


def check_reference_format(claims, violations):
    """从属权要的引用语必须是"根据权利要求X所述的"；回引用法放行"""
    non_standard = []
    for num, block, ln in claims:
        first_line = block.split('\n')[0]
        # 找出该权要中所有的引用式表达
        for m in re.finditer(r'(如|根据)?权利要求\s*\d+(?:\s*(?:至|到|-|或|、|，|,)\s*\d+)*(?:\s*中任一项)?\s*所述的', first_line):
            prefix = m.group(1)
            if prefix == '根据':
                continue  # 标准引用格式
            # "如权利要求..."：仅在回引场景（作为执行/实现对象）合法
            before = first_line[:m.start()]
            if re.search(r'(执行|实现|运行|完成)\s*$', before):
                continue  # 回引型权要中的合法用法
            non_standard.append(
                f"Claim {num} (line {ln}): 非标准引用 '如权利要求...所述的'，从属引用应使用'根据权利要求X所述的'")
        # 非正式引用："权X所述的"
        if re.search(r'(?<![权利要求])权\s*\d+\s*所述的', first_line):
            non_standard.append(f"Claim {num} (line {ln}): 非正式引用'权X所述的'，应写全称'根据权利要求X所述的'")
    if non_standard:
        violations.append({
            "rule": "引用格式",
            "details": non_standard[:5],
            "count": len(non_standard)
        })


def check_forbidden_words(content, violations):
    """禁用词检测：多字词直接子串匹配；单字词上下文白名单"""
    found = []

    multi_char_terms = ['可以', '优选', '较佳', '大约', '例如', '比如', '可选的']
    for term in multi_char_terms:
        for m in re.finditer(re.escape(term), content):
            line_num = content[:m.start()].count('\n') + 1
            found.append(f"Line {line_num}: 禁用词 '{term}'")

    # 单字"等"：排除正常 compound（等待/等于/等级/等同/等候/等效/等值/均等/平等/对等 等）
    deng_after = set('待于级同候效值比温离分幅边差高距速位响离子度时')  # 等+X 构成正常词
    deng_before = set('均平对高劣优低相')  # X+等 构成正常词
    for m in re.finditer('等', content):
        pos = m.start()
        prev_c = content[pos - 1] if pos > 0 else ''
        next_c = content[pos + 1] if pos + 1 < len(content) else ''
        if next_c in deng_after or prev_c in deng_before:
            continue
        line_num = content[:pos].count('\n') + 1
        ctx = content[max(0, pos - 6):pos + 7].replace('\n', ' ')
        found.append(f"Line {line_num}: 禁用词 '等'（列举未尽）…{ctx}…")

    # 单字"约"：仅在近似数值语境下判定（约5、约为10、约20%）
    for m in re.finditer(r'约(?=\s*\d|为\s*\d|[一二三四五六七八九十百千])', content):
        line_num = content[:m.start()].count('\n') + 1
        ctx = content[max(0, m.start() - 6):m.start() + 7].replace('\n', ' ')
        found.append(f"Line {line_num}: 禁用词 '约'（近似表述）…{ctx}…")

    if found:
        violations.append({
            "rule": "禁用词",
            "details": found[:10],
            "count": len(found)
        })


def check_multiple_dependency(claims, violations, warnings):
    """从属引用检查：只能引用在前权项（FAIL 级）。
    多引多（多项从属引用多项从属）2024 年起按 CN 实践不作限制，降为 WARN 级提示：
    细则25.2 条文层面仍有形式规定，遇审查员形式意见时再改即可。"""
    # 仅分析以"根据权利要求"表达的从属引用（回引型权要的"如权利要求"不算）
    ref_map = {}
    for num, block, ln in claims:
        refs = set()
        first_line = block.split('\n')[0]
        for m in re.finditer(r'根据权利要求\s*(\d+)(?:\s*(至|到|或|、|，|,)\s*(\d+))?(?:\s*中任一项)?\s*所述', first_line):
            r1 = int(m.group(1))
            if m.group(2) in ('至', '到') and m.group(3):
                refs.update(range(r1, int(m.group(3)) + 1))
            else:
                refs.add(r1)
                if m.group(3):
                    refs.add(int(m.group(3)))
        if refs:
            ref_map[num] = {"refs": refs, "line": ln, "multiple": len(refs) > 1}

    problems = []
    multi_multi = []
    for num, info in ref_map.items():
        for r in info["refs"]:
            # 只能引用在前权项
            if r >= num:
                problems.append(f"Claim {num} (line {info['line']}): 从属权利要求引用了在后的权利要求{r}")
            # 多引多：CN 实践允许，仅作提示（不阻塞）
            elif info["multiple"] and r in ref_map and ref_map[r]["multiple"]:
                multi_multi.append(f"Claim {num}: 引用多项从属权{r}（多引多，CN实践可接受，仅提示）")
    if problems:
        violations.append({
            "rule": "从属引用在前限制（CN）",
            "details": problems[:5],
            "count": len(problems)
        })
    if multi_multi:
        warnings.append({
            "rule": "多引多提示",
            "details": multi_multi[:5],
            "count": len(multi_multi)
        })


def check_category_coverage(content, warnings):
    """全品类布局检验：方法 + 装置为最低要求"""
    category_keywords = {
        "method": ["方法", "method"],
        "apparatus": ["装置", "apparatus", "device"],
        "storage_medium": ["存储介质", "storage medium", "computer-readable"],
        "program_product": ["程序产品", "program product"],
        "chip": ["芯片", "chip"],
        "system": ["系统", "system"],
    }
    found_categories = set()
    content_lower = content.lower()
    for category, keywords in category_keywords.items():
        for kw in keywords:
            if kw.lower() in content_lower:
                found_categories.add(category)
                break

    missing_min = {"method", "apparatus"} - found_categories
    result = {"found": sorted(found_categories)}
    if missing_min:
        return result, [{
            "rule": "全品类布局",
            "details": [f"缺少必需类别: {', '.join(sorted(missing_min))}（方法+装置为最低要求）"],
            "count": len(missing_min)
        }]
    missing_extended = {"storage_medium", "program_product"} - found_categories
    if missing_extended:
        warnings.append({
            "rule": "全品类布局（扩展类别）",
            "details": [f"建议补充: {', '.join(sorted(missing_extended))}"],
            "count": len(missing_extended)
        })
    return result, []


def check_placeholder_residue(content, violations):
    """占位符残留：最终权要文本不得包含方括号模板槽（[...]/【...】）"""
    found = []
    for m in re.finditer(r'[\[【][^\]】\n]{1,30}[\]】]', content):
        line_num = content[:m.start()].count('\n') + 1
        found.append(f"Line {line_num}: 占位符残留 '{m.group(0)}'，模板槽必须实例化为具体技术术语")
    if found:
        violations.append({
            "rule": "占位符残留",
            "details": found[:10],
            "count": len(found)
        })


def check_claim_rules(filepath):
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
    except FileNotFoundError:
        return {"status": "ERROR", "message": f"File not found: {filepath}"}
    except Exception as e:
        return {"status": "ERROR", "message": str(e)}

    violations = []
    warnings = []

    claims = split_claims(content)
    if not claims:
        return {"status": "ERROR", "message": "No claims found in file"}

    check_reference_format(claims, violations)
    check_forbidden_words(content, violations)
    check_placeholder_residue(content, violations)
    check_multiple_dependency(claims, violations, warnings)
    _, coverage_violations = check_category_coverage(content, warnings)
    violations.extend(coverage_violations)

    status = "FAIL" if violations else "PASS"

    return {
        "status": status,
        "claim_count": len(claims),
        "violations": violations,
        "warnings": warnings,
        "total_violations": sum(v["count"] for v in violations),
        "total_warnings": sum(w["count"] for w in warnings)
    }


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(json.dumps({"status": "ERROR", "message": "Usage: python check_claim_rules.py <claims_file.txt>"}))
        sys.exit(1)
    result = check_claim_rules(sys.argv[1])
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if result["status"] == "FAIL":
        sys.exit(1)
