#!/usr/bin/env python3
"""
verify_coverage.py — 交底书→说明书覆盖度反向校验
反向校验原理：
  不检查"说明书写了什么"，而检查"交底书有但说明书没有的"。

覆盖度算法（中文适用）：
  将交底书按标点切分为语义片段，对每个片段提取字符级 3-gram 集合，
  若某片段 ≥60% 的 3-gram 能在说明书中找到，则判定该片段已被覆盖。
  （说明书的合理改写——如单侧撰写中删去"网络设备发送的"——不会导致误判，
   因为片段的大部分字串仍然保留。）

步骤校验（三套机制，编号体系不同也能查）：
  1. 编号差集：仅当交底书本身使用 S 编号时，比对 S 编号差集
     （"步骤1"式编号与说明书 S100 式编号体系不同，不直接比号）。
  2. 说明书 S 编号序列：行首定义式提取（排除正文回引），倒序 FAIL、重复定义 WARN。
  3. 步骤单元覆盖：交底书按编号列表或动作动词句切分为步骤单元，
     逐单元 n-gram 覆盖比对，整步缺失（覆盖率<30%）FAIL，步骤数不一致 WARN。

Usage:
    python scripts/verify_coverage.py --disclosure <disclosure.txt> --specification <specification.txt> [--analysis <disclosure_analysis.json>]
Returns:
    JSON: { status, coverage_pct, missing_segments[], missing_steps[] }
"""

import re
import sys
import json
import argparse

NGRAM = 3
SEGMENT_COVER_THRESHOLD = 0.6

# 纯套话/通用片段不参与覆盖率统计
GENERIC_SEGMENTS = {'技术领域', '背景技术', '发明内容', '附图说明', '具体实施方式',
                    '技术问题', '技术方案', '有益效果'}


def ngrams(text, n=NGRAM):
    """提取字符级 n-gram 集合（仅保留含中文或字母数字的片段）"""
    text = re.sub(r'\s+', '', text)
    return {text[i:i + n] for i in range(len(text) - n + 1)}


def split_segments(text, min_len=6):
    """按标点将文本切分为语义片段，过滤过短与通用片段"""
    raw = re.split(r'[，。；、：！？\n,.;:?!（）()\[\]【】""'']+', text)
    segments = []
    for seg in raw:
        seg = seg.strip()
        if len(seg) >= min_len and seg not in GENERIC_SEGMENTS:
            segments.append(seg)
    return segments


def extract_steps(text):
    """提取方法步骤：编号步骤 + 行首动作动词"""
    steps = set()
    # 编号步骤：S101、步骤101、步骤一、Step 3
    for m in re.finditer(r'(?:步骤|Step)\s*([0-9]+|[一二三四五六七八九十百千]+)', text, re.IGNORECASE):
        steps.add(m.group(1))
    for m in re.finditer(r'\bS\s*(\d{2,4})\b', text):
        steps.add(m.group(1))
    # 行首动作动词（中文行文动词后紧跟宾语，无空格）
    for m in re.finditer(r'^\s*(获取|确定|接收|发送|生成|建立|配置|检测|判断|选择|更新|删除|添加|调整|计算|解析|编码|解码|映射|转换|验证|认证|授权)(?=[\u4e00-\u9fffA-Z])', text, re.MULTILINE):
        steps.add('verb:' + m.group(1) + str(m.start()))
    return steps


def extract_spec_step_definitions(text):
    """提取说明书中的步骤"定义"编号（按出现顺序）。

    只认行首（或"步骤"引导）的 S 编号定义，如：
        S100，第一网元接收第一信息。
        步骤S200：第一网元确定感知参数。
    正文中的回引（"在S100之后"、"如S100所述"）不在行首，不计入。
    """
    labels = []
    for m in re.finditer(r'^\s*(?:步骤\s*)?S\s*(\d{2,4})\s*[、，,:：.]', text, re.MULTILINE):
        labels.append(int(m.group(1)))
    return labels


def check_step_sequence(labels):
    """检查说明书步骤编号序列：倒序为 FAIL 级，重复定义为 WARN 级"""
    inversions, duplicates = [], []
    seen = {}
    prev = None
    for idx, n in enumerate(labels):
        if n in seen:
            duplicates.append(n)
        else:
            seen[n] = idx
        if prev is not None and n < prev:
            inversions.append((prev, n))
        prev = n
    return inversions, duplicates


def split_disclosure_step_units(text):
    """将交底书切分为"步骤单元"。

    交底书一般没有 S 编号，优先按显式编号列表切分
    （"步骤1"/"1."/"（1）"等行首标记）；没有编号列表时，
    退化为以动作动词开头的语义片段。
    """
    # 显式编号列表：步骤1 / 步骤一 / 1. / （2）等行首标记
    marker = re.compile(r'^\s*(?:步骤\s*[0-9一二三四五六七八九十]+|[（(]\s*\d+\s*[）)]|\d+\s*[.、．])\s*', re.MULTILINE)
    matches = list(marker.finditer(text))
    units = []
    if len(matches) >= 2:
        for i, m in enumerate(matches):
            end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
            unit = text[m.start():end].strip()
            if len(unit) >= 6:
                units.append(unit)
        return units
    # 退化：动作动词开头的片段
    for seg in split_segments(text):
        if re.match(r'^(获取|确定|接收|发送|生成|建立|配置|检测|判断|选择|更新|删除|添加|调整|计算|解析|编码|解码|映射|转换|验证|认证|授权)', seg):
            units.append(seg)
    return units


def load_method_steps(analysis_file):
    """从 Phase 1 交底书分析结果读取 method_steps 字段（权威步骤序列）"""
    try:
        with open(analysis_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        steps = data.get('method_steps') or []
        return [s for s in steps if isinstance(s, str) and len(s.strip()) >= 6]
    except (FileNotFoundError, json.JSONDecodeError, TypeError):
        return []


def verify_coverage(disclosure_file, spec_file, analysis_file=None):
    try:
        with open(disclosure_file, 'r', encoding='utf-8') as f:
            disclosure = f.read()
    except FileNotFoundError:
        return {"status": "ERROR", "message": f"Disclosure file not found: {disclosure_file}"}

    try:
        with open(spec_file, 'r', encoding='utf-8') as f:
            specification = f.read()
    except FileNotFoundError:
        return {"status": "ERROR", "message": f"Specification file not found: {spec_file}"}

    spec_grams = ngrams(specification)

    # 全局覆盖：交底书全部语义片段的 n-gram 有多少能在说明书中找到。
    # 说明书的合理改写（如单侧撰写删去"网络设备发送的"）只会影响局部少量
    # n-gram，不会把全局覆盖率压到阈值以下；整段遗漏才会显著拉低覆盖率。
    disc_segments = split_segments(disclosure)
    all_disc_grams = set()
    for seg in disc_segments:
        all_disc_grams |= ngrams(seg)

    if all_disc_grams:
        coverage_pct = round(len(all_disc_grams & spec_grams) / len(all_disc_grams) * 100, 2)
    else:
        coverage_pct = 100.0

    # 片段级命中率仅作诊断：列出覆盖率明显偏低的片段供人工确认
    missing_segments = []
    for seg in disc_segments:
        grams = ngrams(seg)
        if grams and sum(1 for g in grams if g in spec_grams) / len(grams) < 0.5:
            missing_segments.append(seg)

    total = len(disc_segments)

    # 步骤覆盖：仅当交底书本身使用 S 编号时才做编号差集。
    # "步骤1/步骤一"式编号与说明书 S100/S200 编号体系不同，不能直接比号，
    # 这类对应关系由下方的"步骤单元覆盖"校验负责。
    disc_s_steps = set(re.findall(r'\bS\s*(\d{2,4})\b', disclosure))
    spec_s_steps = set(re.findall(r'\bS\s*(\d{2,4})\b', specification))
    missing_steps = sorted(disc_s_steps - spec_s_steps)
    disc_steps = disc_s_steps
    spec_steps = spec_s_steps

    # 强化校验1：说明书步骤编号序列（S100/S200 式定义，行首提取，排除正文回引）
    spec_step_defs = extract_spec_step_definitions(specification)
    inversions, dup_defs = check_step_sequence(spec_step_defs)

    # 强化校验2：交底书步骤单元 → 说明书逐单元覆盖
    # 优先使用 Phase 1 输出的 method_steps（权威步骤序列）；
    # 未提供时按编号列表或动作动词句切分单元，
    # 逐单元做 n-gram 覆盖比对，定位"交底书有而说明书漏写"的整步
    disc_units = load_method_steps(analysis_file) if analysis_file else []
    units_source = "phase1_method_steps" if disc_units else "text_split"
    if not disc_units:
        disc_units = split_disclosure_step_units(disclosure)
    uncovered_units = []
    for i, unit in enumerate(disc_units, 1):
        grams = ngrams(unit)
        if grams and sum(1 for g in grams if g in spec_grams) / len(grams) < 0.3:
            uncovered_units.append({"unit_index": i, "preview": unit[:40]})

    result = {
        "status": "PASS",
        "coverage_pct": coverage_pct,
        "total_disclosure_segments": total,
        "missing_segments_count": len(missing_segments),
        "missing_segments": missing_segments[:30],
        "missing_steps": missing_steps,
        "disclosure_step_count": len(disc_steps),
        "spec_step_count": len(spec_steps),
        "spec_step_definitions": spec_step_defs,
        "disclosure_step_unit_count": len(disc_units),
        "step_units_source": units_source,
        "uncovered_step_units": uncovered_units,
        "step_sequence_inversions": inversions,
        "step_definition_duplicates": dup_defs
    }

    if coverage_pct < 70:
        result["status"] = "FAIL"
        result["message"] = f"覆盖率过低: {coverage_pct}%。交底书有 {len(missing_segments)} 个语义片段未在说明书中体现。"
    elif missing_steps:
        result["status"] = "FAIL"
        result["message"] = f"交底书中的 {len(missing_steps)} 个步骤编号未在说明书中出现: {missing_steps}"
    elif inversions:
        result["status"] = "FAIL"
        result["message"] = f"说明书步骤编号倒序: {['S%d 后出现 S%d' % (a, b) for a, b in inversions]}。"
    elif uncovered_units:
        result["status"] = "FAIL"
        result["message"] = (f"交底书 {len(disc_units)} 个步骤单元中有 {len(uncovered_units)} 个"
                             f"在说明书中基本无对应内容: {[u['unit_index'] for u in uncovered_units]}。")
    elif coverage_pct < 85 or dup_defs or len(spec_step_defs) < len(disc_units):
        result["status"] = "WARN"
        notes = []
        if coverage_pct < 85:
            notes.append(f"覆盖率 {coverage_pct}%，少量片段未覆盖")
        if dup_defs:
            notes.append(f"步骤编号重复定义: {['S%d' % n for n in dup_defs]}")
        if len(spec_step_defs) < len(disc_units):
            notes.append(f"说明书步骤定义数({len(spec_step_defs)})少于交底书步骤单元数({len(disc_units)})，"
                         f"请确认是否有步骤被合并")
        result["message"] = "；".join(notes) + "。请人工确认。"
    else:
        result["message"] = f"覆盖率: {coverage_pct}%。交底书内容与步骤均已覆盖。"

    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--disclosure', required=True)
    parser.add_argument('--specification', required=True)
    parser.add_argument('--analysis', default=None, help='Phase 1 disclosure_analysis.json（含 method_steps 字段）')
    parser.add_argument('--spec-only', action='store_true', help='Run spec-only checks')
    args = parser.parse_args()

    result = verify_coverage(args.disclosure, args.specification, args.analysis)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if result["status"] == "FAIL":
        sys.exit(1)
