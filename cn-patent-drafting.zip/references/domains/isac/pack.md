# 领域包：ISAC / 核心网感知

> 领域包路由元信息。**Phase 1 启动前**，主 Agent 扫描 `references/domains/` 下各包的
> 本文件，用"命中关键词"对 `output/disclosure.txt` 全文匹配（grep 即可），命中即按"文件清单"在对应阶段加载
>（Phase 1 的 sub agent prompt 需要本包文件路径，因此路由必须先于 Phase 1）。

## 命中关键词

核心关键词：**感知**、**核心网**（交底书主题含任一词即纳入候选判定）

细化关键词：感知网元（SF/SCF）、NEF 感知业务开放、感知授权、感知网元选择、协同感知、
感知数据上报、通感一体、ISAC、sensing、核心网感知

> 注：核心关键词较宽泛，命中后需结合细化关键词二次确认——若交底书的"感知"
> 实为传感器数据采集、状态监测等非通信感知语义，或"核心网"仅作为背景出现而
> 发明点与之无关，则不加载本包。

## 3GPP 归属

跨 RAN1/RAN2/SA1/SA2；核心网感知优先 SA1（业务需求）→ SA2（系统架构）。
课题对照详见 `references/sep_mapping_rules.md` 的 ISAC 专题组。

## 文件清单

| 文件 | 内容 | 加载阶段 |
|---|---|---|
| `disclosure-analysis.md` | 交底书信息清单 + 发明点类型库（A~H） | Phase 1 |
| `claims-strategy.md` | 权利要求树、独权句式模板、从权三层素材库 | Phase 2 |
| `boilerplate.md` | 说明书套话库 + 中英对照词汇（含摘要句式） | Phase 3 / Phase 5（摘要步） |
| `figures.md` | 附图版式规范（架构图/信令时序图/装置功能框图/硬件结构图） | Phase 3.5 |
