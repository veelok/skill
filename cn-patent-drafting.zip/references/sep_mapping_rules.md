# SEP 标准课题映射规则（3GPP 课题↔技术方向对照表）

> 本文件用于 SEP 对应性分析 sub agent 在判断交底书所属标准课题时参考。
> 仅列出最相关的 3GPP 课题，按技术领域分组。

---

## 无线物理层（RAN1）

| 技术方向 | 相关 Release | 关键词 |
|---------|-------------|--------|
| CSI 测量与反馈 | R17/R18/R19 | CSI, PMI, CQI, RI, beam reporting, channel measurement |
| 信道状态信息增强 | R18/R19 | CSI enhancement, AI/ML for CSI, spatial domain compression |
| 波束管理 | R17/R18 | beam management, beam failure recovery, L1-SINR |
| 多天线/MIMO | R17-R19 | MIMO, multi-panel, coherent transmission, SRS enhancement |
| 定位 | R17/R18/R19 | positioning, SRS for positioning, PRS, DL-TDOA, multi-RTT |
| 侧链通信 | R17/R18 | sidelink, SL positioning, SL relay |
| 非地面网络 | R17/R18 | NTN, satellite, earth-fixed, regenerative payload |
| AI/ML 空口应用 | R18/R19 (SI) | AI/ML for beam management, CSI feedback, positioning accuracy |
| 全双工 | R18/R19 | full duplex, SBFD, sub-band, self-interference cancellation |
| 载波聚合增强 | R17/R18 | CA, FR1+FR2, inter-band CA, PSCell |
| 非授权频谱 | R17/R18/R19 | NR-U, unlicensed, LBT, channel access |
| 免许可频谱侧链 | R19 | NR-U sidelink |
| 多载波/多连接增强 | R18/R19 | multi-carrier, multi-connectivity, L1 enhancements |
| 多TRP/多面板 | R17/R18 | mTRP, multi-panel, coherent joint transmission, NCJT |
| 节能 | R17/R18 | network energy saving, UE power saving, wake-up signal, DRX |

## 无线 L2/L3（RAN2）

| 技术方向 | 相关 Release | 关键词 |
|---------|-------------|--------|
| MAC 调度增强 | R17/R18 | scheduling, HARQ, CG, dynamic grant, configured grant |
| 小区切换与选择 | R17/R18 | handover, CHO, conditional handover, cell selection, L1/L3 mobility |
| RLC 层增强 | R17/R18 | RLC segmentation, reordering |
| 小数据传输 | R17/R18 | SDT, small data, inactive state, RRC_INACTIVE |
| 多播/广播 | R17/R18 | MBS, multicast, broadcast, PTM, PTP, group scheduling |
| 边缘链路中继 | R17/R18 | relay, remote UE, L2 relay, L3 relay |
| RRC 状态管理 | R17/R18 | RRC states, state transition, inactive, suspended |
| 切片 | R17/R18 | network slicing, RAN slicing, slice selection |
| AI/ML for L2/L3 | R18/R19 | AI/ML for mobility, load balancing, traffic prediction |

## 核心网与架构（SA2）

| 技术方向 | 相关 Release | 关键词 |
|---------|-------------|--------|
| 会话管理 | R17-R19 | session management, PDU session, SSC mode, multi-access |
| 移动性管理 | R17-R19 | mobility management, registration, tracking area, UE reachability |
| 网络切片 | R17-R19 | network slicing, NSSF, S-NSSAI, slice instance selection |
| 边缘计算 | R17/R18 | edge computing, MEC, UPF relocation, DNAI |
| 服务化架构 | R17-R19 | SBA, service discovery, NRF, service communication proxy |
| AI/ML 网络 | R18/R19 (FS) | AI/ML for 5GS, NWDAF, model management, federated learning |
| 卫星回传 | R18 | satellite backhaul, NTN CN interface |
| QoS 控制 | R17-R19 | QoS, 5QI, reflective QoS, guaranteed bit rate |
| 策略控制 | R17-R19 | policy framework, PCC, ANDSP, URSP |

## 服务与能力开放（SA1 / CT1）

| 技术方向 | 相关 Release | 关键词 |
|---------|-------------|--------|
| 网络能力开放 | R17-R19 | CAPIF, NEF, API exposure, service enablement |
| 增强现实/虚拟现实 | R17/R18 | AR/VR, XR, media streaming, QoS for XR |
| 工业IoT | R17/R18 | IIoT, industrial sensor, TSC, time synchronization |
| V2X 服务 | R17/R18 | V2X, platooning, remote driving, vulnerable road user |
| 无人机 | R18 | UAV, UAS, drone, aerial communication |
| 多媒体 | R17-R19 | MTSI, MBMS, multimedia priority |
| 5G 消息 | R18 | 5G messaging, MMS replacement, chat service |

## 安全与认证（SA3 / LI）

| 技术方向 | 相关 Release | 关键词 |
|---------|-------------|--------|
| 接入层安全 | R17-R19 | AS security, ciphering, integrity protection |
| 非接入层安全 | R17-R19 | NAS security, primary authentication, secondary authentication |
| 密钥管理 | R17-R19 | key management, KDF, key derivation, AKMA |
| 切片安全 | R17/R18 | network slice security, slice-specific authentication |
| AI/ML 安全 | R18/R19 | AI security, adversarial robustness, model poisoning |
| 隐私保护 | R17-R19 | privacy, SUCI, SUPI protection, IMSI replacement |
| 合法监听 | R17-R19 | lawful interception, LI, intercept related information |

## 多媒体与编解码（SA4）

| 技术方向 | 相关 Release | 关键词 |
|---------|-------------|--------|
| 音频编解码 | R17-R19 | codec, EVS, IVAS, immersive audio |
| 视频编解码 | R17-R19 | video codec, H.265, H.266, VVC, EVC |
| 点云 | R17/R18 | point cloud, PCC, G-PCC, V-PCC |
| 沉浸式媒体 | R18/R19 | immersive media, MTSI, 6DoF, volumetric media |
| AI 编解码 | R19 (SI) | AI codec, neural network based compression, end-to-end |

## 业务与系统（SA5 / SA6）

| 技术方向 | 相关 Release | 关键词 |
|---------|-------------|--------|
| 网络管理 | R17-R19 | OAM, FCAPS, SON, self-optimization, self-healing |
| 自动化与编排 | R17-R19 | automation, orchestration, NFV, MANO, closed-loop |
| 保障 | R17-R19 | assurance, SLA, service assurance, KPI monitoring |
| 数据收集 | R17-R19 | MDT, minimization of drive test, trace, QoE |
| AI/ML for OAM | R18/R19 | AI/ML in management, intent-driven, anomaly detection |

## 射频与性能（RAN4）

| 技术方向 | 相关 Release | 关键词 |
|---------|-------------|--------|
| 射频要求 | R17-R19 | RF requirements, spurious emission, ACLR, EVM |
| 基站射频 | R17-R19 | BS RF, power class, sensitivity, dynamic range |
| UE 射频 | R17-R19 | UE RF, maximum power, ACLR, spurious |
| 共存 | R17-R19 | coexistence, adjacent channel, blocking, desensitization |
| AI/ML RF 增强 | R18/R19 | AI/ML for RRM, RF optimization |

## 医疗电子（RAN SWG / SA SWG）

| 技术方向 | 相关 Release | 关键词 |
|---------|-------------|--------|
| 医疗物联网 | R17/R18 | healthcare, medical IoT, wearable, patient monitoring |

---

## 通信感知一体化 / 核心网感知（ISAC，跨 RAN1/RAN2/SA1/SA2）

| 技术方向 | 相关 Release | 关键词 |
|---------|-------------|--------|
| 感知业务开放 | R18/R19 | sensing service, NEF exposure, sensing request, AF sensing |
| 感知授权/签约 | R18/R19 | sensing authorization, UDM sensing subscription, consent |
| 感知网元选择/发现 | R18/R19 | SF selection, sensing NF discovery, NRF sensing capability |
| 感知能力注册 | R18/R19 | sensing capability registration, AMF sensing support |
| 协同感知 | R18/R19 | collaborative sensing, multi-node sensing, sensing coordination |
| 感知控制与资源 | R18/R19 | sensing control, SF/SCF, sensing area, sensing QoS |
| 感知数据传输 | R18/R19 | sensing data reporting, sensing data collection, UPF sensing |
| 感知测量与空口 | R18/R19 (SI) | ISAC, sensing measurement, radar-like, echo signal, monostatic/bistatic |
| 感知与定位融合 | R18/R19 | sensing and positioning, LMF/GMLC sensing |

> 核心网感知案件（SF/SCF、NEF 感知开放、感知授权、网元选择等）优先查 SA1（业务需求）与 SA2（架构流程）课题；空口感知测量查 RAN1/RAN2。

## 快速判断规则

当分析交底书时，按以下优先级判断：

```
1. 先读 innovation_points 和 tech_problems
2. 提取核心技术关键词（见各课题关键词列）
3. 按"匹配关键词数 / 总关键词数"计算各课题匹配度
4. 匹配度 ≥ 50% → 置信度 HIGH
5. 匹配度 25-50% → 置信度 MEDIUM
6. 匹配度 < 25% → 置信度 LOW 或 不收录
7. 如 HARQ + 调度 + RLC → RAN2
8. 如 CSI + beam + MIMO + positioning → RAN1
9. 如 session + mobility + slice → SA2
10. 如 security + authentication + key → SA3
11. 如 codec + media + audio/video → SA4
12. 如 AI/ML + network analytics + NWDAF → R18/R19 跨课题
```

---

## 搜索提案时的建议关键词

针对各课题，搜索提案时推荐的关键词组合：

```
RAN1:  "R1-{year} {keyword} agreement/signalling/intention"
RAN2:  "R2-{year} {keyword} CR/discussion/agreement"
SA2:   "S2-{year} {keyword} solution/architecture/procedure"
SA3:   "S3-{year} {keyword} security/threat/analysis"
SA4:   "S4-{year} {keyword} codec/quality/evaluation"
RAN4:  "R4-{year} {keyword} requirement/minimum/limit"
```

跨课题场景：
```
AI/ML: "R1-{year} AI/ML beam/CSI/positioning"
       "S2-{year} AI/ML NWDAF analytic"
```
