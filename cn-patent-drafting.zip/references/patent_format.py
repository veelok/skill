# -*- coding: utf-8 -*-
"""
华为专利申请文件 DOCX 格式生成工具 (Patent Format Module)
============================================================

基于华为专利申请文件模板（参考92118935CN01）提炼的格式规范。
适用于上行控制、通信领域及所有中文专利申请文件的DOCX生成。

## Agent 集成指南（发给agent时，agent应执行以下步骤）

1. 将此文件复制到 skill 的 `references/` 目录下
2. 在 skill 的 SKILL.md 中添加以下内容（含空行规则）：

```markdown
## DOCX输出格式规范

当输出为 `.docx` 文件时，使用 `references/patent_format.py` 生成格式正确的文档。

```python
from references.patent_format import PatentDoc

doc = PatentDoc()
doc.add_page_title("说明书")           # 页标题
doc.add_invention_title("一种通信方法及装置")  # 发明名称
doc.add_section_title("技术领域")      # 章节标题
doc.add_body_para("本申请涉及...")     # 正文
doc.add_claim_group(["1. 一种通信方法...", "步骤A"])  # 权利要求组
doc.add_sep_line()                    # 空行（仅节间/权利要求组间使用）
doc.add_page_break()                  # 分页
doc.save("output.docx")
```

**从文件构建完整文档（推荐）**：
```python
from references.patent_format import PatentDoc

PatentDoc.build_from_files(
    abstract_path="output/abstract.txt",
    claims_path="output/claims_final.txt",
    specification_path="output/full_patent.txt",
    title="一种通信方法及装置",
    output_path="专利_一种通信方法及装置.docx"
)
```

**空行规则（关键）**：
- add_sep_line() 仅用于节间（技术领域→背景技术→发明内容→附图说明→具体实施方式）和权利要求组间
- 同节内正文段落间禁止使用 add_sep_line()
- 首条权利要求前禁止使用 add_sep_line()
```

3. 确保 `pip install python-docx` 已安装

## 快速使用

```python
from patent_format import PatentDoc

doc = PatentDoc()
doc.add_page_title("说明书")
doc.add_invention_title("一种通信方法及装置")
doc.add_section_title("技术领域")
doc.add_body_para("本申请涉及通信技术领域，尤其涉及一种通信方法及装置。")
doc.save("output.docx")
```

## 依赖

pip install python-docx

## 格式规范摘要

| 元素 | 字体 | 字号 | 格式 |
|------|------|------|------|
| 页标题 | 楷体 | 10.5pt | 加粗、居中、底部黑线+左侧方块 |
| 发明名称 | 楷体 | 10.5pt | 居中（不加粗） |
| 章节标题 | 楷体 | 10.5pt | 加粗、下划线 |
| 正文 | 楷体+Times New Roman | 10.5pt | 首行缩进2字符 |
| 权利要求 | 楷体+Times New Roman | 10.5pt | 首行缩进2字符 |

## 段落间距规则（关键！）

add_sep_line() 的使用规则：

**正文中仅以下5处节间使用 add_sep_line()**：
  技术领域末尾 → 背景技术
  背景技术末尾 → 发明内容
  发明内容末尾 → 附图说明
  附图说明末尾 → 具体实施方式

**同节内正文段落间禁止使用 add_sep_line()**（所有正文段落连续排列）

**权利要求**：
  不同权利要求条目间：1个 add_sep_line()
  同条内子步骤间：无空行
  首条权利要求前：无空行（页标题后直接接第一条权利要求）

**说明书附图**：
  每幅图后：1个 add_sep_line()

## 正确示例

```python
# 正确：节间有空行
D.add_section_title("技术领域")
D.add_body_para("本申请涉及...")
D.add_sep_line()  # ← 节间空行

D.add_section_title("背景技术")
D.add_body_para("第一段...")
D.add_body_para("第二段...")  # ← 同节内无空行
D.add_body_para("第三段...")
D.add_sep_line()  # ← 节间空行

# 错误：同节内加空行
D.add_section_title("背景技术")
D.add_body_para("第一段...")
D.add_sep_line()  # ← 错误！同节内不应有空行
D.add_body_para("第二段...")
```

## 权利要求正确示例

```python
D.add_page_title("权利要求书", after=240)
# 注意：首条前无空行
D.add_claim_group(["1. 一种通信方法，...", "步骤A；", "步骤B。"])
D.add_sep_line()  # 组间空行
D.add_claim_group(["2. 根据权利要求1所述的方法，..."])
D.add_sep_line()  # 组间空行
D.add_claim_group(["3. 根据权利要求1所述的方法，..."])
```
"""

import os
from docx import Document
from docx.shared import Pt, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn, nsdecls
from docx.oxml import parse_xml


class PatentDoc:
    """专利申请文件DOCX生成器"""

    def __init__(self):
        self.doc = Document()
        self._setup_normal_style()
        self._setup_page()

    def _setup_normal_style(self):
        """设置Normal样式：楷体10.5pt，行距固定15pt"""
        style = self.doc.styles['Normal']
        style.font.name = '楷体'
        style.font.size = Pt(10.5)
        rPr = style.element.rPr
        rPr.rFonts.set(qn('w:eastAsia'), '楷体')
        rPr.rFonts.set(qn('w:ascii'), 'Times New Roman')
        rPr.rFonts.set(qn('w:hAnsi'), 'Times New Roman')
        rPr.rFonts.set(qn('w:cs'), 'Times New Roman')
        style.paragraph_format.line_spacing = Pt(15)
        style.paragraph_format.space_before = Pt(0)
        style.paragraph_format.space_after = Pt(0)
        style.paragraph_format.first_line_indent = Cm(0)

    def _setup_page(self):
        """页面设置：A4，标准页边距"""
        for section in self.doc.sections:
            section.top_margin = Cm(2.54)
            section.bottom_margin = Cm(2.54)
            section.left_margin = Cm(3.18)
            section.right_margin = Cm(3.18)

    def _add_run(self, p, text, bold=False, underline=False, size=10.5):
        """添加文字run，中文楷体+英文Times New Roman"""
        run = p.add_run(text)
        run.bold = bold
        run.font.size = Pt(size)
        run.font.name = '楷体'
        rPr = run._element.get_or_add_rPr()
        rFonts = parse_xml(
            f'<w:rFonts {nsdecls("w")} w:eastAsia="楷体" '
            f'w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:cs="Times New Roman"/>'
        )
        rPr.append(rFonts)
        if underline:
            run.underline = True
        return run

    # ==================== 页标题 ====================

    def add_page_title(self, text, after=312):
        """
        添加页标题（说明书/权利要求书/说明书摘要/说明书附图）

        格式：居中、加粗、底部黑色实线+左侧方块、导航窗格可见、字间4空格

        Args:
            text: 标题文字，如 "说明书"
            after: 段后间距(twips)，说明书/附图=312，权利要求书/摘要=240
        """
        p = self.doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.line_spacing = Pt(15)
        p.paragraph_format.space_after = Pt(after / 20)
        p.paragraph_format.space_before = Pt(0)
        p.paragraph_format.first_line_indent = Cm(0)

        # 大纲级别（导航窗格可见）
        pPr = p._element.get_or_add_pPr()
        pPr.append(parse_xml(f'<w:outlineLvl {nsdecls("w")} w:val="0"/>'))

        # 底部黑色实线 + 左侧细线（产生左侧方块效果）
        pBdr = parse_xml(
            f'<w:pBdr {nsdecls("w")}>'
            f'<w:left w:val="single" w:sz="4" w:space="4" w:color="000000"/>'
            f'<w:bottom w:val="single" w:sz="12" w:space="1" w:color="000000"/>'
            f'</w:pBdr>'
        )
        pPr.append(pBdr)

        # 文字间加4个半角空格，各自独立run
        chars = list(text)
        for i, ch in enumerate(chars):
            self._add_run(p, ch, bold=True, size=10.5)
            if i < len(chars) - 1:
                self._add_run(p, "    ", bold=True, size=10.5)
        return p

    # ==================== 发明名称 ====================

    def add_invention_title(self, text):
        """
        添加发明名称

        格式：居中、不加粗、行距自动、段后312twips

        Args:
            text: 发明名称，如 "一种通信方法及装置"
        """
        p = self.doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.paragraph_format.line_spacing = Pt(18)
        p.paragraph_format.space_after = Pt(15.6)
        p.paragraph_format.space_before = Pt(0)
        p.paragraph_format.first_line_indent = Cm(0)
        self._add_run(p, text, bold=False, size=10.5)
        return p

    # ==================== 章节标题 ====================

    def add_section_title(self, text):
        """
        添加章节标题（技术领域/背景技术/发明内容/附图说明/具体实施方式）

        格式：加粗+下划线、左对齐、无段前段后

        Args:
            text: 章节标题文字
        """
        p = self.doc.add_paragraph()
        p.paragraph_format.line_spacing = Pt(15)
        p.paragraph_format.space_before = Pt(0)
        p.paragraph_format.space_after = Pt(0)
        p.paragraph_format.first_line_indent = Cm(0)
        self._add_run(p, text, bold=True, underline=True, size=10.5)
        return p

    # ==================== 正文 ====================

    def add_body_para(self, text):
        """
        添加正文段落

        格式：首行缩进2字符(420twips)、行距固定15pt、无段前段后

        Args:
            text: 段落文字
        """
        p = self.doc.add_paragraph()
        p.paragraph_format.line_spacing = Pt(15)
        p.paragraph_format.space_before = Pt(0)
        p.paragraph_format.space_after = Pt(0)
        p.paragraph_format.first_line_indent = Pt(21)
        self._add_run(p, text, size=10.5)
        return p

    # ==================== 权利要求 ====================

    def add_claim_para(self, text):
        """
        添加权利要求段落

        格式：首行缩进2字符(420twips)、行距固定15pt

        Args:
            text: 权利要求文字
        """
        p = self.doc.add_paragraph()
        p.paragraph_format.line_spacing = Pt(15)
        p.paragraph_format.space_before = Pt(0)
        p.paragraph_format.space_after = Pt(0)
        p.paragraph_format.first_line_indent = Pt(21)
        self._add_run(p, text, size=10.5)
        return p

    def add_claim_group(self, texts):
        """
        添加一条权利要求（可能含多个子步骤段落）

        同一条内子步骤间无空行。
        调用方负责在不同条之间调用 sep_line()。

        Args:
            texts: 权利要求文字列表，如 ["1. 一种通信方法，...", "接收第一配置信息..."]
        """
        if isinstance(texts, str):
            # 防御：误传整段字符串时按行切分，避免逐字成段
            texts = [ln for ln in texts.splitlines() if ln.strip()]
        for text in texts:
            self.add_claim_para(text)

    # ==================== 空行 ====================

    def add_sep_line(self):
        """添加节间空行（1个空段落）"""
        p = self.doc.add_paragraph()
        p.paragraph_format.line_spacing = Pt(15)
        p.paragraph_format.space_before = Pt(0)
        p.paragraph_format.space_after = Pt(0)
        p.paragraph_format.first_line_indent = Cm(0)
        self._add_run(p, "", size=10.5)
        return p

    # ==================== 分页 ====================

    def add_page_break(self):
        """添加分页符"""
        self.doc.add_page_break()

    # ==================== 保存 ====================

    def save(self, path):
        """保存DOCX文件"""
        self.doc.save(path)
        print(f"Patent DOCX saved: {path}")

    # ==================== 从文件构建完整专利文档 ====================

    @staticmethod
    def build_from_files(abstract_path, claims_path, specification_path,
                         title, output_path):
        """
        从文本文件构建完整的专利申请 DOCX 文档（说明书摘要 + 权利要求书 + 说明书）。

        Args:
            abstract_path: str, 说明书摘要文本文件路径
            claims_path: str, 权利要求书文本文件路径
            specification_path: str, 说明书全文文本文件路径（含【】章节标记）
            title: str, 发明名称
            output_path: str, 输出 DOCX 路径

        Returns:
            PatentDoc 实例

        文本文件格式约定:
            1. abstract.txt: 一段纯文本，无章节标记
            2. claims_final.txt: 每行一条权利要求，空行表示权项间的分隔
            3. full_patent.txt（说明书）: 以【技术领域】【背景技术】等标记段落，
               段落间用空行分隔。节标记独占一行，紧跟空行，再跟正文段落。

        空行规则（依据专利模板规范）:
            - 节间使用 add_sep_line() 空行
            - 同节内正文段落间不使用 add_sep_line()
            - 权利要求项间使用 add_sep_line()
            - 同条内子步骤间不使用 add_sep_line()
        """
        doc = PatentDoc()

        # ===== 第一部分：说明书摘要 =====
        doc.add_page_title("说明书摘要", after=240)
        with open(abstract_path, 'r', encoding='utf-8') as f:
            abstract_text = f.read().strip()
        doc.add_body_para(abstract_text)

        doc.add_page_break()

        # ===== 第二部分：权利要求书 =====
        doc.add_page_title("权利要求书", after=240)
        with open(claims_path, 'r', encoding='utf-8') as f:
            claims_text = f.read().strip()

        was_blank = True  # 上一条是否空行（初始为True表示首条前不加sep_line）
        for line in claims_text.split('\n'):
            line = line.strip()
            if not line:
                was_blank = True
                continue
            if not was_blank:
                # 上一条不是空行→新权项开始，加sep_line（权项间空行）
                doc.add_sep_line()
            doc.add_claim_para(line)
            was_blank = False

        doc.add_page_break()

        # ===== 第三部分：说明书 =====
        doc.add_page_title("说明书")
        doc.add_invention_title(title)

        with open(specification_path, 'r', encoding='utf-8') as f:
            spec_text = f.read().strip()

        # 按空行分段
        paragraphs = [p.strip() for p in spec_text.split('\n\n') if p.strip()]

        first_para = True
        for para_str in paragraphs:
            # 判断是否为章节标记（以【开头、】结尾的独立行）
            if para_str.startswith('【') and para_str.endswith('】'):
                # 除第一个节外，节前加空行
                if not first_para:
                    doc.add_sep_line()
                doc.add_section_title(para_str)
                first_para = False
            else:
                doc.add_body_para(para_str)

        doc.save(output_path)
        return doc


# ==================== 便捷函数（兼容旧版API） ====================

def page_title(doc, text, after=312):
    """页标题便捷函数（兼容独立Document对象）"""
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.line_spacing = Pt(15)
    p.paragraph_format.space_after = Pt(after / 20)
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.first_line_indent = Cm(0)
    pPr = p._element.get_or_add_pPr()
    pPr.append(parse_xml(f'<w:outlineLvl {nsdecls("w")} w:val="0"/>'))
    pBdr = parse_xml(
        f'<w:pBdr {nsdecls("w")}>'
        f'<w:left w:val="single" w:sz="4" w:space="4" w:color="000000"/>'
        f'<w:bottom w:val="single" w:sz="12" w:space="1" w:color="000000"/>'
        f'</w:pBdr>'
    )
    pPr.append(pBdr)
    chars = list(text)
    for i, ch in enumerate(chars):
        _add_run_raw(p, ch, bold=True, size=10.5)
        if i < len(chars) - 1:
            _add_run_raw(p, "    ", bold=True, size=10.5)
    return p


def invention_title(doc, text):
    """发明名称便捷函数"""
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.line_spacing = Pt(18)
    p.paragraph_format.space_after = Pt(15.6)
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.first_line_indent = Cm(0)
    _add_run_raw(p, text, bold=False, size=10.5)
    return p


def section_title(doc, text):
    """章节标题便捷函数"""
    p = doc.add_paragraph()
    p.paragraph_format.line_spacing = Pt(15)
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(0)
    p.paragraph_format.first_line_indent = Cm(0)
    _add_run_raw(p, text, bold=True, underline=True, size=10.5)
    return p


def body_para(doc, text):
    """正文段落便捷函数"""
    p = doc.add_paragraph()
    p.paragraph_format.line_spacing = Pt(15)
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(0)
    p.paragraph_format.first_line_indent = Pt(21)
    _add_run_raw(p, text, size=10.5)
    return p


def claim_para(doc, text):
    """权利要求段落便捷函数"""
    p = doc.add_paragraph()
    p.paragraph_format.line_spacing = Pt(15)
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(0)
    p.paragraph_format.first_line_indent = Pt(21)
    _add_run_raw(p, text, size=10.5)
    return p


def sep_line(doc):
    """节间空行便捷函数"""
    p = doc.add_paragraph()
    p.paragraph_format.line_spacing = Pt(15)
    p.paragraph_format.space_before = Pt(0)
    p.paragraph_format.space_after = Pt(0)
    p.paragraph_format.first_line_indent = Cm(0)
    _add_run_raw(p, "", size=10.5)
    return p


def _add_run_raw(p, text, bold=False, underline=False, size=10.5):
    """内部run创建函数"""
    run = p.add_run(text)
    run.bold = bold
    run.font.size = Pt(size)
    run.font.name = '楷体'
    rPr = run._element.get_or_add_rPr()
    rFonts = parse_xml(
        f'<w:rFonts {nsdecls("w")} w:eastAsia="楷体" '
        f'w:ascii="Times New Roman" w:hAnsi="Times New Roman" w:cs="Times New Roman"/>'
    )
    rPr.append(rFonts)
    if underline:
        run.underline = True
    return run


# ==================== 使用示例 ====================


def add_comment(para, text, author="撰写助手", initials="AI"):
    """为段落添加批注（修订模式批注，python-docx >= 1.2.0 原生支持）。

    用途：按 Phase 3 第5章规则，具体实施方式不写"实施例一/二"标签，
    实施例与权要/附图的对应关系改用 DOCX 批注标明，例如：
        p = doc.add_body_para("在一种可能的实现方式中，……")
        add_comment(p, "对应权利要求5；对应图6实施例")

    Args:
        para: 段落对象（add_body_para 等的返回值若为 None，可改用 doc.paragraphs[-1]）
        text: 批注内容
        author/initials: 批注署名
    Returns:
        Comment 对象
    """
    doc = para.part.document if hasattr(para.part, "document") else None
    # python-docx 1.2.0: Document.add_comment(runs=..., text=..., author=..., initials=...)
    from docx import Document as _Doc
    _d = para._parent
    while _d is not None and not hasattr(_d, "add_comment"):
        _d = getattr(_d, "_parent", None)
    if _d is None or not hasattr(_d, "add_comment"):
        raise RuntimeError("未找到 Document 对象，或 python-docx 版本过低（需 >= 1.2.0）")
    return _d.add_comment(runs=para.runs, text=text, author=author, initials=initials)

if __name__ == "__main__":
    # 示例：生成一个最小化的专利申请文件
    doc = PatentDoc()

    doc.add_page_title("说明书")
    doc.add_invention_title("一种通信方法及装置")
    doc.add_sep_line()

    doc.add_section_title("技术领域")
    doc.add_body_para("本申请涉及通信技术领域，尤其涉及一种通信方法及装置。")
    doc.add_sep_line()

    doc.add_section_title("背景技术")
    doc.add_body_para("在无线通信系统中...")
    doc.add_sep_line()

    doc.add_section_title("发明内容")
    doc.add_body_para("本申请实施例提供一种通信方法及装置...")
    doc.add_sep_line()

    doc.add_section_title("附图说明")
    doc.add_body_para("图1为本申请实施例提供的一种通信系统的架构示意图；")
    doc.add_sep_line()

    doc.add_section_title("具体实施方式")
    doc.add_body_para("为便于理解本申请实施例，首先做出以下几点说明。")
    doc.add_sep_line()

    doc.add_page_break()

    doc.add_page_title("权利要求书", after=240)
    doc.add_sep_line()

    # 权利要求（组间空行）
    doc.add_claim_group([
        "1. 一种通信方法，其特征在于，所述方法包括：",
        "步骤A；",
        "步骤B。",
    ])
    doc.add_sep_line()
    doc.add_claim_group(["2. 根据权利要求1所述的方法，其特征在于，..."])
    doc.add_sep_line()
    doc.add_claim_group(["3. 根据权利要求1所述的方法，其特征在于，..."])

    doc.add_page_break()
    doc.add_page_title("说明书摘要", after=240)
    doc.add_body_para("本申请提供一种通信方法及装置...")

    doc.add_page_break()
    doc.add_page_title("说明书附图", after=312)

    doc.save("示例_专利申请文件.docx")