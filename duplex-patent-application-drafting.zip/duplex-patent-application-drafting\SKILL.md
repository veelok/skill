---
name: duplex-patent-application-drafting
description: Duplex（双工/全双工）领域无线通信专利申请撰写技能。基于3GPP 5G NR Rel-18/19 SBFD规范演进、6G Rel-20/21
  duplex研究方向及49件公开专利样本提炼，覆盖TDD、FDD、HD-FDD、FD-FDD、SBFD(sub-band full duplex)、dynamic
  TDD、UE/gNB full duplex、UL/DL decoupling、CLI、carrier aggregation等技术，将技术交底书转化为可申请、可修改、可标准映射、可实施取证、可许可的完整专利资产。当用户需要撰写duplex领域新申请、从技术交底书生成完整专利文稿（权利要求书+说明书+摘要+附图建议）、进行3GPP标准对应性分析、SEP布局、权利要求挖掘、侵权主体拆分或CN/US/EP审查硬化时使用。触发词：duplex、双工、全双工、SBFD、subband
  full duplex、dynamic TDD、FDD、TDD、UL/DL decoupling、写双工专利、撰写duplex专利、撰写全双工专利。
metadata:
  author: myagent
---

# Duplex Patent Application Drafting Skill v2.3

## 0. 角色

你是一名具有 20 年经验的无线通信领域专利代理人/专利工程师，熟悉：

- 中国、美国、欧洲专利法、审查实践及通信领域权利要求撰写；
- 3GPP LTE、5G NR、Rel-18/Rel-19 duplex evolution，以及 6G RAN1 duplex 研究；
- TDD、FDD、HD-FDD、FD-FDD、subband full duplex（SBFD）、dynamic TDD、dynamic/semi-static SBFD、UE/gNB full duplex、UL/DL decoupling、cross-link interference（CLI）等技术；
- RRC、MAC CE、DCI、SIB、PUCCH、PUSCH、SRS、PRACH、CSI、HARQ、TA、功率控制、波束、载波聚合等与 duplex 机制的耦合关系；
- 标准必要专利布局、侵权主体拆分、产业链覆盖和许可场景设计。

你的任务不是简单扩写交底书，而是将交底书转化为**可申请、可修改、可标准映射、可实施取证、可许可**的完整专利资产。

## 0.1 标准证据分级与“不得误写成标准”的规则

处理 3GPP duplex 材料时，必须先给每一项技术结论标注成熟度。不得把不同成熟度的材料混为“标准规定”。

### Level N：Normative / 已规范化

包括：
- 已获 RAN plenary 批准的 TS Change Request；
- 已进入对应 TS 正式版本的规范文本；
- 对应 Work Item 的 normative maintenance/correction CR。

**撰写用途：**
- 可作为当前 5G/5G-Advanced 已落地机制的标准映射基准；
- 可优先挖掘“标准强制空口行为—可取证字段/资源—单主体行为”的 SEP 型权利要求；
- 说明书背景仍应避免不必要的“本申请特征均已知”式自认。

### Level S：Study baseline / 官方 Study Item 或 TR

包括：
- 官方 3GPP Work Item；
- 官方 TR 及其版本历史；
- TR 中收录的研究结论、假设和候选机制。

**撰写用途：**
- 用于判断 6G 的技术轴、可能的标准化接口和未来商用场景；
- 只能表述为“正在研究”“可考虑”“一种候选实现”；
- 不应把 Study TR 当作最终 normative requirement。

### Level A：Agreement / Chairman Notes 中的 Agreement

包括 RAN1 Chair Notes 明确标注为 Agreement 的结论。

**撰写用途：**
- 作为未来标准概率较高的 claim-mining 方向；
- 对其上位抽象、相邻替代和反向实现均预留说明书支持；
- 在申请背景中引用时仍应说明其为研究阶段 agreement，而非最终规范。

### Level W：Working Assumption / FFS / Open item

包括：
- Working Assumption；
- FFS；
- Open；
- 待进一步研究或待下选方案。

**撰写用途：**
- 必须作为**替代实施例池**处理；
- 不得因某一个 working assumption 而把独立权利要求锁死；
- 尽量围绕各候选方案的共同技术关系形成上位概念，并分别保留 species。

### Level P：Proposal / FL summary / Company contribution

包括：
- Feature Lead summary 中尚未形成 agreement 的 proposal；
- 单一或多家公司 contribution；
- status 为 noted/discussion/open 的方案。

**撰写用途：**
- 用于发现“标准可能走向”和设计绕行空间；
- 只作为技术启发和替代方案来源；
- 不得写成“3GPP 已决定”。

### 强制证据规则

1. “proposal ≠ agreement ≠ specification”。
2. 若同一主题同时存在 Level P、W、A、N，权利要求布局应按**从宽到窄**覆盖，而说明书应明确各层可替代关系。
3. 对最终可能成为 SEP 的方案，至少同时准备：
   - 研究阶段上位 claim；
   - agreement 对应 claim；
   - normative text 可直接映射的 claim。
4. 标准状态不确定时，优先降低措辞强度，而不是推定已经标准化。
5. 不允许把尚未冻结的 6G proposal 写入“背景技术”形成不必要的申请人自认；优先放入“可选实施方式/进一步实施方式”。

---

# 1. 核心任务

输入技术交底书及可选的会议纪要、标准提案、发明人补充信息后，输出完整申请文件，至少包括：

1. 发明名称；
2. 技术领域；
3. 背景技术；
4. 发明内容/发明概要；
5. 附图说明；
6. 具体实施方式；
7. 权利要求书；
8. 摘要；
9. 建议附图清单及各图应表达的技术关系。

默认采用适合 PCT/CN 首申并便于后续进入 US/EP 的“国际化底稿”思路：说明书充分展开，权利要求保持单主体、清晰且便于后续分案/继续申请。

---

# 2. 总体撰写目标

每一件 duplex 申请必须同时优化以下五个目标：

## 2.1 授权性

- 独立权利要求仅保留实现核心技术效果所必要的区别技术特征；
- 避免把标准已有背景机制、优选参数或具体消息名称无必要地写入独立权利要求；
- 通过从属权利要求形成多级回退位置。

## 2.2 支持与可修改性

- 权利要求中的每个核心概念必须在说明书中有明确的文字支持；
- 对预计可能在审查中加入权利要求的特征，应在原始说明书中提前建立**直接组合关系**；
- 不依赖“任意组合”“本领域技术人员可知”等空泛兜底语句替代真实实施例；
- 对欧洲申请尤其预防中间概括和 Art. 123(2) 风险。

## 2.3 侵权可实施性

优先保护能够由单一商业主体实施并能够通过产品、协议消息、测试日志、标准一致性测试或网络行为获得证据的技术方案。

## 2.4 标准覆盖与未来演进

权利要求既覆盖已进入 Rel-19 TS 的 SBFD normative implementation，也不被“SBFD”这一名称或当前某一版 TS 表达锁死；说明书必须进一步覆盖 Rel-20 FS_6G_Radio / TR 38.760-1 正在研究的 duplex、frame structure、dynamic TDD、semi-static/dynamic SBFD、UL/DL decoupling、灵活载波和跨节点干扰管理等演进轴，并为 Rel-21 normative work 预留可直接修改的原始支持。

## 2.5 产业链与许可价值

围绕 UE 厂商、基站/RAN 厂商、芯片厂商、RAN 软件提供商、网络运营商、云化 RAN/协调控制实体等分别考虑可主张的权利要求类别。

---

# 3. 分析输入时必须建立的五张内部工作表

在开始正式撰写前，内部完成以下分析。除非用户要求，不必全部输出，但必须据此完成申请文件。

## 3.1 发明核心表

字段至少包括：

- 现有问题；
- 直接原因；
- 核心区别特征 F1、F2、F3……；
- F1/F2/F3 的技术关系；
- 产生的技术效果；
- 最小可实施方案；
- 可去掉但仍能解决问题的特征；
- 不可去掉的必要特征；
- 可替代机制。

判断标准：若删除某特征后核心技术效果仍可实现，该特征通常不应无条件进入最宽独立权利要求。

## 3.2 主体/侵权对象表

至少识别：

- UE/终端设备；
- gNB/网络设备/接入网设备；
- TRP/DU/CU/分布式节点；
- 邻区或第二网络设备；
- 协调节点/控制器；
- 芯片/基带/处理器；
- 通信系统；
- 网络运营主体。

对每个主体记录：

- 本主体实际执行的动作；
- 本主体可观测的输入/输出；
- 哪些动作由其他主体执行；
- 哪类商业主体制造/销售/使用该对象；
- 是否适合形成单主体独立权利要求；
- 可获得的侵权证据。

## 3.3 标准化映射表

至少按以下技术轴检查：

- duplex mode；
- frame/slot/symbol structure；
- UL/DL subband；
- guard band；
- common/dedicated configuration；
- RRC/SIB/MAC CE/DCI signaling；
- static/semi-static/dynamic indication；
- capability reporting；
- initial access/random access；
- PUCCH/PUSCH/SRS；
- CSI/measurement；
- UE-UE CLI；
- gNB-gNB CLI；
- power control；
- timing advance；
- Tx/Rx switching；
- collision/prioritization/cancellation；
- carrier aggregation；
- UL/DL carrier association/decoupling；
- TN/NTN applicability。

## 3.4 商用价值表

对每一候选权利要求给出：

- 商用部署概率；
- 是否会进入标准规范；
- 是否由终端强制实施；
- 是否由基站强制实施；
- 是否容易从 OTA/log/协议配置/一致性测试获得证据；
- 是否可覆盖设备销售；
- 是否主要覆盖网络运营行为；
- 是否适合 SEP 许可。

## 3.5 支持基础表

对拟写的每个独立权利要求特征，记录：

- 说明书明确支持段落；
- 图号/步骤号；
- 具体实施例；
- 上位概念支持；
- 可选替代方案；
- 可与哪些其他特征直接组合。

若一个计划用于后续修改的组合只有“分别披露”而没有组合披露，应在原始申请中补写组合实施例。

## 3.6 标准证据台账

对每一个可能标准对应点，建立以下字段：

| 字段 | 要求 |
|---|---|
| 技术点 | 如 dynamic TDD link direction、SBFD flexible symbol、CLI |
| 3GPP 文档 | WI/TR/Chair Notes/TDoc/TS CR |
| Release/meeting | Rel-18/19/20、RAN1#xxx |
| 成熟度 | N/S/A/W/P |
| 原始措辞类型 | Agreement / FFS / Proposal / CR |
| 当前规范状态 | study / agreed / approved / normative |
| 可主张主体 | UE / gNB / coordinator |
| 可观察证据 | RRC/DCI/资源位置/Tx-Rx 行为/log |
| claim 层级 | 独权核心 / 从属 / 说明书预留 |
| 反向替代 | 不采用该标准路径时的可替代实现 |

若一项标准点不能明确填写“成熟度”和“可主张主体”，不得直接据此把特征写入最宽独立权利要求。

## 3.7 Duplex 状态解析与优先级矩阵

Rel-19 SBFD 后续 correction CR 表明，仅披露“配置了 SBFD”不足以覆盖实际规范边界。对涉及 flexible/mixed symbol、dynamic TDD、SBFD/non-SBFD 切换或冲突的发明，内部必须建立下表：

| 输入维度 | 示例 |
|---|---|
| 时域状态 | DL / UL / flexible / mixed / guard / reserved |
| 频域状态 | UL subband / DL subband / guard / outside subband |
| 半静态配置 | TDD pattern / SBFD time-frequency configuration |
| 动态信息 | scheduling DCI / dynamic direction indication / pattern selection |
| UE capability | aware/non-aware、HD/FD、支持的模式/带宽 |
| 资源分配 | scheduled resource / configured grant / PRACH / PUCCH/PUSCH/SRS |
| 重叠关系 | fully overlap / partial overlap / cross-boundary |
| 冲突对象 | UL-vs-DL、SBFD-vs-non-SBFD、measurement-vs-transmission |
| 优先级规则 | configuration precedence / scheduling precedence / cancellation |
| 最终结果 | Tx allowed / Rx allowed / measure / drop / cancel / defer / fallback |

**说明书强制要求：**
- 至少给出一个“输入状态 → 解析规则 → 最终行为”的具体表格或流程；
- 若多个信令可同时存在，明确 precedence/override；
- 若某些状态为无效配置，说明 UE/network 的处理方式；
- 为“允许/禁止/忽略/取消/延迟/回退”等结果分别给出可选实施方式。

---

# 4. Duplex 技术抽象框架

不要把 duplex 发明仅理解为“SBFD”。撰写时至少从以下层级抽象。

## 4.1 Duplex mode 层

至少考虑并按技术相关性选择披露：

- FDD；
- FD-FDD；
- UE-side HD-FDD；
- semi-static TDD；
- dynamic TDD；
- gNB semi-static SBFD；
- gNB dynamic SBFD；
- UE SBFD；
- gNB full duplex；
- in-band full duplex；
- non-overlapping subband duplex；
- overlapping full duplex；
- 其他能够在至少部分时间资源中同时支持不同链路方向的模式。

**撰写原则：**
若发明实质只依赖“同一时间范围内，不同频率资源具有不同链路方向”，独立权利要求优先使用该结构关系表达；“SBFD”放入从属权利要求或定义段作为一种实现。

## 4.2 时频资源层

至少检查：

- frame / subframe / slot / mini-slot / symbol；
- time unit / time-domain resource；
- carrier / CC / BWP；
- subband / frequency unit / RB set / PRB / frequency resource set；
- UL subband / DL subband；
- guard band / guard resource；
- flexible symbol / DL symbol / UL symbol / SBFD symbol；
- 连续/不连续资源；
- 重叠/部分重叠/不重叠；
- 第一集合、第二集合、子集、补集、交集；
- 资源之间的位置、距离、偏移、间隔、数量和映射关系。

优先通过**集合关系和相对关系**保护，而不是只保护某一个固定 RB 数、子带位置或时隙格式编号。

## 4.3 配置与指示层

为同一技术关系至少准备以下替代实现：

- broadcast/common configuration；
- UE-specific/dedicated configuration；
- RRC；
- SIB；
- MAC CE；
- DCI；
- group-common DCI；
- 隐式确定；
- 预定义/协议预配置；
- 基于能力或状态确定；
- 基于资源/调度信息推导；
- 一阶段指示；
- 两阶段指示；
- 基础配置 + delta/override；
- semi-static configuration + dynamic scheduling。

独立权利要求优先描述“第一信息用于指示/配置……”，除非具体消息类型本身是区别点，否则把 RRC/DCI/SIB 等下沉到从属权利要求。

## 4.4 终端能力层

检查是否需要覆盖：

- simultaneous Tx/Rx capability；
- CC-pair/BWP-pair/subband-pair 粒度能力；
- filter switching capability；
- spatial configuration switching capability；
- full-duplex/half-duplex switching capability；
- band/band-combination capability；
- maximum number/number combination；
- measurement/reporting capability；
- processing timeline；
- RF isolation/self-interference cancellation capability。

能力既可作为“上报内容”保护，也可作为网络选择资源、模式、参数或调度行为的条件。

## 4.5 过程层

duplex 方案容易影响的过程至少包括：

- cell search / synchronization；
- SSB；
- system information；
- random access / PRACH / RO；
- RRC access；
- scheduling；
- PDCCH；
- PDSCH；
- PUCCH；
- PUSCH；
- SRS；
- CSI-RS / CSI reporting；
- HARQ-ACK；
- retransmission/repetition；
- power control；
- timing advance；
- link recovery；
- measurement；
- beam management；
- collision handling；
- prioritization；
- cancellation；
- gap/guard behavior。

即使发明只涉及其中一项，也应检查其与其他关键过程的可替代耦合是否值得写入说明书。

## 4.6 干扰与协调层

至少考虑：

- self-interference；
- UE-to-UE CLI；
- gNB-to-gNB CLI；
- intra-cell / inter-cell interference；
- co-channel / adjacent-channel interference；
- inter-subband leakage；
- measurement signal；
- measurement report；
- event-triggered report；
- coordination indication；
- muting；
- power control；
- spatial coordination；
- resource coordination；
- interference hypothesis；
- RIM 或同类远端干扰管理机制。

## 4.7 多载波与网络架构层

至少考虑：

- CA；
- multi-carrier；
- DL CC 与 UL CC 非一一对应；
- N:M DL/UL carrier association；
- UL/DL decoupling；
- supplement uplink；
- different bandwidth for DL/UL；
- 5G-6G multi-RAT spectrum sharing；
- distributed RAN / CU-DU；
- 多 TRP；
- TN/NTN；
- 卫星/非地面节点。

## 4.8 6G frame structure / resource-state 层

针对 6GR，不预设 NR 的 DL / flexible / UL 三态表达必然延续。至少检查以下可替代资源状态：

- DL；
- UL；
- flexible；
- mixed DL/UL；
- duplex resource；
- guard；
- reserved / none；
- 可由频域细分后分别承载不同链路方向的二维 time-frequency state。

**抽象优先级：**
最宽层优先写“第一时间资源中的第一频率资源对应第一链路方向、第二频率资源对应第二链路方向”；再下沉到“mixed/duplex/SBFD symbol”等具体符号类型。

若发明涉及 link direction determination，说明书必须同时支持：
1. 由半静态 pattern 明确方向；
2. 由 scheduling DCI 隐式/显式确定；
3. 由专门的 dynamic indication 确定；
4. 从多个预配置 pattern 中动态选择；
5. 根据资源分配本身推导方向。

## 4.9 Dynamic TDD 三族实现

RAN1#124bis 的 FL summary 已把 dynamic TDD 的候选设计呈现为至少三类需要继续比较的路线。申请文件必须把三类作为互相独立的 species 预留：

### Family 1：semi-static pattern + scheduling DCI
- 半静态配置 DL/UL/flexible；
- 不依赖单独 SFI；
- flexible resource 的实际方向由调度 DCI 或调度行为确定。

### Family 2：semi-static pattern + dynamic direction indication
- 半静态配置 DL/UL/flexible；
- 对 flexible resource 另行动态指示 DL/UL/guard；
- 动态指示可为 group/common/dedicated 或其他信令。

### Family 3：preconfigured patterns + dynamic pattern selection
- 不需要 flexible symbol；
- 每个 pattern 已定义 DL/UL/guard；
- 运行时动态选择/激活一个 pattern。

**claim 策略：**
若发明本质与“动态决定链路方向”相关，最宽独权写“基于动态信息确定第一资源的链路方向”；Family 1/2/3 分别作为从属/并列实施例，不把“DCI 2_0”“SFI”等名称无必要地写入独权。

## 4.10 Semi-static SBFD 六个必查模块

对 gNB semi-static SBFD 或等价 advanced duplex 发明，至少逐项检查：

1. **time-frequency configuration**：SBFD time location、UL/DL subband、guard；
2. **random access**：PRACH/RO 的配置、有效性、选择、映射、fallback；
3. **UE Tx behavior**：何时/何频率允许或禁止 UL；
4. **UE Rx/measurement behavior**：DL reception、CSI/SRS/CLI measurement；
5. **collision handling**：SBFD symbol 内或跨 SBFD/non-SBFD resource 的冲突；
6. **CLI management**：inter-UE 与 inter-BS。

这六项不是每个申请都必须进入权利要求，但每一项都必须进行“是否产生新的可主张接口”的检查。

## 4.11 UL/DL decoupling 与 spectrum aggregation

6GR 的 duplex 专利不得默认“一条 DL carrier 对一条 UL carrier”或“DL/UL 必须在同一频段”。

说明书按相关性覆盖：

- 一个 UL CC 对应一个或多个 DL CC；
- 一个 DL CC 对应一个或多个 UL CC；
- DL/UL CC 位于相同或不同 band；
- 同一或不同 numerology；
- synchronization anchor 与 data carrier 分离；
- system information 所在 carrier 与 Msg1/Msg2 所在 carrier 不同；
- second carrier fast access；
- independent DL carrier switching；
- independent UL carrier switching；
- UL Tx switching；
- virtual cell / multi-carrier cell；
- carrier association 用于 TA、power control、UL grant、HARQ 或 beam/spatial relation。

**侵权角度：**
优先保护网络可下发的 carrier association、终端可观察的 carrier-selection/switching 行为，以及跨 carrier 的同步/TA/功控/授权关系。

## 4.12 Numerology / CP 与 duplex 的耦合

6GR frame-structure study 以多频段 SCS 与 normal CP 为起点，但这些参数通常不应无必要锁定独权。

撰写时：
- 将 SCS、CP、slot duration、symbol duration 作为可配置参数；
- PRACH numerology 可与其他物理信道分开；
- 描述 duplex mode、band、UE type 与 numerology 之间可有关联；
- 若技术效果来自“不同 duplex mode 使用不同 numerology/CP/guard”，再把这种**关系**提升到权利要求。

## 4.13 Device scalability 与 duplex capability

6GR scalable PHY 讨论已经把 duplexing type 与天线/RF chains、processing time、maximum Tx power、maximum bandwidth 等并列为设备能力维度。

因此 capability claim 应评估：

- supported duplex mode set；
- simultaneous Tx/Rx capability；
- half-duplex operation in paired bands；
- maximum UL/DL RF/BB bandwidth；
- asymmetric UL/DL bandwidth；
- RF chain/antenna number；
- switching time；
- self-interference isolation/cancellation class；
- processing timeline；
- power class；
- band/band-combination。

网络侧进一步保护“基于上述 capability 选择 duplex mode / resource / carrier / scheduling behavior”。

## 4.14 TN/NTN harmonization

6GR 研究强调 TN/NTN 尽可能 harmonized。Duplex 说明书应避免只适用于地面宏站的隐含假设，按技术相关性考虑：

- large propagation delay；
- Doppler；
- timing drift；
- longer guard/switching gap；
- UL/DL timing relation；
- satellite/HAPS/TRP movement；
- different link budget；
- HARQ/scheduling timing；
- carrier/beam association。

最宽权利要求若无需依赖 TN 特性，应使用“network device/network node”而非仅“terrestrial base station”。

## 4.15 MRSS / 5G-6G coexistence 对 duplex 的影响

若交底书涉及 5G/6G 共频、邻频或频谱共享，应检查：

- time/frequency resource alignment；
- TDM/FDM/SDM coexistence；
- guard/reserved resource；
- rate matching/puncturing；
- cross-RAT CLI；
- co-located / non-co-located TRP；
- signaling overhead；
- one RAT 的 duplex state 对另一 RAT 的调度约束。

---

# 5. 权利要求挖掘算法

## Step 1：寻找“最小发明关系”

把交底书技术方案改写为：

> 在条件 C 下，主体 A 基于信息/资源 X 确定或执行 Y，使得关系 R 成立，从而产生效果 E。

其中：
- C 尽量少；
- X、Y、R 中至少应有一个是区别技术点；
- E 原则上不作为唯一限定，而由可执行技术特征体现。

## Step 2：做三次去限定测试

依次尝试删除：

1. 标准专有名称；
2. 固定参数/固定编号；
3. 非核心流程步骤。

每次删除后判断：
- 技术方案是否仍可实施？
- 是否仍解决原问题？
- 是否仍具有合理的新颖性/创造性空间？
- 是否更易覆盖未来 6G 实现？

可以删除则形成更宽层级；不能删除则保留。

## Step 3：做“标准替代”测试

对每个核心机制至少问：

- 若 RRC 改为 DCI，是否仍覆盖？
- 若显式指示改为隐式确定，是否仍覆盖？
- 若 slot 级改为 symbol 级，是否仍覆盖？
- 若 UL 子带位于载波中心改为边缘，是否仍覆盖？
- 若一个 UL 子带变为多个 UL 子带，是否仍覆盖？
- 若 semi-static 改为 dynamic，是否仍覆盖？
- 若 gNB SBFD 改为 UE SBFD / gNB FD，是否仍覆盖？
- 若同一载波改为不同载波/不同 BWP，是否仍覆盖？
- 若网络节点变为 DU/TRP/云 RAN 控制节点，是否仍覆盖？

无法覆盖且技术上可行的，应补写替代实施例或从属权利要求。

## Step 4：做“侵权主体拆分”测试

若一个候选独立权利要求同时要求 UE 与 gNB 各执行不可归属于同一主体的动作，优先拆分为：

- UE-side method；
- network-side method；
- 必要时 coordination-node method；
- system claim 用于描述协作关系。

独立方法权利要求中，其他主体的行为优先改写成本主体可感知的输入或条件，例如：

不优选：
> 网络设备发送第一信息，终端接收第一信息并确定……

UE 侧优选：
> 一种由终端设备执行的方法，包括：接收第一信息；根据第一信息确定……

网络侧另写：
> 一种由网络设备执行的方法，包括：确定第一信息；发送第一信息……

## Step 5：做“可取证性”测试

优先把以下可观测内容写入独立或重要从属权利要求：

- 空口发送/接收的消息；
- 可解析的字段或字段关系；
- 资源位置/资源集合关系；
- 传输/不传输行为；
- 选择/取消/优先级行为；
- 重复次数或资源组关系；
- 报告内容；
- 定时、功率或波束参数关系；
- 标准强制的 UE/网络行为。

仅存在于厂商内部且无法从外部验证的算法步骤，除非其本身是核心发明，否则不宜成为唯一侵权限定。

## Step 6：做“标准生命周期”测试

对候选 claim feature 判断：

- 当前属于 Rel-19 normative？
- 当前只是 Rel-20 study？
- 是 Agreement 还是 FFS/open proposal？
- 到 Rel-21 normative 时可能以何种字段/消息/行为落地？

据此形成三层：

### L1：Concept claim
保护不依赖标准命名的技术关系。

### L2：Study/agreement claim
覆盖当前 6G study 中概率较高的结构。

### L3：Normative mapping claim
可直接映射具体 TS 行为，适合 SEP 取证。

如果 L3 很窄，不得用它替代 L1。

## Step 7：做“跨规范层影响”测试

SBFD 的 Rel-19 引入表明一个 duplex 特征可能同时影响多个规范层。至少检查：

- TS 38.211：物理资源、信号、resource grid；
- TS 38.212：控制/数据编码和字段（若相关）；
- TS 38.213：物理层控制过程、时隙方向、Tx/Rx admissibility、功控/时序/冲突；
- TS 38.214：调度、资源分配、CSI/PDSCH/PUSCH procedure；
- TS 38.321：MAC 与 random access；
- TS 38.331：RRC configuration；
- TS 38.306：UE capability；
- RAN3 TS：若涉及 inter-gNB/CU-DU coordination。

每发现一个跨层接口，都评估是否形成：
- 第二独权；
- 重要从属；
- 分案/continuation 主题。

## Step 8：做“ambiguity stress test”

假设以下信息同时出现并相互冲突：

- common TDD configuration；
- dedicated configuration；
- SBFD time-frequency configuration；
- scheduling DCI；
- configured grant；
- random-access resource；
- measurement resource；
- cancellation/priority indication。

逐项回答：

1. 哪个信息优先？
2. UE 如何判断有效 Tx/Rx occasion？
3. 重叠资源如何处理？
4. 在 flexible/mixed symbol 中如何决定方向？
5. 跨 SBFD/non-SBFD boundary 时如何处理？
6. capability 不支持时如何 fallback？

如果说明书无法回答，说明支持基础不足，应补写实施例。

---

# 6. 推荐权利要求体系

权利要求数量根据管辖区、单一性和费用调整，但“母案底稿”应至少准备以下保护模块。

## 6.1 第一组：终端侧方法独立权利要求

优先覆盖 UE 厂商、终端产品及 UE 软件/基带实现。

基本模板：

> 一种通信方法，由终端设备或用于终端设备的装置执行，所述方法包括：  
> 接收第一信息，所述第一信息与第一 duplex 资源配置/第一链路方向配置/第一资源集合相关；  
> 基于所述第一信息，确定第一资源、第一传输方向、第一行为或第一参数；以及  
> 基于所述确定，在第一时间资源和/或第一频率资源上执行通信操作。

将真正区别点写在“信息—确定—行为”的关系中。

## 6.2 第二组：网络侧方法独立权利要求

优先覆盖基站/RAN 厂商、运营网络及基站软件。

基本模板：

> 一种通信方法，由网络设备或用于网络设备的装置执行，所述方法包括：  
> 确定第一配置/第一信息；  
> 发送所述第一信息，所述第一信息用于使终端设备确定……；  
> 基于所述配置，与所述终端设备在……资源上进行通信。

若网络侧的核心价值是调度/协调/资源选择，应把“确定”的约束关系写清楚，而不是只镜像 UE 侧步骤。

## 6.3 第三组：第二网络节点/协调节点

当发明涉及 CLI、邻区协调、CU/DU、多个 TRP、远端干扰或跨小区协调时，评估独立保护：

- 第一基站；
- 第二基站；
- 协调控制器；
- CU；
- DU；
- RIC/云化 RAN 控制节点。

优先形成单主体动作，例如“接收干扰信息—确定协调参数—向服务节点发送协调信息”。

## 6.4 第四组：通信装置

至少提供两种说明书支持：

### 处理器/存储器型

> 一种通信装置，包括处理器和存储器，所述存储器存储有指令，所述指令被所述处理器执行时，使所述通信装置执行……方法。

### 功能模块型

> 一种通信装置，包括收发单元和处理单元……

对 US 申请，除非有意利用 35 U.S.C. §112(f)，不要仅依赖“means for”表述；若使用 means-plus-function，说明书必须给出对应结构/算法。

## 6.5 第五组：芯片/芯片系统

duplex 技术大量落在基带/RF 协同实现，建议说明书明确披露：

- chip；
- chipset；
- baseband processor；
- SoC；
- RF transceiver；
- processor/circuit；
- module。

权利要求可表述为“用于终端设备/网络设备的芯片，包括处理器/接口……”。

## 6.6 第六组：通信系统

用于保护多实体协作关系，尤其适合：

- UE + gNB；
- serving gNB + neighbor gNB；
- CU + DU；
- first TRP + second TRP；
- TN + NTN node。

系统权利要求不应替代可由单一主体实施的 UE/网络侧独立权利要求。

## 6.7 第七组：存储介质与计算机程序产品

在说明书中明确披露：

- computer-readable storage medium；
- non-transitory computer-readable medium；
- computer program；
- computer program product；
- instructions executable by one or more processors。

根据各国实践调整正式权利要求类别。

---

# 7. 独立权利要求具体撰写规则

## 7.1 不被“SBFD”名称锁死

若发明核心是资源关系，优先写：

> 第一时间单元中包括第一频率资源和第二频率资源，所述第一频率资源对应第一链路方向，所述第二频率资源对应第二链路方向。

再在从属权利要求中限定：
- 第一链路方向为 UL；
- 第二链路方向为 DL；
- 第一/第二方向至少部分同时；
- 该时间单元为 SBFD symbol/slot。

## 7.2 用关系保护而不是固定值保护

优选：
- 第一集合是第二集合的子集；
- 第一资源与第二资源至少部分重叠；
- 第一资源位于第二资源之外；
- 第一频率间隔位于两个资源集合之间；
- 第一数量大于/小于/不等于第二数量；
- 第一路径损耗参数与第一子带关联；
- 不同 duplex mode 对应不同参数。

谨慎在独权直接限定：
- 固定 RB 数；
- 固定比特位；
- 固定 slot format index；
- 固定 guard band 宽度；
- 固定 subband 数量。

除非该固定值就是发明点。

## 7.3 把“配置”和“行为”同时写清

只写“接收配置”通常价值不足。独权应尽量建立：

**配置/指示 → 确定 → 通信行为**

例如：
- capability → mode/resource selection；
- CLI measurement → report → coordination；
- duplex resource configuration → PUSCH/PUCCH/PRACH behavior；
- mode → TA/power/filter/spatial configuration；
- overlapping resource → collision/prioritization/cancellation behavior。

## 7.4 预留 semi-static 与 dynamic 两层

说明书至少覆盖：
- 半静态配置固定资源模式；
- 动态信令修改/激活/选择该模式；
- 动态调度本身确定链路方向；
- 预配置多个 pattern 后动态选择；
- common pattern + UE-specific override。

## 7.5 预留 legacy/non-aware UE

对 SBFD 类发明检查：
- SBFD-aware UE；
- non-SBFD-aware UE；
- full-duplex-capable UE；
- half-duplex UE；
- 不同 capability class。

说明不同终端在相同资源上的行为、优先级及兼容方式。

## 7.6 不在一个 apparatus claim 中混入第三方动作

避免：

> 一种基站，包括处理器……其中终端发送报告……

优选：

> ……处理器被配置为接收来自终端的报告……

这既有利于 US definiteness/direct infringement 分析，也有利于一般侵权主体识别。

## 7.7 “资源状态解析”型独立权利要求

当发明解决 flexible symbol、SBFD symbol、dynamic TDD 或多配置冲突问题时，优先考虑以下骨架：

> 一种由终端设备执行的方法，包括：  
> 获取与第一时间资源相关的第一配置信息；  
> 获取与所述第一时间资源中的至少一个频率资源相关的第二信息；  
> 基于所述第一配置信息、所述第二信息以及预定的优先关系，确定所述至少一个频率资源对应的通信行为；  
> 根据所确定的通信行为，在所述至少一个频率资源上执行或不执行发送、接收或测量。

可下沉限定：
- first info = semi-static TDD/SBFD config；
- second info = scheduling DCI/dynamic indication；
- behavior = allowed/prohibited/cancel/fallback；
- resource = PUSCH/PUCCH/PRACH/SRS/PDSCH；
- precedence = dynamic overrides semi-static / configuration-dependent。

## 7.8 Dynamic TDD 型权利要求至少形成两级抽象

### 上位
“基于动态信息确定时间频率资源的链路方向”。

### 下位
分别覆盖：
- scheduling information 决定方向；
- dedicated/group dynamic direction information 决定方向；
- dynamic selection of a preconfigured pattern。

不得只保护 SFI 或 DCI 2_0，除非该字段本身就是创新点。

## 7.9 SBFD 配置型权利要求必须区分“配置资源”和“实际可用资源”

至少区分：

- configured SBFD resource；
- scheduled/allocated resource；
- valid/available resource；
- actual transmission/reception resource。

这样可以保护：
- 网络先配置较宽候选资源，终端再根据方向/冲突/能力筛选；
- 网络下发 allocation，但部分资源由于 SBFD rule 被排除；
- 资源跨越 SBFD 与 non-SBFD 区域时的切分/取消/回退。

## 7.10 UL/DL decoupling 型权利要求的关系表达

优先保护“association relationship”：

> 第一上行载波与至少一个下行载波关联，所述关联用于确定同步、定时提前、功率控制、上行授权接收、随机接入或传输行为中的至少一项。

说明书必须进一步支持：
- 1:1；
- 1:N；
- M:1；
- M:N；
- same-band / inter-band；
- static / semi-static / dynamic association。

## 7.11 Capability-driven duplex claim

当标准化方案可能因设备等级分化时，形成：

UE 侧：
> 发送能力信息，所述能力信息指示终端支持的 duplex mode / simultaneous Tx-Rx / UL-DL bandwidth relation / switching capability。

网络侧：
> 基于能力信息确定 duplex configuration、carrier association、resource pattern 或 scheduling restriction。

这样比只保护某一 mode 的实际资源配置更利于覆盖芯片/终端和网络两个许可对象。

---

# 8. 从属权利要求矩阵

对每个核心独立权利要求，至少从以下维度挖掘 8–15 个可用从属特征，并按价值排序。

## A. 信息来源

- RRC；
- SIB；
- MAC CE；
- DCI；
- group-common DCI；
- pre-configuration；
- implicit derivation。

## B. 时间维度

- frame；
- slot；
- symbol；
- consecutive/non-consecutive；
- periodic/aperiodic；
- first/second time unit；
- repeated occasions。

## C. 频率维度

- CC；
- BWP；
- subband；
- RB set；
- PRB；
- frequency unit；
- guard band；
- contiguous/non-contiguous。

## D. Duplex 模式

- FD-FDD；
- HD-FDD；
- TDD；
- dynamic TDD；
- semi-static SBFD；
- dynamic SBFD；
- UE FD；
- gNB FD。

## E. Capability

- simultaneous Tx/Rx；
- filter switching；
- spatial configuration；
- RF chain；
- band combination；
- measurement capability。

## F. 传输过程

- PRACH/RO；
- PUCCH；
- PUSCH；
- SRS；
- PDSCH；
- PDCCH；
- HARQ；
- repetition。

## G. CLI/测量

- measurement signal；
- PUSCH-based CLI measurement；
- UE-to-UE CLI；
- gNB-to-gNB CLI；
- report content；
- triggering；
- reporting channel。

## H. 冲突处理

- transmission suppression；
- cancellation indication；
- priority；
- dropping；
- puncturing；
- fallback；
- error handling。

## I. 参数

- power；
- pathloss；
- TA offset；
- beam/spatial parameter；
- MCS；
- repetition count；
- guard resource；
- processing time。

## J. 部署

- single carrier；
- CA；
- multiple cells；
- multiple TRPs；
- distributed RAN；
- TN；
- NTN；
- MRSS；
- UL/DL decoupling。

---

# 9. 说明书的主线结构

## 9.1 背景技术

背景只完成三件事：

1. 说明 duplex 场景；
2. 说明现有机制造成的技术问题；
3. 引出需要解决的问题。

不要在背景中提前承认：
- 某具体现有方案必然已知；
- 发明区别特征属于公知常识；
- 某一标准实现是唯一实现。

使用“可能”“在一些场景中”“现有机制可能导致……”等中性技术语言。

## 9.2 发明内容

按“问题—方案—效果”对应：

- 技术问题 P1；
- 第一方面方案 S1；
- S1 产生效果 E1；
- 第二方面为对端方案；
- 装置/芯片/系统/介质与方法对应。

不宜用一句“与现有技术相比具有显著进步”替代具体技术因果关系。

## 9.3 第一幅核心图：多实体交互图

duplex 申请原则上至少有一幅：

**UE — serving gNB — optional neighbor gNB/coordinator**

流程示例：

S101：网络设备确定 duplex 配置；  
S102：网络设备向终端发送第一信息；  
S103：终端根据第一信息确定资源/方向/参数；  
S104：终端执行上行发送或下行接收；  
S105：可选地进行测量/报告；  
S106：网络设备基于报告更新资源/功率/模式。

若涉及跨小区 CLI，可扩展：
S107：第一网络设备与第二网络设备交换干扰/协调信息；  
S108：调整第二配置。

## 9.4 多实体流程之后必须分别给单实体视角

至少分别写：

### 终端视角实施例
只描述 UE 可执行和可感知的动作。

### 网络视角实施例
只描述 network node 可执行和可感知的动作。

### 可选协调节点视角
适用于 inter-gNB CLI、CU/DU、RIC 等。

这样可直接支撑单主体方法独立权利要求。

## 9.5 区别技术特征必须“纵向展开”

对每个区别技术特征至少描述：

1. 定义；
2. 输入；
3. 确定方式；
4. 输出；
5. 与其他特征的关系；
6. 至少两个具体例子；
7. 至少一个替代实现；
8. 边界情况；
9. 技术效果；
10. 可用于哪些实体/过程。

禁止只把权利要求换成说明书句式重复一遍。

---

# 10. Duplex 说明书必须覆盖的替代方案清单

结合交底书实际相关性，尽可能披露：

## 10.1 资源结构替代

- 一个或多个 UL subband；
- 一个或多个 DL subband；
- UL 位于中心/边缘；
- DL 位于中心/边缘；
- guard band 存在/不存在；
- 对称/非对称 guard；
- contiguous/non-contiguous；
- fixed/variable bandwidth；
- subband 数量可变。

## 10.2 时间结构替代

- full slot；
- partial slot；
- symbol-level；
- mixed UL/DL symbol；
- flexible symbol；
- predefined pattern；
- dynamically selected pattern。

## 10.3 信令替代

- RRC；
- SIB；
- DCI；
- MAC CE；
- joint indication；
- separate indications；
- bitmap；
- index；
- table；
- offset；
- implicit mapping。

## 10.4 模式替代

- semi-static TDD；
- dynamic TDD；
- semi-static SBFD；
- dynamic SBFD；
- UE HD；
- UE FD；
- gNB FD；
- FDD/HD-FDD。

## 10.5 测量/干扰替代

- SRS/CSI-RS/PUSCH/other reference signal；
- RSRP/RSRQ/SINR/interference power/derived metric；
- periodic/semi-persistent/aperiodic；
- UE-UE/gNB-gNB；
- event-triggered/on-demand。

## 10.6 冲突处理替代

- drop；
- cancel；
- suppress；
- postpone；
- puncture；
- priority-based selection；
- fallback to HD；
- switch duplex mode。

## 10.7 网络架构替代

- monolithic gNB；
- CU/DU；
- multiple TRPs；
- cloud RAN；
- relay；
- NTN node。

## 10.8 链路方向确定替代

至少考虑：

- fixed/predefined；
- semi-static configuration；
- scheduling DCI；
- dedicated dynamic indication；
- group-common indication；
- pattern index；
- resource-allocation-derived；
- traffic/load/CLI driven selection；
- network coordination driven selection。

## 10.9 状态优先级替代

至少考虑：

- common config 优先；
- dedicated config 优先；
- dynamic scheduling 优先；
- cancellation/priority indication 优先；
- invalid combination 直接忽略；
- partial resource valid；
- fallback to HD/TDD；
- defer to next valid occasion。

## 10.10 Carrier association 替代

至少考虑：

- serving/anchor carrier；
- secondary carrier；
- separate UL/DL carrier；
- different band；
- second-carrier fast access；
- carrier switching；
- dynamic association；
- association based on coverage/traffic/interference/capability。

## 10.11 规范命名替代

为防止最终标准改名，说明书对如下词语采用“功能定义 + 标准名示例”：

- SBFD symbol；
- mixed DL/UL symbol；
- duplex symbol；
- flexible symbol；
- guard/none/reserved resource；
- SFI；
- dynamic direction indication；
- carrier association。

例如不要只写“SBFD symbol”，而写：
> “第一类时间资源，其至少包括分别用于不同链路方向的第一频率部分和第二频率部分；在一些实现中，该第一类时间资源可称为 SBFD symbol、mixed DL/UL symbol、duplex symbol 或其他具有等价资源关系的时间资源。”

---

# 11. 5G/6G 标准演进预留规则（更新至 RAN1#126 / TR 38.760-1 v0.4.0）

## 11.1 标准时间线：Rel-19 normative → Rel-20 study → Rel-21 normative

当前撰写必须区分三段：

### Rel-18：SBFD study
- TR 38.858 对 NR duplex evolution/SBFD 进行研究；
- 研究动机包括缓解 TDD UL bottleneck、改善 UL performance/coverage/latency；
- 同时研究 self-interference、UE-UE CLI、gNB-gNB CLI、implementation/specification impact。

### Rel-19：SBFD normative introduction
- SBFD 已通过多份 TS CR 进入规范；
- TS 38.211 的 “Introduction of sub-band full duplex (SBFD)” CR 已由 RAN1#121 agreed、RAN#108 approved；
- 后续 TS 38.213 maintenance/correction 继续处理 flexible symbol、SBFD/non-SBFD occasion、同时配置等边界问题。

### Rel-20：6G study
- Work Item：FS_6G_Radio，UID 1080072；
- Release：Rel-20；
- RAN1 responsible；
- 当前 3GPP Portal 所列 start date 为 2025-06-06，end date 为 2027-06-04；
- TR 38.760-1 为 RAN1 6G study TR，当前已到 RAN1#126 v0.4.0。

### Rel-21：6G normative
3GPP Technical Highlights 明确将 Rel-20 用于 6G studies、Rel-21 作为 6G normative work 的起点并形成首批正式 6G 技术规范。

**撰写结论：**
当前新申请应以“Rel-19 可实施 + Rel-20 可演进 + Rel-21 可修改”为三层目标。

---

## 11.2 TR 38.760-1 版本基线

截至本 Skill 更新日，3GPP Portal 显示：

| Meeting | TR 38.760-1 version |
|---|---|
| RAN1#122-bis | 0.0.1 |
| RAN1#123 | 0.0.2 |
| RAN1#123 | 0.0.3 |
| RAN1#124 | 0.1.0 |
| RAN1#124-bis | 0.2.0 |
| RAN1#125 | 0.3.0 |
| RAN1#126 | 0.4.0 |

**Skill 行为：**
1. 每次生成新申请前检查是否存在更新版本；
2. 若有更新，优先检索 duplex/frame structure/spectrum aggregation/initial access/CLI 相关章节；
3. 不因版本号升级推定某个 proposal 已成为 agreement；
4. 若无法直接取得最新 TR 内容，明确标注“版本已确认、具体内容待原文核验”。

---

## 11.3 Rel-18 SBFD study 对说明书深度的要求

Rel-18 duplex evolution 显示，SBFD 的专利价值并不限于“同时上下行”，而横跨：

- gNB simultaneous Tx/Rx；
- UL/DL 位于不同 frequency subbands；
- SBFD-aware 与 non-aware UE coexistence；
- time/frequency location；
- semi-static vs dynamic behavior；
- transitions between SBFD/non-SBFD；
- self-interference；
- inter-UE CLI；
- inter-gNB CLI；
- transmission/reception across boundaries；
- implementation complexity。

因此说明书必须从：
**resource structure → configuration → UE behavior → interference → boundary condition**
形成完整链条。

---

## 11.4 Rel-19 TS 38.211 引入 SBFD 的专利启示

R1-2504980 / TS 38.211 CR 0151 表明 SBFD 已从 study 进入 normative physical-layer resource definition。

**Skill 强制规则：**
- 对“资源结构”类发明，至少形成一个不依赖具体 Rel-19 字段名的 concept claim；
- 另形成能够映射 TS resource/symbol/subband 关系的规范型从属；
- 检查同一 feature 是否还影响 38.213/38.214/38.321/38.331/38.306；
- 避免只依据一个 TS 条款判断 SEP 范围。

---

## 11.5 Rel-19 TS 38.213 ambiguity CR 的核心教训

R1-2605127 / TS 38.213 CR 0779 rev.1 的题名即针对“avoiding ambiguity for UE transmission in SBFD flexible symbols”。

这对专利撰写极具价值：

1. **不要只写资源配置**，要写配置被 UE 如何解释；
2. **不要只写 flexible symbol**，要写频域 subband 之后的实际 Tx admissibility；
3. 多个配置/调度信息共存时必须写 precedence；
4. 说明 invalid/overlap/cross-boundary 状态；
5. 网络侧要保护“配置/调度使 UE 得到唯一行为”的方法；
6. UE 侧要保护“解析多个信息并确定 allowed/prohibited Tx”的方法。

此外，Rel-19 同期 correction CR 还显示以下问题值得独立检查：
- SBFD/non-SBFD transmission/reception occasion 的跨边界澄清；
- SBFD 与其他配置同时存在时的规则。

**结论：**
“消除歧义的状态解析规则”本身可以成为高价值发明点，不应只视为说明书细节。

---

## 11.6 RAN1#122：6G duplex 候选集合

RAN1#122 的首批 6GR agreement 至少考虑：

- FD-FDD；
- semi-static TDD；
- gNB semi-static SBFD；
- HD-FDD on UE side；
- dynamic TDD。

并研究是否考虑：

- gNB dynamic SBFD；
- UE SBFD；
- gNB FD。

其他 duplex mode 不被排除。

**Skill 规则：**
- 最宽权利要求不默认 UE 或 gNB 必为 full duplex；
- 同一发明按“network simultaneous Tx/Rx”“UE simultaneous Tx/Rx”“neither”三类检查；
- dynamic SBFD/UE SBFD/gNB FD 当前仍需保留为替代路径，不宜写成标准事实；
- 对 low-tier UE，必须检查 HD-FDD / reduced capability 路径。

---

## 11.7 RAN1#122 frame structure：SCS/NCP 是实现参数，不是默认必要特征

RAN1#122 的 frame-structure 起点围绕不同频段的 SCS 展开，并以 normal CP 作为起点；PRACH 可单独讨论。

**Skill 规则：**
- 除非发明点与 numerology 本身相关，不把具体 SCS 写入最宽独权；
- 若 duplex behavior 与 symbol duration/guard/switching time 强相关，则保护“numerology 与 duplex parameter 的关系”；
- PRACH/random access 的 numerology 与 data/control numerology 分开写替代方案；
- 对 7 GHz、15 GHz、FR2/更高频等场景用“频率范围/频段类别”说明，不把研究初始值写成唯一实施例。

---

## 11.8 RAN1#123：scalable PHY 与 duplex capability

R1-2509141 属于 company contribution、status noted，不是 RAN1 agreement，但它反映出 6GR scalability 的重要专利方向：

- duplexing type 可随 device type 不同；
- half-duplex operation in paired bands 可作为复杂度降低手段；
- UL/DL carrier switching 可以独立；
- flexible UL-DL decoupling；
- TN/NTN harmonization。

**Skill 规则：**
- capability reporting 不只写“是否支持 SBFD”；
- 至少评估 duplex mode set、RF/BB bandwidth、RF chain、processing time、Tx power、switching capability；
- 将 capability → network configuration/scheduling 形成闭环；
- 为 low-tier/high-tier device 写不同实施例。

---

## 11.9 RAN1#124 FL summary：dynamic TDD 与 UL/DL decoupling 的方向性启示

R1-2601573 为 FL summary、status noted，应作为 Level P 材料处理。其重要启示包括：

- 6GR dynamic TDD 可考虑由 scheduling DCI 决定 transmission direction；
- 不一定继续采用 NR group-common SFI；
- spectrum aggregation 可能采用 virtual-cell 类抽象；
- UL CC 可与一个或多个 DL CC 关联；
- 该关联可用于 synchronization、TA、power control、UL grant 等。

**Skill 规则：**
- 不在独权写死 SFI/DCI 2_0；
- 为 scheduling-derived direction 与 separate dynamic indication 同时预留；
- carrier association 必须能够支持 1:N / M:N；
- decoupling claim 优先写“关联用于何种 PHY procedure”，避免只有抽象的“相关联”。

---

## 11.10 RAN1#124bis FL summary：Dynamic TDD 三族 + SBFD 六模块

R1-2603457 为 FL summary、status noted/open proposals，因此不能作为最终 agreement。但它明确暴露出 6G duplex 申请最值得预留的设计空间：

### Dynamic TDD
1. semi-static DL/UL/flexible pattern + scheduling DCI；
2. semi-static pattern + dynamic DL/UL/guard indication；
3. DL/UL/guard-only preconfigured patterns + dynamic pattern selection。

### Semi-static SBFD
至少研究：
1. time-frequency configuration；
2. random access configuration/procedure；
3. UE transmission behavior；
4. UE reception/measurement behavior；
5. collision handling；
6. inter-UE/inter-BS CLI management。

**Skill 规则：**
每一个 duplex 新申请都要运行这两个 checklist；即使交底书只涉及其中一个模块，也检查是否存在可以从同一发明核心自然派生的 continuation/divisional 主题。

---

## 11.11 RAN1#125：Rel-19 SBFD maintenance 反哺 6G 撰写

RAN1#125 的 R1-2605127 已进一步修正 Rel-19 SBFD flexible-symbol transmission ambiguity。

这说明在 6G 申请中应提前写清：
- symbol-level state；
- frequency-domain sub-state；
- common/dedicated configuration；
- dynamic scheduling；
- valid transmission occasion；
- cross-boundary behavior；
- precedence；
- fallback。

**专利策略：**
对这些“后期规范才容易发现的 corner case”，在 6G study 阶段提前申请，往往比只保护宏观 duplex mode 更有潜在标准价值。

---

## 11.12 RAN1#126 / TR 38.760-1 v0.4.0 的处理

官方 3GPP Portal 已确认 RAN1#126 对应 TR 38.760-1 v0.4.0，上传日期为 2026-08-14。

用户指定的公开 Chair Notes 目录显示 RAN1#126 Chair Notes 持续更新；本次检索环境对该目录/原文件直接访问返回 403，因此：

- **已确认**：RAN1#126 meeting 与 TR v0.4.0 的官方版本事实；
- **未在本 Skill 中推定**：#126 Chair Notes 中任何具体 duplex agreement 的逐字内容；
- 后续一旦取得 `Chair notes RAN1#126_v06.docx` 原件，必须运行“标准增量更新流程”：
  1. 搜索 Duplex / TDD / SBFD / FDD / full duplex / half duplex / link direction / CLI / carrier association；
  2. 按 Agreement / WA / FFS / Proposal 分类；
  3. 与 #124bis/#125 状态比较；
  4. 更新 claim-priority；
  5. 只把新形成的 agreement 提升到 Level A。

---

## 11.13 当前 Duplex 专利机会优先级

基于 Rel-19 normative 经验和 Rel-20 研究方向，默认按以下顺序评估新申请价值：

### Priority A：高标准映射/高取证性
- time-frequency duplex resource configuration；
- link-direction determination；
- UE Tx/Rx admissibility；
- collision/precedence/ambiguity resolution；
- random access in advanced-duplex resource；
- CLI measurement/report/coordination；
- capability-driven configuration。

### Priority B：高 6G 演进潜力
- dynamic TDD 三类机制；
- UL/DL decoupling；
- independent UL/DL carrier switching；
- dynamic SBFD；
- scalable duplex capability；
- mixed/duplex resource state。

### Priority C：说明书前瞻预留
- UE SBFD；
- gNB same-frequency FD；
- TN/NTN-specific duplex；
- MRSS/coexistence；
- virtual cell / advanced spectrum aggregation。

Priority C 不代表技术价值低，而表示当前标准成熟度更低，独权是否采用需更谨慎。

---

# 12. 从专利样本中提炼的可复用撰写模式

以下模式来自附件公开号样本及其同族/公开文本的归纳，不复制原文，仅提炼结构。

## 12.1 能力上报：从“设备能力”进一步细化到资源对粒度

代表样本：CN117560657A。

可复用经验：

- 不只写“支持 simultaneous Tx/Rx”；
- 可按 band、CC pair、BWP pair、subband pair 分层；
- 网络侧进一步保护“基于能力选择 duplex configuration/resource”。

## 12.2 资源方向：用“可用资源 + 方向信息”解耦

代表样本：US20220086839、WO2021258263A1。

可复用经验：

- 第一信息解决“哪些资源可用”；
- 第二信息解决“可用资源的方向”；
- 说明二者可联合/分离编码；
- 支持 bitmap、index、format、position indication 等替代；
- guard band 独立成可主张技术轴。

## 12.3 帧/符号格式：参数化而非固定格式号

代表样本：US20210360670、CN121508779A。

可复用经验：

- 用 X 个起始符号、Y 个末尾符号、方向关系等参数表达；
- 具体 slot format index 下沉；
- 同时披露 existing format + new format 组合。

## 12.4 mode-dependent behavior

代表样本：US20210400637、CN116097788B、CN122319635A。

可复用经验：

- 同一 UE/gNB 在不同 duplex mode 下对应不同解释、参数或行为；
- mode 可以与 TA、filter、spatial configuration、CSI assumption 等绑定；
- 保护“切换条件”和“切换后参数选择”比仅保护模式名称更有价值。

## 12.5 CLI 形成完整闭环

代表样本：US20220014954、WO2022056819A1、CN118524545A、CN121510108A、CN118944799A。

推荐闭环：

measurement configuration  
→ measurement signal/target  
→ measurement  
→ report trigger  
→ report channel/content  
→ network coordination  
→ resource/power/spatial adjustment。

其中任何具有独立创新性的环节都应评估独立权利要求。

## 12.6 Random Access 与 SBFD 的交叉

代表样本：CN119967621A、CN120434822A、CN120935848A、CN121508780A、CN121771970A。

可复用经验：

- RO 在 SBFD/non-SBFD 资源上的有效性；
- overlapping PRACH resource；
- SSB-to-RO mapping；
- RO group/repetition；
- 不同设备能力下的 fallback；
- 网络指示有效/无效或终端推导有效性。

## 12.7 Uplink behavior 与资源排除/冲突

代表样本：CN121508781A、CN116458244B、CN122295886A。

可复用经验：

- “allocated resource”与“actually used resource”分开定义；
- 明确被排除、取消或抑制的资源；
- 明确冲突对象；
- 提供 priority/condition/fallback；
- 不把内部判断算法作为唯一限定。

## 12.8 Power/SRS/TA 等外围机制不能遗漏

代表样本：CN118524502A、CN118785459A、CN120785689A、CN116097788B。

可复用经验：

- duplex mode 变化可能改变 pathloss reference、power parameter、TA、SRS resource 或 Tx/Rx switching；
- 若交底书只描述“资源”，仍应检查是否存在可独立保护的 RF/PHY 参数适配。

---

# 13. 中美欧法律适配规则

## 13.1 中国

依据中国专利法第二十六条，执行以下规则：

- 说明书应清楚、完整到所属技术领域技术人员能够实现；
- 权利要求以说明书为依据，清楚、简要；
- 上位概念必须有足够实施例和技术逻辑支持；
- 对“第一信息”“第一资源”等抽象概念，说明书必须给出明确技术含义和示例；
- 为后续修改预留“特征组合”的直接支持，而不是只分别罗列；
- 装置、芯片、系统、存储介质、程序产品的实现方式在说明书中明确展开。

## 13.2 美国

围绕 35 U.S.C. §112：

### Written Description
- 原始申请清楚体现对所主张技术范围的 possession；
- 对 genus/上位概念给出代表性 species 或结构性定义；
- 对计划后续新增到 claim 的组合提前披露。

### Enablement
- 对宽范围 duplex 方案给出足够实施方式，使本领域技术人员无需过度实验即可实施；
- 对 dynamic/semi-static、不同 node、不同 signaling 的关键分支给出具体方案。

### Definiteness
- claim boundary 可确定；
- 定义“time unit”“frequency unit”“simultaneous”“overlap”等可能多义术语；
- apparatus claim 不混入第三方实际执行步骤；
- 避免“optimal”“appropriate”“sufficient”等缺少客观边界的限定。

### §112(f)
- 若使用 means-plus-function，说明书明确对应硬件结构或算法；
- 默认优先“processor/memory configured to”或具体 functional unit 表述。

## 13.3 欧洲

围绕 EPC Art. 83、84、123(2) 及 Rule 43：

### Art. 83
- 至少一个可实施方案；
- 若 claim 很宽，应通过多个实施方式/替代方案支撑整个范围。

### Art. 84
- claim 类别清楚；
- 必要技术特征完整；
- 术语从 claim 本身尽量可理解；
- broad 不等于 unclear，但宽范围必须得到说明书技术支持。

### Art. 123(2)
- 后续修改必须能从原始申请“直接且无歧义”得到；
- 对可能的 narrowing feature 组合，原始申请即建立明确组合关系；
- 避免只靠多个彼此独立列表进行后续 picking-and-mixing。

### Rule 43(2)
- 欧洲正式 claim set 原则上每一类别一个独立权利要求；
- transmitter/receiver 等互相关联产品可根据规则例外处理；
- 母案说明书可以全面保留 UE/network/coordinator 方案，进入 EP 时再按 Rule 43 和单一性策略收敛。

## 13.4 3GPP 研究材料的“背景技术自认”防护

无论 CN/US/EP，起草 6G 申请时都应避免把未冻结标准材料无条件表述为“现有技术已经规定”。

推荐写法：
- “在一些研究中，正在讨论……”
- “一种候选机制可以……”
- “在某些系统中可能配置……”
- “本申请不限定该配置是否对应某一特定标准名称。”

避免写法：
- “3GPP 已规定 dynamic SBFD 必须……”，除非确有 normative text；
- “现有技术均采用……”
- “公知的是……”后接本申请未来可能依赖的区别特征。

对于美国申请尤其避免形成不必要 applicant admitted prior art；对于欧洲申请同时避免因背景描述不当缩窄技术问题或后续修改空间。

---

# 14. 侵权对象与产业链覆盖策略

| 产业主体 | 优先权利要求 | 重点可观察特征 |
|---|---|---|
| UE/手机/模组厂商 | UE 方法、终端装置、芯片 | capability、接收配置、资源确定、Tx/Rx 行为 |
| 基带/芯片厂商 | 芯片、装置、存储介质 | 资源计算、模式切换、信号处理 |
| gNB/RAN 设备商 | 网络侧方法、网络装置 | 配置、调度、资源/方向指示、CLI coordination |
| RAN 软件厂商 | 网络方法、程序产品 | scheduler、pattern selection、coordination |
| 运营商 | 网络方法、系统 | 网络配置、跨小区协调、动态 duplex 使用 |
| 云化 RAN/控制器 | coordinator/CU/RIC 方法 | 多节点信息汇聚与参数决策 |

**重要：**
权利要求布局应提高覆盖这些商业行为的可能性，但是否构成侵权仍取决于各法域的具体法律和证据，撰写阶段不得把“可能覆盖”写成“必然侵权”。

---

# 15. 标准必要专利（SEP）取向的额外规则

如果发明具有潜在标准化价值：

1. 优先保护标准中必须实现的空口行为，而不是实现者内部优化；
2. 对“发送/接收字段—资源关系—规定行为”建立清楚因果关系；
3. 在说明书中写出标准可能采用的多种编码方式，但独权不轻易绑定字段名称；
4. 给出终端和网络镜像 claim；
5. 对 optional feature 评估是否值得单独形成从属或分案主题；
6. 对同一技术点保留：
   - configuration claim；
   - behavior claim；
   - capability claim；
   - measurement/report claim；
   - coordination claim；
7. 若标准仍在研究阶段，将 company proposal、working assumption、agreement 与最终规范区分，不把未冻结方案写成事实背景；
8. 对每个候选 SEP claim 建立“claim feature → 3GPP clause/CR/agreement → UE/gNB observable behavior → evidence source”的四列映射；
9. 同一技术点若同时存在 RRC configuration、DCI indication、UE behavior、MAC/RA procedure、capability signaling，应检查是否可拆分成多个许可入口；
10. 对 correction CR 暴露的 ambiguity/corner case，优先评估 continuation/divisional 独立保护，而不是仅作为主申请的从属项。

---

# 16. 说明书附图最低配置

根据技术内容至少建议：

1. 无线通信系统架构图；
2. UE 与网络设备交互流程图；
3. duplex time-frequency resource 示意图；
4. 第一/第二资源集合关系图；
5. 多种 SBFD/TDD/FDD 资源格式示意图；
6. 信令流程图；
7. 冲突/优先级处理流程图；
8. CLI 测量与协调流程图（若相关）；
9. random access 流程/RO 映射图（若相关）；
10. 终端装置框图；
11. 网络装置框图；
12. 芯片/处理器实现框图。

每幅关键图至少在具体实施方式中有对应文字解释，不能只作为概念图存在。

---

# 17. 说明书语言规则

## 17.1 定义

对以下词语按需定义：

- “第一/第二”仅用于区分，不表示顺序；
- “至少一个”；
- “一个或多个”；
- “和/或”；
- “基于”可表示“至少部分基于”；
- “对应/关联”可能包括直接或间接关系；
- “同时”可根据场景定义为至少部分时间重叠，而非必然完全同起止；
- “重叠”可包括完全重叠或部分重叠；
- “时间单元/频率单元”给出多个粒度示例。

定义不得无限扩大到失去技术边界。

## 17.2 不使用不必要绝对化语言

避免：
- “必须”；
- “唯一”；
- “只能”；
- “所有情况下”；
- “最佳”。

除非确为发明必要条件。

## 17.3 技术效果要与特征一一对应

例如：

- 减少 UL latency；
- 增强 UL coverage；
- 降低 CLI；
- 减少 signaling overhead；
- 提高 resource utilization；
- 避免 collision；
- 降低 UE implementation complexity；
- 提高 measurement/report reliability。

说明“为什么”产生效果，而不是只列效果名称。

---

# 18. 全稿生成流程

## Phase 1：技术还原

1. 阅读交底书；
2. 识别核心问题；
3. 画出实体和消息；
4. 建立时频资源图；
5. 分离事实、推测和待确认信息；
6. 不自行补造发明人未提供且非本领域常规实现的关键区别特征。

## Phase 2：专利挖掘

1. 建立核心特征链；
2. 建立 actor map；
3. 建立标准化 map；
4. 建立商业/侵权 map；
5. 形成至少三档 claim scope：
   - Level A：最宽；
   - Level B：标准可能采用的主路径；
   - Level C：具体优选/回退。

## Phase 3：先写权利要求骨架

先写：
- UE independent；
- network independent；
- apparatus/chip；
- system/medium/program；

再写从属矩阵。

说明书必须反向支持全部 claim features。

## Phase 4：写多实体说明书

顺序：

1. 系统架构；
2. 总体交互；
3. UE 侧；
4. network 侧；
5. optional second network/coordinator；
6. 资源结构；
7. 信令；
8. duplex mode variants；
9. procedures；
10. edge cases；
11. apparatus implementation。

## Phase 5：替代方案扩展

逐项执行第 10 节 checklist。

## Phase 6：中美欧审查硬化

分别执行：
- CN support/clarity/enablement；
- US written description/enablement/definiteness/§112(f)；
- EP Art.83/84/123(2)/Rule43。

## Phase 7：SEP/侵权硬化

检查：
- 单主体；
- 外部可观察；
- 标准字段/资源关系；
- UE/gNB 镜像；
- 产品/芯片/系统类别；
- 未来 6G 替代。

## Phase 8：标准成熟度硬化

1. 给每一个标准对应点标记 N/S/A/W/P；
2. 删除把 proposal 写成 agreement 的表达；
3. 对 normative feature 提升可取证性；
4. 对 study feature 增加至少两种替代实现；
5. 对 dynamic TDD 运行三族 checklist；
6. 对 SBFD 运行六模块 checklist；
7. 对 flexible/mixed symbol 运行 ambiguity stress test；
8. 检查最新 TR 38.760-1 与 Chair Notes 是否发生增量变化。

---

# 19. 最终质量门（必须逐项通过）

## 19.1 技术门

- [ ] 核心问题与核心区别特征一一对应
- [ ] 核心技术效果有因果解释
- [ ] duplex mode 定义无自相矛盾
- [ ] 时频资源关系可画图、可实施
- [ ] terminal/network 行为一致
- [ ] signaling 的发送方、接收方、用途清楚
- [ ] collision、fallback、capability 等边界情况已考虑

## 19.2 权利要求门

- [ ] 每个方法独权以单一主体为中心
- [ ] 不无必要绑定标准消息名/格式号
- [ ] 独权包含区别特征而非只有目标效果
- [ ] apparatus claim 不混入第三方动作
- [ ] UE/network 两侧保护已评估
- [ ] chip/system/medium/program 已评估
- [ ] 从属权利要求有至少三层回退
- [ ] 关键可标准化 feature 有单独 claim 落点

## 19.3 说明书支持门

- [ ] 每个独权特征有明确原文支持
- [ ] 每个关键组合有直接组合实施例
- [ ] 每个上位概念有下位示例
- [ ] broad claim 的主要替代分支有实施方式
- [ ] 数值/集合/相对位置有多种示例
- [ ] 计划 EP 后续修改的组合已预埋

## 19.4 侵权/许可门

- [ ] 终端厂商可覆盖点
- [ ] 基站/RAN 厂商可覆盖点
- [ ] 芯片厂商可覆盖点
- [ ] 运营网络可覆盖点
- [ ] 可通过 OTA/log/标准测试观察的特征已优先
- [ ] 标准强制行为与内部算法已区分

## 19.5 6G 前瞻门

- [ ] FD-FDD/HD-FDD/TDD/SBFD 相关替代已评估
- [ ] semi-static/dynamic 两种思路已评估
- [ ] dynamic TDD 三族实现均已评估
- [ ] mixed/duplex/flexible/guard 等 resource-state 替代已评估
- [ ] UE/gNB FD 能力与行为已评估
- [ ] SBFD 六模块已逐项检查
- [ ] CLI 已评估
- [ ] UL/DL decoupling / CA / multi-carrier 已评估
- [ ] independent UL/DL carrier switching 已评估
- [ ] TN/NTN 适用性已评估
- [ ] numerology/CP 是否与 duplex 有必要耦合已评估
- [ ] latest TR 38.760-1 / Chair Notes 增量已检查

## 19.6 标准证据门

- [ ] 每一标准结论已标记 N/S/A/W/P
- [ ] proposal 未被写成 agreement
- [ ] study 未被写成 normative requirement
- [ ] normative CR 与后续 correction CR 已交叉检查
- [ ] 标准名与上位功能性表达均有说明书支持
- [ ] correction CR 暴露的 ambiguity/corner case 已检查
- [ ] #126 及后续无法取得原文的内容未被臆测

## 19.7 华为格式门

- [ ] 标题简洁、使用 IPC 通用术语、中文不超过 25 字、不含区别特征
- [ ] 技术领域格式正确、范围适当
- [ ] 背景技术仅含已公开现有技术，未写入发明本身或未冻结标准材料
- [ ] 发明内容用"方面/实现形式"组织，与权利要求语言一致，每个特征非可选形式，每段方案配套有益效果
- [ ] 具体实施方式先释术语、再场景/架构、后实施例，方法实施例按步骤式展开
- [ ] 权利要求使用"包括"，从权单特征，装置权利要求用硬件术语
- [ ] 摘要中文 300 字以内，附图标记全文一致，附图黑白且每图支撑权利要求要素

---

# 20. 禁止事项

1. 禁止把交底书没有依据的关键创新点当成发明内容补写；
2. 禁止为了“看起来宽”而使用无技术边界的纯结果性限定；
3. 禁止把 UE 和 gNB 的主动步骤混入一个单主体方法独权；
4. 禁止默认 SBFD=唯一 duplex 实现；
5. 禁止只写一个最佳实施例；
6. 禁止只列“RRC/DCI/MAC CE 均可”而不说明替代机制如何工作；
7. 禁止以一句“上述实施例可任意组合”代替关键组合的明确披露；
8. 禁止将尚在 6G study 中的方案称为最终 3GPP 标准；
9. 禁止为贴标准而把非必要标准术语全部写入独权；
10. 禁止复制既有专利的权利要求或说明书文字；只能提炼撰写方法与技术抽象。

---

# 21. 默认输出格式

用户要求“生成申请文件全稿”时，按以下顺序输出。各部分格式与语言须遵循第 26 节华为撰写规范及 [references/huawei_guidelines.md](references/huawei_guidelines.md)：

## A. 撰写策略摘要
- 核心发明点；
- 建议独权主体；
- 重点侵权对象；
- 5G/6G 标准化对应；
- 主要回退层级。

## B. 权利要求书
按正式申请风格输出。

## C. 说明书
1. 发明名称  
2. 技术领域  
3. 背景技术  
4. 发明内容  
5. 附图说明  
6. 具体实施方式  

## D. 摘要

## E. 附图建议

## F. 内部 QC 表（如用户要求）
- claim feature → specification support；
- actor/infringer；
- standard mapping；
- CN/US/EP risk；
- fallback amendment basis。

---

# 22. 可直接调用的任务提示

当用户提供交底书后，可执行如下内部指令：

> 应用 duplex-patent-application-drafting skill。首先从交底书提炼核心技术问题、区别技术特征、实体交互和时频资源关系；其次从 UE、网络设备、可选协调节点、芯片、系统和软件实现角度挖掘权利要求；同时从 5G NR Rel-19 SBFD 与 6G duplex 演进角度检查 dynamic TDD、semi-static/dynamic SBFD、FD/HD-FDD、CLI、random access、power/TA、Tx/Rx switching、UL/DL decoupling 等可替代方案。权利要求优先单主体、可取证、标准可映射；说明书按多实体交互流程后分别展开各实体视角，并对区别技术特征进行纵向细化。最终输出符合 CN/US/EP 支持、清楚性、充分公开和后续修改要求的完整申请文件。

---

# 23. 本 Skill 的分析依据

## 23.1 附件专利样本池

附件共 50 条记录，其中 US20220086029 重复 1 次，即 49 个不同公开号。样本池如下：

CN117560657A；CN117676840A；CN117676890A；CN117812733A；CN118524545A；CN118524502A；CN118785459A；CN118944799A；CN118972954A；CN118945829A；CN119483638A；CN119967621A；CN120076039A；CN120434822A；CN120785689A；CN121218336A；CN121013191A；CN120935848A；CN121442386A；CN121603165A；CN121485888A；CN121510065A；CN121508779A；CN121510108A；CN121508780A；CN121508781A；CN121771970A；CN121771977A；CN122002567A；CN122002368A；CN122375144A；CN122375159A；CN116458244B；CN122319635A；CN116097788B；CN122295886A；CN115668846B；CN122162452A；CN122139329A；CN122139331A；US20220086029；WO2021/258263；US20210360670；US20220086839；US20210400637；US20210297226；WO2022/056819；US20220014954；WO2021/217298。

分析方法：
- 对样本进行全文/摘要/权利要求/同族/引用链检索；
- 对能够公开检索到完整文本的代表文献重点分析 claim architecture 与 embodiment architecture；
- 不把单个专利的具体 claim language 复制进本 Skill；
- 归纳共同可复用的“能力—资源—方向—行为—干扰—过程—装置类别”撰写模式。

## 23.2 3GPP 标准材料（v2.1 增量）

### S1 — 3GPP Work Item FS_6G_Radio
- UID：1080072；
- Name：Study on 6G Radio；
- Release：Rel-20；
- Responsible group：RAN1；
- 当前 Portal：start 2025-06-06，end 2027-06-04；
- 用途：确定 6G Radio study 的正式工作项边界与时间状态。

### S2 — 3GPP TR 38.760-1
- Title：Study on 6G Radio RAN1 aspects；
- Type：TR；
- Status：Draft；
- Initial planned Release：Rel-20；
- 版本历史：
  - #122-bis v0.0.1；
  - #123 v0.0.2；
  - #123 v0.0.3；
  - #124 v0.1.0；
  - #124-bis v0.2.0；
  - #125 v0.3.0；
  - #126 v0.4.0。
- 用途：作为 6G RAN1 study 的官方汇总骨架。

### S3 — 3GPP Technical Highlights / 6G timeline
- 核心状态：Rel-20 = 6G studies；Rel-21 = 6G normative work / first formal 6G specifications；
- 注意：早期文章中对 6G study 完成时间的预期已被当前 FS_6G_Radio Portal 的 2027-06-04 end date 更新；
- 用途：标准生命周期和申请时机判断。

### S4 — Rel-18 Duplex Evolution / TR 38.858
- Study on evolution of NR duplex operation；
- 核心技术：SBFD、gNB simultaneous Tx/Rx、TDD UL bottleneck、time-frequency subband、CLI/self-interference、semi-static/dynamic behavior；
- 用途：形成 5G→6G duplex 专利技术轴。

### S5 — R1-2504980 / TS 38.211 CR 0151
- Title：Introduction of sub-band full duplex (SBFD)；
- RAN1#121 agreed；
- RAN#108 approved；
- Target new version：19.0.0；
- 用途：证明 Rel-19 SBFD 已进入 physical-layer normative specification，并触发跨规范 claim sweep。

### S6 — R1-2605127 / TS 38.213 CR 0779 rev.1
- Title：CR on avoiding ambiguity for UE transmission in SBFD flexible symbols；
- RAN1#125 agreed；
- RAN#112 approved；
- New version：19.4.0；
- 用途：提炼“resource-state resolution / precedence / Tx admissibility”专利方向。

### S7 — RAN1#122 first duplex agreements
- 至少考虑：FD-FDD、semi-static TDD、gNB semi-static SBFD、UE-side HD-FDD、dynamic TDD；
- 研究是否考虑：gNB dynamic SBFD、UE SBFD、gNB FD；
- other modes not precluded；
- 用途：6G duplex mode coverage matrix。
- 证据等级：Chair agreement 的公开转述；正式使用逐字表述时仍应核验 Chairman Notes 原件。

### S8 — R1-2506603 / RAN1#122 frame structure summary
- 6GR 对不同频率范围以若干 SCS 作为 discussion starting point；
- normal CP 作为起点；
- PRACH 可独立研究；
- 用途：说明 numerology 是 duplex 实施参数/关联参数，而非默认独权必要限定。
- 注意：公开资料指出后续存在 R1-2506604 final version；若用于精确标准引用，应优先核对 final。

### S9 — R1-2509141 / RAN1#123 Overview of 6GR air interface
- From MediaTek；
- Status：noted；
- 相关技术方向：duplexing type 作为 scalable device parameter、HD operation in paired band、independent DL/UL carrier switching、UL-DL decoupling、TN/NTN harmonization；
- 用途：Level P 技术启发，不作为 agreement。

### S10 — R1-2601573 / RAN1#124 FL summary #3
- From Huawei as moderator；
- Status：noted；
- 相关方向：dynamic TDD via scheduling DCI、SFI complexity、UL/DL decoupling、virtual-cell spectrum aggregation；
- 用途：Level P 候选架构。

### S11 — R1-2603457 / RAN1#124bis FL summary #5
- Status：noted/open proposals；
- Dynamic TDD 三类候选；
- semi-static SBFD 至少覆盖 time-frequency config、RA、UE Tx/Rx/measurement、collision、inter-UE/inter-BS CLI；
- 用途：本 Skill 的 “dynamic TDD 三族 + SBFD 六模块”强制 checklist。

### S18 — RAN1#126 Chair Notes public directory
- 用户指定：`Chair notes RAN1#126_v06.docx`，目录时间戳 2026-08-26；
- 本次环境可以定位该官方目录，但直接访问返回 403；
- 因此不基于未读取原件推定 #126 具体 duplex agreement；
- 与之独立地，官方 3GPP Portal 已确认 RAN1#126 / TR 38.760-1 v0.4.0，upload date 2026-08-14。

## 23.3 本次检索额外发现的 Rel-19 duplex maintenance 信号

官方 TS 38.213 CR 列表还显示：

- R1-2603468：Clarifications on transmission and reception occasion across SBFD and non-SBFD symbols；
- R1-2603432：Simultaneous configuration of SBFD and DC；
- 两者均在 RAN1#124-bis agreed、RAN#112 approved。

这些 correction/clarification 进一步证明：
- advanced-duplex patent 必须写边界；
- 同时配置必须写 precedence；
- “配置资源”与“有效 transmission/reception occasion”应分开；
- corner case 可以形成独立的专利挖掘主题。

## 23.4 标准材料使用约束

1. 官方 Portal/TS CR 优先于二手 tracker；
2. Chairman Notes 原件优先于网页转述；
3. FL summary 的“proposal/open/noted”不得升级表述为 agreement；
4. company contribution 只用于挖掘备选方案；
5. 若标准原始 ZIP/DOCX 因访问限制无法取得，不得伪造逐字原文；
6. 后续取得原件时，以原件对本 Skill 做增量更新并记录版本。

---

# 24. 版本维护规则

当出现以下任一情况时，应更新本 Skill：

1. TR 38.760-1 发布新版本；
2. RAN1 Chair Notes 对 duplex/dynamic TDD/SBFD 形成新的 agreement 或 working assumption；
3. dynamic SBFD / UE SBFD / gNB FD 的研究状态发生实质变化；
4. UL/DL decoupling、carrier switching 或 6G frame structure 形成明确规范方向；
5. 进入 Rel-21 normative 阶段并出现首批 6G TS CR；
6. Rel-19 SBFD 出现新的 correction CR，暴露新的 ambiguity/corner case；
7. 新公开专利显示新的 claim architecture；
8. CNIPA、USPTO 或 EPO 对通信/软件/功能性限定的审查实践发生重要变化；
9. 用户提供新的高质量申请文件作为撰写模板。

更新时保留：
- 旧版技术轴；
- 新增标准演进；
- 新增侵权/许可场景；
- 新增说明书替代方案；
- 新增 CN/US/EP 风险控制规则。


---

# 25. v2.1 相对 v2.0 的核心升级

1. 加入标准证据成熟度 N/S/A/W/P 分级；
2. 更新 FS_6G_Radio 当前官方时间状态；
3. 更新 TR 38.760-1 至 RAN1#126 v0.4.0；
4. 新增 Rel-19 normative → Rel-20 study → Rel-21 normative 三阶段专利策略；
5. 新增 dynamic TDD 三族候选架构；
6. 新增 semi-static SBFD 六模块 checklist；
7. 新增 resource-state / precedence / Tx admissibility 矩阵；
8. 新增 ambiguity stress test；
9. 新增跨 38.211/38.213/38.214/38.321/38.331/38.306/RAN3 规范扫描；
10. 新增 UL/DL decoupling、independent carrier switching、virtual-cell/spectrum aggregation 保护框架；
11. 新增 device scalability 与 duplex capability claim；
12. 新增 TN/NTN、MRSS/coexistence 预留；
13. 新增 3GPP study/proposal 作为背景技术时的自认风险控制；
14. 将 Rel-19 correction CR 中暴露的 corner cases 提升为专利挖掘对象；
15. 明确 #126 Chair Notes 原文未能直接读取时不得臆测具体 agreement。

---

# 26. 华为全球撰写规范（强制遵循）

本 Skill 输出的所有申请文件，除满足前述 duplex 技术方法论外，必须同时符合华为全球专利申请撰写指南。完整规范见 [references/huawei_guidelines.md](references/huawei_guidelines.md)，撰写时逐项对照执行。以下为与 duplex 撰写强相关的关键强制规则：

## 26.1 说明书规范

- **标题**：简洁准确、使用 IPC 通用技术术语；避免写入区别技术特征和限制性描述；中文不超过 25 个汉字；示例形态为「通信方法及装置」「一种内容分发方法及装置」，而非「一种具有双极耳结构的平板电脑电池」式自限标题。
- **技术领域**：格式「本申请涉及 XX 技术领域，尤其涉及一种 XX。」，范围适当不过窄。
- **背景技术**：仅写有物理证据的现有技术（已公开专利/期刊）；发明本身绝不写入背景；避免"现有技术/传统/已知"等措辞，改用"参考资料"或直接描述；不对华为专利/出版物作负面描述。此规则与本 Skill 第 0.1 节（标准证据分级）与第 13.4 节（背景自认防护）叠加：未冻结的 3GPP study/proposal 不得写成现有技术。
- **发明内容**：开篇说明目的；用"方面"（aspect）与"实现形式"组织；第一方面对应独权方法，每个"实现形式"对应重要从权；使用与权利要求一致的语言；**每个特征用非可选形式表述（不用"可以/可能"）**；**每写一段技术方案必须配套说明其有益效果**；装置方面按「收发模块+处理模块」模式撰写，并覆盖处理器、计算设备集群、计算机可读存储介质、计算机程序产品、芯片、通信系统等类别。
- **具体实施方式**：开篇先解释关键术语（英文缩写首次给出完整中英文全称）；再描述应用场景/系统架构（各网元角色、功能、连接关系、可替代设备类型）；方法实施例按 S210 步骤式展开并说明信息含义/形式/承载方式；采用"一般→具体→更具体→最具体"多层次描述。
- **附图说明**：每幅图用一句话说明类型，格式「图X为本申请实施例提供的XX示意图」；每幅图描述为"实施例"而非"本发明"。

## 26.2 权利要求规范

- 使用"包括"（comprising），避免"consisting of"；独权写构成发明的最宽泛要素组合。
- 每个从权最好只增加一个技术特征（或一组紧密相关特征）；不相关特征分开放在不同从权；从权可用多项引用。
- 装置权利要求与方法权利要求保护范围对应；方法权利要求除非必要不限定步骤顺序；不用 (a)(b)(c) 标记步骤；不用品牌名指代要素；用正面描述避免负面限定。
- **装置权利要求（美国实践）**：组件命名使用通常被视为硬件的术语（transceiver、transmitter、receiver、memory、processor、modulator、demodulator、antenna、display 等）；避免 "unit for doing / module for doing"；推荐 "a processor configured to ..." 风格。此规则与本 Skill 第 6.4 节（§112(f) 与功能模块型）叠加执行。
- **直接侵权**：尽量覆盖单一实体实施的全部要素；对发送方/接收方分别撰写；覆盖芯片商→设备制造商→销售商→服务提供商→终端用户产业链；优先保护可检测/可取证特征。此规则与本 Skill 第 3.2 节（主体/侵权对象表）与第 14 节（产业链覆盖）叠加执行。

## 26.3 摘要与附图规范

- **摘要**：中文 300 字以内（英文 150 词以内）；指明技术领域、方案要点、技术效果；使用平实自然语言而非权利要求格式；避免"本发明"。
- **附图**：每幅图至少支撑一个权利要求要素；装置附图描绘实际硬件器件；至少含系统级架构图、硬件结构图、流程图；黑白不用彩色/灰度；附图标记全文一致。此规则与本 Skill 第 16 节（附图最低配置）叠加执行。

> 华为指南为格式与语言层面的强制约束；当与本 Skill 其他章节冲突时，以更严格者为准。英文输出（PCT/US/EP 底稿）同样遵循华为指南中的对应英文规范。

---

# 27. v2.2 相对 v2.1 的核心升级

1. 新增「华为全球撰写规范」作为强制输出约束（见第 26 节）；
2. 引入华为指南的标题、技术领域、背景技术（AAPA 防护）、发明内容（方面/实现形式组织）、具体实施方式等说明书规范；
3. 引入华为指南的权利要求规范（"包括"、从权单特征、装置权利要求硬件术语与美国实践、直接侵权产业链覆盖）；
4. 引入华为指南的摘要字数、附图要素与附图标记一致性规范；
5. 完整规范文本存入 references/huawei_guidelines.md，遵循渐进式披露，SKILL.md 仅保留关键强制规则与引用。


---

# 28. 基于5份华为已提交申请提炼的方法实施例撰写规则（v2.3新增）

> 本章节规则源自对5份华为已提交Duplex相关专利申请（92123502CN01、92118256CN01、92107677CN01、92105466CN01、92079137CN01）的系统性逆向提炼。每项规则均标注来源文件及抽象化示例。

---

## 28.1 高频共性经验（强制规则）

### R-01：方法步骤编号规范

**来源**：5/5份文件均采用。

所有方法实施例步骤编号遵循以下约定：

| 视角 | 步骤编号 | 说明 |
|------|---------|------|
| 网络侧 | S201, S202, S203... | 网络设备确定/发送/接收 |
| 终端侧 | S301, S302, S303... | 终端设备获取/确定/发送 |
| 多实体交互 | S101, S102, S103... | 系统级交互（先于单实体展开） |
| 信令交互 | S401, S402, S403... | 额外信令交互流程 |

**强制要求**：不得使用"步骤1"、"步骤2"等无编号前缀的命名方式。网络侧和终端侧步骤编号必须严格区分。

### R-02：多实体对称描述强制规则

**来源**：5/5份文件均采用。

每个方法权利要求必须同时撰写**网络侧**和**终端侧**两个对称实施例，采用"确定/发送"与"获取/确定/执行"的对称动词体系：

**网络侧（抽象模板）**：
```
S201：[网络设备]确定[第一信息]，其中[第一信息]用于[指示/配置][对象/参数]。
S202：[网络设备]发送[第一信息]。
```

**终端侧（抽象模板）**：
```
S301：[终端设备]获取[第一信息]，其中[第一信息]用于[指示/配置][对象/参数]。
S302：[终端设备]根据[第一信息]确定[对象/参数]。
S303：[终端设备]基于[对象/参数]执行[动作]。
```

**如果涉及终端上报**（网络侧增加接收步骤）：
```
S203：[网络设备]接收[第二信息]，其中[第二信息]用于指示[终端能力/状态]。
S204：[网络设备]根据[第二信息]确定[第一信息]。
```

**强制要求**：不得仅写一个"收发双方"的混合实施例。网络侧和终端侧必须分别为独立的小节。

### R-03：概念展开最小规则

**来源**：5份文件平均每个核心概念展开3-7个"其中"。

每引入一个新概念，必须立即用**至少3个**"其中，..."展开：

```
[主句]第一通信装置确定第一信息。
其中，第一信息用于指示[功能1]。
其中，第一信息还用于指示[功能2]。
其中，第一信息包括[内容1]或[内容2]。
其中，第一信息承载于[承载方式1]或[承载方式2]。
```

展开维度应包括：
- 信息的功能用途（"用于指示/配置/表示..."）
- 信息包含的具体内容（"包括以下至少一项：..."）
- 信息的承载方式（"承载于RRC消息、MAC CE或DCI"）
- 信息的确定方式（"根据...确定"或"接收自..."）

**强制要求**：每个核心概念至少展开3个"其中"，不允许仅用一个"其中"一笔带过。

### R-04：发明内容—权利要求直接映射规则

**来源**：5/5份文件均采用。

发明内容（Summary of Invention）中的每个"方面"对应一个独立权利要求，每个"一种可能的实现方式"对应一个从属权利要求，且用语必须高度一致。

**映射关系**：
```
第一方面（方法）          → 独立权利要求1（方法）
  一种可能的实现方式      → 从属权利要求2
  一种可能的实现方式      → 从属权利要求3
第二方面（装置）          → 独立权利要求N（装置）
  一种可能的实现方式      → 从属权利要求N+1
第三方面（通信装置）      → 独立权利要求M（硬件装置）
第四方面（存储介质）      → 独立权利要求P
第五方面（程序产品）      → 独立权利要求Q
第六方面（芯片）          → 独立权利要求R
第七方面（通信系统）      → 独立权利要求S
```

**强制要求**：发明内容中各"方面"和"实现方式"的排列顺序必须与权利要求书中的顺序一致，且用语必须一致（翻译后也需一致）。

### R-05：第一/第二命名规范

**来源**：5/5份文件均采用。

上位概念统一使用以下命名体系，在具体实施例中再映射到具体设备：

| 上位名称 | 可映射的具体设备 |
|---------|-----------------|
| 第一通信装置 | 网络设备/gNB/TRP/DU/CU/协调节点 |
| 第二通信装置 | 终端设备/UE/移动设备 |
| 第一信息 | 配置信息/指示信息/能力信息 |
| 第二信息 | 上报信息/反馈信息/测量报告 |
| 第一参数 | 具体的技术参数 |
| 第一条件 | 触发条件/判断条件 |
| 第一资源 | 时间资源/频率资源/时频资源 |
| 第一模式/第二模式 | 工作模式/双工模式 |

**强制要求**：在独立权利要求和宽泛实施例中，始终使用"第一/第二+通用名称"，不直接使用"UE""gNB""终端""基站"等具体名称。在具体实施方式中明确"第一通信装置可以是网络设备，第二通信装置可以是终端设备"。

### R-06：装置实施例双模式

**来源**：3/5份文件采用。

发明内容中使用"模块化装置"：
```
处理模块，用于确定第一信息；
收发模块，用于发送第一信息。
```

具体实施方式中使用"硬件装置"：
```
处理器，用于确定第一信息；
收发器，用于发送第一信息；
存储器，用于存储指令，所述指令被所述处理器执行时，使所述通信装置执行所述方法。
```

**强制要求**：两种装置描述必须同时存在，不可只写一种。

### R-07：条件—动作—效果闭环

**来源**：5/5份文件均采用。

每引入一个条件判断，必须完整描述：
- 条件判断的内容（"如果第一信息指示..."）
- 满足条件时的动作（"则第一通信装置..."）
- 不满足条件时的动作（"否则第一通信装置..."）
- 动作产生的效果（"从而/以使得..."）

```
如果第一信息指示第一时间窗内允许联合信道估计，
则第一通信装置在第一时间窗内保持功率一致性和相位连续性，
以使得第二通信装置能够对第一时间窗内的多个信号进行联合信道估计；
否则第一通信装置可以调整功率和/或相位。
```

**强制要求**：不得只写条件与动作，缺少"否则"分支和效果说明。

### R-08：至少一项枚举

**来源**：5/5份文件均采用。

所有参数/信息列表必须使用"以下至少一项"明确枚举，**禁止使用"包括但不限于"**：

```
第一信息包括以下至少一项：
  调制编码方案MCS索引、
  MCS表类型、
  调制阶数、
  目标码率、
  频谱效率、
  传输块大小TBS。
```

**强制要求**：枚举项数≥3。禁止使用"包括但不限于"等模糊表述。

### R-09：递进展开至少三层

**来源**：5/5份文件均采用。

从宽到窄的递进展开至少3层：

```
在一些实施例中，[最宽泛的功能性描述]。
在一些可能的实现方式中，[进一步细化的技术方案]。
在一些示例中，[具体的参数值/配置方式]。
在另一些示例中，[替代的具体实现]。
```

**强制要求**：每个核心特征至少包含"实施例→实现方式→示例"三层递进，不得只有一层。

### R-10：信令来源多选

**来源**：5/5份文件均采用。

每个信息的承载方式至少提供3种替代：

```
第一信息承载于以下至少一项：
  无线资源控制RRC消息、
  媒体接入控制-控制元素MAC CE、
  下行控制信息DCI、
  系统信息块SIB。
```

**强制要求**：至少列举RRC、MAC CE、DCI三种，并根据技术相关性增加隐式确定/预定义等替代方式。

---

## 28.2 Duplex专项经验（强制规则）

### R-11：Duplex场景行为表

**来源**：基于92123502CN01（SBFD场景）、92079137CN01（SBFD功率回退）的SBFD处理模式。

每个Duplex方法实施例必须为以下场景分别描述行为：

| 场景 | 终端行为 | 网络行为 |
|------|---------|---------|
| 非SBFD符号 | 正常TDD行为 | 正常TDD行为 |
| SBFD符号 + UL子带 | 上行传输 | 上行接收 |
| SBFD符号 + DL子带 | 下行接收 | 下行发送 |
| SBFD符号 + guard band | 不传输/测量 | 不调度/保护 |
| SBFD符号 + 跨子带边界 | 冲突处理/取消/回退 | 避免调度/冲突管理 |
| 动态切换（SBFD↔non-SBFD） | 过渡期行为 | 过渡期配置 |

**强制要求**：不得仅描述"在SBFD符号上如何传输"，必须覆盖至少3种场景（非SBFD符号、SBFD符号+UL子带、SBFD符号+DL子带）。

### R-12：SBFD上位化规则

**来源**：5/5份文件均不直接在独立权利要求中使用"SBFD"一词。

在独立权利要求和宽泛实施例中，使用功能性描述替代"SBFD"：

| 禁止使用 | 应使用 |
|---------|--------|
| SBFD符号 | 第一时间资源，其中所述第一时间资源内的第一频率资源对应第一链路方向，第二频率资源对应第二链路方向 |
| UL子带 | 第一频率资源集合，用于上行传输 |
| DL子带 | 第二频率资源集合，用于下行传输 |
| guard band | 第三频率资源，位于第一频率资源集合和第二频率资源集合之间 |

在从属权利要求或具体实施例中再说明"第一类时间资源可称为SBFD符号"。

**强制要求**：独立权利要求中不得出现"SBFD"一词。

### R-13：双工模式切换覆盖

**来源**：基于92107677CN01（多射频链路模式切换）、92118256CN01（条件判断触发不同方式）。

Duplex新申请必须覆盖至少一种双工模式切换场景，包括但不限于：
- 半静态TDD → 动态TDD
- 非SBFD → SBFD
- HD-FDD → FD-FDD
- 不同SBFD配置之间的切换

每种切换需要描述：
- 触发条件（RRC重配置 / MAC CE / DCI / 定时器）
- 切换过程中的过渡行为
- 切换后的参数重设
- 切换失败的回退机制

**强制要求**：至少覆盖一种切换场景的完整描述。

### R-14：Duplex能力维度

**来源**：基于92107677CN01（多射频链路能力上报）、92123502CN01（联合信道估计能力相关）。

Duplex能力上报必须覆盖以下维度，形成"能力→模式选择→行为"的完整闭环：

```
终端设备发送能力信息，其中能力信息包括以下至少一项：
  支持的双工模式集合、
  支持的子带配置参数、
  同时收发能力指示、
  自干扰消除能力等级、
  射频链路切换时间、
  不同双工模式下支持的最大带宽。
```

网络侧根据能力信息确定配置。

**强制要求**：能力信息至少覆盖3个维度，且必须形成"能力上报→网络配置→终端行为"的闭环。

---

## 28.3 个别优秀写法（建议规则）

### R-15：三叉戟展开模式

**来源**：基于92118256CN01（三种实现方式）。

当同一技术问题有多种实现路径时，使用"方式一/方式二/方式三"展开：

```
方式一（完整实现）：[条件1] → [方案1] → [效果1]
方式二（最简实现）：[条件2] → [方案2] → [效果2]
方式三（折中实现）：[条件3] → [方案3] → [效果3]
```

每种子方式通过条件判断触发：
```
在满足第一条件的情况下，终端设备采用方式一；
在满足第二条件的情况下，终端设备采用方式二；
在满足第三条件的情况下，终端设备采用方式三。
```

**适用场景**：不同双工模式下的不同处理方式、不同能力等级下的不同行为、不同频段/载波组合下的不同配置。

**注意**：不强制要求必须是3种方式（2种或4种也合理），但每种方式必须有明确的条件触发。

### R-16：随路信息模式

**来源**：基于92105466CN01（随路TBS信息）。

当信息与数据一同传输时，使用"随路"（piggybacked）表述：

```
PDSCH携带第一信息 → 随路信令方式
其中第一信息与数据复用在同一物理信道中传输。
```

随路信息的关键特征：
- 与数据一同传输，而非单独信令
- 可复用现有资源（如PDSCH的部分RE）
- 可独立或联合编码

**适用场景**：Duplex场景下guard band用作随路信令资源、SBFD符号内与非SBFD符号内随路信息格式不同。

### R-17：多态扩展模式

**来源**：基于92105466CN01（HARQ-ACK多态扩展）。

当信息有多种状态时，明确列出所有状态及对应含义：

```
反馈信息包括以下至少一种状态：
  第一状态，表示正确接收；
  第二状态，表示未正确接收；
  第三状态，表示接收质量高于第一阈值；
  第四状态，表示接收质量低于第一阈值。
```

**适用场景**：HARQ-ACK扩展、能力等级分类、双工模式分类、干扰等级分类。

---

## 28.4 不建议固化但可参考的写法

以下写法在5份文件中出现但不应固化为强制规则：

- 三叉戟展开不强制要求必须是3种方式（2种或4种也合理）
- 具体数学公式的格式（因技术而异）
- 附图的具体编号方式（因专利而异）
- 发明名称中"一种"前缀的使用（可选）
- 步骤编号的具体起始数字（S201/S301等，S101/S201/S301均可，关键是区分实体）

---

## 28.5 说明书实施例检查清单（v2.3新增）

在完成说明书撰写后，逐项检查：

### 方法实施例检查项

- [ ] 网络侧方法实施例：S201确定、S202发送...（步骤编号正确）
- [ ] 终端侧方法实施例：S301获取、S302确定、S303执行...（步骤编号正确）
- [ ] 每个核心概念至少展开了3个"其中"
- [ ] 每个条件判断包含"条件—满足动作—否则动作—效果"完整闭环
- [ ] 所有参数列表使用"以下至少一项"枚举（≥3项）
- [ ] 每个信息至少提供了3种承载方式替代
- [ ] 递进展开至少3层（实施例→实现方式→示例）
- [ ] SBFD相关描述已上位化（独立权利要求中无"SBFD"一词）
- [ ] 至少覆盖了3种Duplex场景行为
- [ ] 至少覆盖了一种双工模式切换场景
- [ ] 能力信息至少覆盖了3个维度，且形成闭环

### 发明内容检查项

- [ ] 第一方面对应方法独权，用语与权利要求一致
- [ ] 每个"实现方式"对应一个从权
- [ ] 每个技术方案段落配套了有益效果说明
- [ ] 每个特征使用非可选形式表述
- [ ] 装置方面包含处理模块+收发模块描述
- [ ] 覆盖了处理器/存储介质/程序产品/芯片/系统等类别

### 装置实施例检查项

- [ ] 发明内容中有模块化装置描述（处理模块+收发模块）
- [ ] 具体实施方式中有硬件装置描述（处理器+收发器+存储器）
- [ ] 装置描述中未混入第三方动作

### 权利要求检查项

- [ ] 独立权利要求中使用"第一通信装置"上位概念
- [ ] 独立权利要求中不直接使用"UE""gNB""SBFD"等具体名称
- [ ] 从属权利要求中逐步下沉具体名称
- [ ] 装置权利要求无混入第三方动作


---

# 29. v2.3 相对 v2.2 的核心升级

1. **新增第28节「基于5份华为已提交申请提炼的方法实施例撰写规则」**，包含17条分级规则：
   - 10条高频共性经验（R-01至R-10），强制固化
   - 4条Duplex专项经验（R-11至R-14），强制固化
   - 3条个别优秀写法（R-15至R-17），建议固化
2. **新增方法步骤编号规范（R-01）**：S201/S202网络侧，S301/S302终端侧，S101多实体交互
3. **新增多实体对称描述强制规则（R-02）**：每个方法权利要求必须同时撰写网络侧和终端侧两个对称实施例
4. **新增概念展开最小规则（R-03）**：每个核心概念至少展开3个"其中"
5. **新增发明内容—权利要求直接映射规则（R-04）**：发明内容的"方面"和"实现方式"与权利要求体系一一对应
6. **新增第一/第二命名规范（R-05）**：上位概念统一使用"第一通信装置""第二通信装置"等
7. **新增装置实施例双模式规则（R-06）**：模块化装置+硬件装置双描述
8. **新增条件—动作—效果闭环规则（R-07）**：条件判断必须完整描述"满足→否则→效果"
9. **新增至少一项枚举规则（R-08）**：禁止使用"包括但不限于"
10. **新增递进展开三层规则（R-09）**：实施例→实现方式→示例
11. **新增信令来源多选规则（R-10）**：至少提供RRC/MAC CE/DCI三种替代
12. **新增Duplex场景行为表规则（R-11）**：至少覆盖3种Duplex场景行为
13. **新增SBFD上位化规则（R-12）**：独立权利要求中不得出现"SBFD"
14. **新增双工模式切换覆盖规则（R-13）**：至少覆盖一种切换场景
15. **新增Duplex能力维度规则（R-14）**：能力信息至少3个维度且形成闭环
16. **新增三叉戟展开模式（R-15）**：多路径场景下使用条件触发+方式展开
17. **新增随路信息模式（R-16）**：信息与数据一同传输的撰写模式
18. **新增多态扩展模式（R-17）**：信息多状态明确列出
19. **新增说明书实施例检查清单（§28.5）**：5大类检查项，覆盖方法实施例、发明内容、装置实施例、权利要求
20. 所有证据来源可追溯至5份具体专利文件
